"use strict";

// src/stage3/privacy.ts
var import_node_crypto = require("node:crypto");
async function cleanStage3Privacy(store, uid) {
  if (!await store.read("system", "stage3_catalog")) return;
  for (const collection of [
    "registrations",
    "articles",
    "events",
    "checkins"
  ]) {
    let offset = 0;
    for (; ; ) {
      const result = await store.list(
        collection,
        collection === "registrations" || collection === "checkins" ? { uid } : {},
        { offset, limit: 100 }
      );
      for (const record2 of result.items) {
        if ("publisherUid" in record2 && record2.publisherUid !== uid) continue;
        await store.run(async (tx) => {
          const control = await tx.get(
            "system",
            "control"
          );
          if (!control) throw new Error("NOT_INITIALIZED");
          await tx.set("system", "control", {
            ...control,
            revision: control.revision + 1
          });
          const current = await tx.get(
            collection,
            record2.id
          );
          if (!current) return;
          if (collection === "checkins")
            await tx.set(collection, record2.id, {
              ...current,
              reason: "",
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            });
          else if ("snapshot" in current)
            await tx.set(collection, record2.id, {
              ...current,
              snapshot: {
                studentId: "",
                name: "\u5DF2\u533F\u540D\u5316",
                gender: "\u672A\u586B\u5199",
                college: "",
                major: "",
                className: "",
                grade: ""
              },
              note: "",
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            });
          else
            await tx.set(collection, record2.id, {
              ...current,
              publisherName: "\u5DF2\u533F\u540D\u5316",
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            });
        });
      }
      offset += 100;
      if (offset >= result.total) break;
    }
  }
  const id = (0, import_node_crypto.randomUUID)();
  await store.run(
    (tx) => tx.set("audit_logs", id, {
      id,
      actor: "private-maintenance",
      action: "privacy.stage3_cleanup",
      target: uid,
      fields: ["registration.snapshot", "registration.note", "publisherName"],
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    })
  );
}

// src/forum/query.ts
var FORUM_TABLES = [
  "forum_boards",
  "forum_posts",
  "forum_comments",
  "forum_likes",
  "forum_favorites",
  "forum_reports",
  "forum_user_restrictions",
  "forum_notifications",
  "forum_images"
];
var queryTables = [...FORUM_TABLES, "audit_logs"];
var keys = [
  "_createdBefore",
  "_beforeFloor",
  "_forumAudit",
  "status",
  "boardId",
  "postId",
  "authorUid",
  "recipientUid",
  "reporterUid",
  "ownerUid",
  "uid",
  "read",
  "_search",
  "_sort",
  "_public",
  "_favoriteUid",
  "_featured",
  "_notDeleted"
];
function validateForumQuery(collection, filter, options) {
  if (!queryTables.includes(collection) || Object.keys(filter).some((k) => !keys.includes(k)) || Object.values(filter).some(
    (v) => !["string", "boolean"].includes(typeof v)
  ) || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50)
    throw new Error("INVALID_FORUM_QUERY");
  if (collection === "audit_logs" && filter._forumAudit !== true)
    throw new Error("INVALID_FORUM_AUDIT");
  if (filter._beforeFloor && !/^\d{1,9}$/.test(String(filter._beforeFloor)))
    throw new Error("INVALID_FLOOR");
  if (filter._sort && !["latest", "reply", "hot", "oldest", "featured"].includes(
    String(filter._sort)
  ))
    throw new Error("INVALID_FORUM_SORT");
}
function forumSelect(collection) {
  if (!queryTables.includes(collection)) throw new Error("INVALID_FORUM_TABLE");
  const publicCheck = collection === "forum_boards" ? `r.data->>'status' IN ('active','disabled')` : collection === "forum_posts" ? `r.data->>'status'='published' AND EXISTS(SELECT 1 FROM electronicclub.forum_boards b WHERE b.id=r.data->>'boardId' AND b.data->>'status' IN ('active','disabled'))` : collection === "forum_comments" ? `r.data->>'status' IN ('published','deleted') AND EXISTS(SELECT 1 FROM electronicclub.forum_posts p JOIN electronicclub.forum_boards b ON b.id=p.data->>'boardId' WHERE p.id=r.data->>'postId' AND p.data->>'status'='published' AND b.data->>'status' IN ('active','disabled'))` : "false";
  const filters = [
    "status",
    "boardId",
    "postId",
    "authorUid",
    "recipientUid",
    "reporterUid",
    "ownerUid",
    "uid",
    "read"
  ].map(
    (k) => `(NOT $1::jsonb ? '${k}' OR r.data->>'${k}'=$1::jsonb->>'${k}')`
  ).join(" AND ");
  const favorites = collection === "forum_posts" ? `EXISTS(SELECT 1 FROM electronicclub.forum_favorites f WHERE f.data->>'postId'=r.id AND f.data->>'uid'=$1::jsonb->>'_favoriteUid')` : "false";
  const order = collection === "forum_boards" ? `(data->>'position')::integer,id` : collection === "forum_comments" ? `(data->>'floor')::integer,id` : collection === "forum_posts" ? `coalesce((data->>'pinned')::boolean,false) DESC,CASE WHEN $1::jsonb->>'_sort'='hot' THEN coalesce((data->>'likeCount')::integer,0)*3+coalesce((data->>'commentCount')::integer,0)*2 END DESC NULLS LAST,CASE WHEN $1::jsonb->>'_sort'='reply' THEN data->>'lastReplyAt' ELSE data->>'createdAt' END DESC,id` : `data->>'createdAt' DESC,id`;
  const projection = collection === "forum_images" ? "r.data - 'dataUrl' AS data" : "r.data";
  return `WITH filtered AS (SELECT r.id,${projection} FROM electronicclub.${collection} r WHERE ${collection === "audit_logs" ? "r.data->>'action' LIKE 'forum.%' AND" : ""} ${filters} AND (NOT $1::jsonb ? '_notDeleted' OR r.data->>'status'<>'deleted') AND (NOT $1::jsonb ? '_public' OR (${publicCheck})) AND (NOT $1::jsonb ? '_favoriteUid' OR (${favorites})) AND (NOT $1::jsonb ? '_featured' OR r.data->>'featured'='true') AND (NOT $1::jsonb ? '_createdBefore' OR (r.data->>'createdAt')::timestamptz<($1::jsonb->>'_createdBefore')::timestamptz) AND (NOT $1::jsonb ? '_beforeFloor' OR (r.data->>'floor')::integer<($1::jsonb->>'_beforeFloor')::integer) AND (NOT $1::jsonb ? '_search' OR strpos(lower(coalesce(r.data->>'title','')||' '||coalesce(r.data->>'body','')||' '||coalesce(r.data->>'name','')),lower($1::jsonb->>'_search'))>0)),paged AS (SELECT id,data,row_number() OVER(ORDER BY ${order}) AS n FROM filtered ORDER BY ${order} LIMIT $2 OFFSET $3) SELECT jsonb_build_object('total',(SELECT count(*) FROM filtered),'items',coalesce((SELECT jsonb_agg(data||jsonb_build_object('id',id) ORDER BY n) FROM paged),'[]'::jsonb)) AS result`;
}

// src/members/pg-store.ts
var import_pg = require("pg");
var tables = /* @__PURE__ */ new Set([
  ...FORUM_TABLES,
  "events",
  "event_managers",
  "registrations",
  "checkins",
  "articles",
  "popup_announcements",
  "popup_state",
  "users",
  "roles",
  "permissions",
  "credentials",
  "sessions",
  "student_ids",
  "audit_logs",
  "import_jobs",
  "login_limits",
  "system",
  "privacy_jobs"
]);
function table(name) {
  if (!tables.has(name)) throw new Error("INVALID_TABLE");
  return `electronicclub.${name}`;
}
var DatabaseFailure = class extends Error {
  constructor(stage, safeCode2, diagnostic) {
    super("Database unavailable");
    this.stage = stage;
    this.safeCode = safeCode2;
    this.diagnostic = diagnostic;
  }
};
function createPool() {
  if (!process.env.DATABASE_URL)
    throw new DatabaseFailure("configuration", "DATABASE_NOT_CONFIGURED");
  if (process.env.PG_TLS !== "disable" && !process.env.PG_CA_CERT)
    throw new DatabaseFailure("configuration", "TLS_CA_REQUIRED");
  let endpoint;
  try {
    endpoint = new URL(process.env.DATABASE_URL);
  } catch {
    throw new DatabaseFailure("configuration", "INVALID_DATABASE_URL");
  }
  if (!["postgres:", "postgresql:"].includes(endpoint.protocol) || [...endpoint.searchParams.keys()].some(
    (key) => key.toLowerCase().startsWith("ssl")
  ))
    throw new DatabaseFailure("configuration", "UNSAFE_DATABASE_URL");
  if (process.env.PG_TLS === "disable" && !["127.0.0.1", "localhost", "[::1]"].includes(endpoint.hostname))
    throw new DatabaseFailure("configuration", "REMOTE_TLS_REQUIRED");
  return new import_pg.Pool({
    connectionString: process.env.DATABASE_URL,
    max: 4,
    connectionTimeoutMillis: 5e3,
    idleTimeoutMillis: 3e4,
    statement_timeout: 15e3,
    ssl: process.env.PG_TLS === "disable" ? false : { rejectUnauthorized: true, ca: process.env.PG_CA_CERT }
  });
}
var PgStore = class {
  constructor(pool = createPool()) {
    this.pool = pool;
    pool.on(
      "error",
      () => console.error(
        JSON.stringify({
          category: "database",
          stage: "idle_connection",
          code: "DB_CONNECTION_FAILED"
        })
      )
    );
  }
  roleVerified = false;
  async verifyRole() {
    if (this.roleVerified) return;
    const result = await this.pool.query(
      "SELECT rolsuper,rolcreatedb,rolcreaterole,rolreplication FROM pg_roles WHERE rolname=current_user"
    ).catch(() => {
      throw new DatabaseFailure("authorization", "DB_ROLE_CHECK_FAILED");
    });
    if (!result.rows[0] || Object.values(result.rows[0]).some(Boolean))
      throw new DatabaseFailure("authorization", "PRIVILEGED_DB_ROLE");
    this.roleVerified = true;
  }
  async run(fn) {
    await this.verifyRole();
    const client = await this.pool.connect().catch(() => {
      throw new DatabaseFailure("connect", "DB_CONNECT_FAILED");
    });
    let stage = "begin";
    try {
      await client.query("BEGIN");
      await client.query("SET LOCAL idle_in_transaction_session_timeout='30s'");
      await client.query("SELECT pg_advisory_xact_lock(1991,1)");
      stage = "transaction";
      const tx = {
        get: async (c, id) => {
          const result2 = await client.query(
            `SELECT data FROM ${table(c)} WHERE id=$1`,
            [id]
          );
          return result2.rows[0]?.data ?? null;
        },
        set: async (c, id, value) => {
          await client.query(
            `INSERT INTO ${table(c)}(id,data) VALUES($1,$2) ON CONFLICT(id) DO UPDATE SET data=excluded.data`,
            [id, JSON.stringify(value)]
          );
          if (c === "users") {
            await client.query(
              "DELETE FROM electronicclub.user_roles WHERE user_id=$1",
              [id]
            );
            for (const role of value.roleIds ?? [])
              await client.query(
                "INSERT INTO electronicclub.user_roles VALUES($1,$2)",
                [id, role]
              );
          }
        },
        remove: async (c, id) => {
          await client.query(`DELETE FROM ${table(c)} WHERE id=$1`, [id]);
        }
      };
      const result = await fn(tx);
      stage = "commit";
      await client.query("COMMIT");
      return result;
    } catch (error) {
      try {
        await client.query("ROLLBACK");
      } catch {
      }
      const code = String(error.code ?? "");
      if (/^[0-9A-Z]{5}$/.test(code)) throw new DatabaseFailure(stage, code);
      throw error;
    } finally {
      client.release();
    }
  }
  async read(c, id) {
    try {
      await this.verifyRole();
      return (await this.pool.query(`SELECT data FROM ${table(c)} WHERE id=$1`, [
        id
      ])).rows[0]?.data ?? null;
    } catch {
      throw new DatabaseFailure("read", "DB_READ_FAILED");
    }
  }
  async list(c, filter, options) {
    await this.verifyRole();
    if (c.startsWith("forum_") || filter._forumAudit === true) {
      validateForumQuery(c, filter, options);
      const result = await this.pool.query(forumSelect(c), [filter, options.limit, options.offset]);
      return result.rows[0].result;
    }
    const args = [], clauses = [];
    const param = (value) => {
      args.push(value);
      return `$${args.length}`;
    };
    for (const [key, value] of Object.entries(filter)) {
      if (key === "_search")
        clauses.push(
          `(strpos(upper(data->>'studentId'),upper(${param(value)}))>0 OR strpos(upper(data->>'name'),upper($${args.length}))>0 OR strpos(upper(data->>'nickname'),upper($${args.length}))>0)`
        );
      else if (key === "_notDeleted") clauses.push("data->>'status'<>'deleted'");
      else if (key === "roleIds")
        clauses.push(
          `data->'roleIds' @> ${param(JSON.stringify([value]))}::jsonb`
        );
      else {
        if (!["status", "college", "className", "owner", "uid"].includes(key))
          throw new Error("INVALID_FILTER");
        clauses.push(`data->>'${key}'=${param(value)}`);
      }
    }
    const where = clauses.length ? " WHERE " + clauses.join(" AND ") : "";
    try {
      const count = await this.pool.query(
        `SELECT count(*) AS total FROM ${table(c)}${where}`,
        args
      );
      const rows = await this.pool.query(
        `SELECT data FROM ${table(c)}${where} ORDER BY data->>'createdAt' DESC,id ASC LIMIT $${args.length + 1} OFFSET $${args.length + 2}`,
        [...args, options.limit, options.offset]
      );
      return {
        items: rows.rows.map((row) => row.data),
        total: Number(count.rows[0].total)
      };
    } catch {
      throw new DatabaseFailure("query", "DB_QUERY_FAILED");
    }
  }
};

// src/members/cloudbase-auth.ts
var import_node_crypto2 = require("node:crypto");
var import_signature_nodejs = require("@cloudbase/signature-nodejs");
function cloudbaseAuthorization(env) {
  let cached;
  let pending;
  const invalidate = () => {
    cached = void 0;
  };
  async function header() {
    if (process.env.CLOUDBASE_APIKEY)
      return `Bearer ${process.env.CLOUDBASE_APIKEY}`;
    const secretId = process.env.TENCENTCLOUD_SECRETID, secretKey = process.env.TENCENTCLOUD_SECRETKEY, sessionToken = process.env.TENCENTCLOUD_SESSIONTOKEN;
    if (!secretId || !secretKey)
      throw new DatabaseFailure(
        "runtime_identity",
        "CLOUDBASE_IDENTITY_UNAVAILABLE"
      );
    const fingerprint = (0, import_node_crypto2.createHash)("sha256").update(JSON.stringify([secretId, secretKey, sessionToken])).digest("hex");
    if (cached?.fingerprint === fingerprint && cached.until > Date.now())
      return `Bearer ${cached.token}`;
    if (!pending || pending.fingerprint !== fingerprint) {
      const exchange = async () => {
        const url = `https://${env}.api.tcloudbasegateway.com/auth/v1/token/clientCredential`;
        const body = { grant_type: "client_credentials" };
        const headers = {
          "Content-Type": "application/json",
          Host: new URL(url).host,
          "X-TCB-Source": `${process.env.TCB_SOURCE || ""},scf`,
          "X-Client-Timestamp": String(Date.now()),
          "X-SDK-Version": "tcb-node-sdk/3.18.7"
        };
        if (process.env.TENCENTCLOUD_REGION)
          headers["X-TCB-Region"] = process.env.TENCENTCLOUD_REGION;
        const signed = (0, import_signature_nodejs.sign)({
          secretId,
          secretKey,
          method: "POST",
          url,
          params: body,
          headers,
          timestamp: Math.floor(Date.now() / 1e3) - 1,
          withSignedParams: false,
          isCloudApi: true
        });
        headers.Authorization = `${signed.authorization}, Timestamp=${signed.timestamp}${sessionToken ? `, Token=${sessionToken}` : ""}`;
        let response;
        try {
          response = await fetch(url, {
            method: "POST",
            headers,
            body: JSON.stringify(body),
            signal: AbortSignal.timeout(15e3)
          });
        } catch {
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_UNREACHABLE"
          );
        }
        if (!response.ok)
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_REJECTED"
          );
        let result;
        try {
          result = await response.json();
        } catch {
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_INVALID_RESPONSE"
          );
        }
        if (!result || typeof result.access_token !== "string" || !result.access_token)
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_INVALID_RESPONSE"
          );
        const lifetime = typeof result.expires_in === "number" && Number.isFinite(result.expires_in) ? Math.max(0, Math.min(result.expires_in, 3600) - 60) : 0;
        cached = {
          token: result.access_token,
          until: Date.now() + lifetime * 1e3,
          fingerprint
        };
        return `Bearer ${result.access_token}`;
      };
      pending = { fingerprint, promise: exchange() };
    }
    const active = pending;
    try {
      return await active.promise;
    } finally {
      if (pending === active) pending = void 0;
    }
  }
  return { header, invalidate };
}

// src/members/rdb-diagnostics.ts
var providerCodes = /* @__PURE__ */ new Set([
  "INVALID_PATH",
  "INVALID_ENV",
  "INVALID_ENV_ID",
  "ENV_NOT_FOUND",
  "RESOURCE_NOT_FOUND",
  "DATABASE_NOT_INITIALIZED",
  "DATABASE_NOT_FOUND",
  "PERMISSION_DENIED",
  "UNAUTHORIZED",
  "FORBIDDEN",
  "NOT_FOUND",
  "INTERNAL_ERROR",
  "INTERNAL_SERVER_ERROR",
  "FAILED_OPERATION",
  "ACCESS_TOKEN_INVALID",
  "TOKEN_EXPIRED",
  "FailedOperation",
  "InvalidParameter",
  "InvalidParameterValue",
  "ResourceNotFound",
  "UnauthorizedOperation",
  "AuthFailure",
  "InternalError",
  "OperationDenied",
  "ServiceUnavailable"
]);
var sqlStates = /* @__PURE__ */ new Set([
  "42501",
  "42P01",
  "42883",
  "3F000",
  "23505",
  "23503",
  "23514",
  "23502",
  "40001",
  "40P01",
  "53300",
  "53400",
  "57014",
  "55P03",
  "08000",
  "08001",
  "08003",
  "08004",
  "08006",
  "08P01",
  "XX000",
  "P0001"
]);
var record = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
function safeCode(value) {
  if (typeof value !== "string") return void 0;
  return providerCodes.has(value) || sqlStates.has(value) || /^PGRST\d{3}$/.test(value) ? value : void 0;
}
function safeId(value) {
  return typeof value === "string" && /^(?:[0-9a-f]{32}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(
    value
  ) ? value : void 0;
}
async function rdbDiagnostic(response, operation) {
  let body = {};
  try {
    body = record(await response.json());
  } catch {
  }
  const wrapper = record(body.Response);
  const nested = record(body.error);
  const error = record(wrapper.Error);
  const code = [body.code, nested.code, error.Code, body.errorCode].map(safeCode).find(Boolean);
  const requestId = [
    response.headers.get("x-request-id"),
    response.headers.get("x-tcb-request-id"),
    response.headers.get("x-cloudbase-request-id"),
    body.requestId,
    body.request_id,
    body.reqId,
    body.RequestId,
    wrapper.RequestId
  ].map(safeId).find(Boolean);
  const contentType = response.headers.get("content-type") ?? "";
  return {
    upstreamStatus: response.status,
    upstreamCode: code ?? "UNRECOGNIZED",
    upstreamRequestId: requestId,
    operation: ["ec_read", "ec_list", "ec_commit"].includes(operation) ? operation : "unknown",
    responseKind: contentType.includes("json") ? "json" : contentType.includes("html") ? "html" : "other"
  };
}
function rdbFailureCode(diagnostic) {
  const code = diagnostic.upstreamCode;
  if ([401, 403].includes(diagnostic.upstreamStatus) || [
    "42501",
    "PGRST301",
    "PERMISSION_DENIED",
    "UNAUTHORIZED",
    "FORBIDDEN",
    "AuthFailure",
    "UnauthorizedOperation",
    "ACCESS_TOKEN_INVALID",
    "TOKEN_EXPIRED"
  ].includes(code))
    return "RDB_HTTP_PERMISSION_DENIED";
  if (["PGRST202", "42883"].includes(code)) return "RDB_RPC_NOT_INSTALLED";
  if (["42P01", "3F000", "PGRST205"].includes(code))
    return "RDB_SCHEMA_NOT_INSTALLED";
  if (code === "PGRST106") return "RDB_SCHEMA_NOT_EXPOSED";
  if (code === "INVALID_PATH") return "RDB_ENDPOINT_NOT_AVAILABLE";
  if (["PGRST000", "PGRST001"].includes(code))
    return "RDB_DATABASE_UNAVAILABLE";
  return "RDB_HTTP_FAILED";
}

// src/members/http-store.ts
function cloudbaseRpc() {
  const env = process.env.CLOUDBASE_ENV_ID;
  if (!env || !/^[a-zA-Z0-9-]+$/.test(env))
    throw new DatabaseFailure("configuration", "CLOUDBASE_ENV_REQUIRED");
  const auth = cloudbaseAuthorization(env);
  const base = `https://${env}.api.tcloudbasegateway.com/v1/rdb/rest/rpc/`;
  return async (name, args) => {
    const authorization = await auth.header();
    let response;
    try {
      response = await fetch(base + name, {
        method: "POST",
        headers: {
          Authorization: authorization,
          "Content-Type": "application/json",
          "Accept-Profile": "public",
          "Content-Profile": "public"
        },
        body: JSON.stringify(args),
        signal: AbortSignal.timeout(15e3)
      });
    } catch {
      throw new DatabaseFailure("http_connect", "RDB_HTTP_UNREACHABLE");
    }
    if (!response.ok) {
      if (response.status === 401) auth.invalidate();
      const diagnostic = await rdbDiagnostic(response, name);
      throw new DatabaseFailure(
        "http_rpc",
        rdbFailureCode(diagnostic),
        diagnostic
      );
    }
    try {
      return await response.json();
    } catch {
      throw new DatabaseFailure("http_decode", "RDB_HTTP_INVALID_RESPONSE");
    }
  };
}
var HttpStore = class {
  constructor(rpc = cloudbaseRpc()) {
    this.rpc = rpc;
  }
  async read(collection, id) {
    const snapshot = await this.rpc("ec_read", {
      p_collection: collection,
      p_id: id
    });
    return snapshot.data;
  }
  async list(collection, filter, options) {
    const forum = collection.startsWith("forum_") || filter._forumAudit === true;
    if (forum) validateForumQuery(collection, filter, options);
    return await this.rpc(forum ? "ec_forum_list" : "ec_list", {
      p_collection: collection,
      p_filter: filter,
      p_offset: options.offset,
      p_limit: options.limit
    });
  }
  async run(fn) {
    for (let attempt = 0; attempt < 32; attempt++) {
      const reads = /* @__PURE__ */ new Map(), writes = /* @__PURE__ */ new Map();
      const load = (collection, id) => {
        const key = collection + "/" + id;
        if (!reads.has(key))
          reads.set(
            key,
            this.rpc("ec_read", {
              p_collection: collection,
              p_id: id
            }).then((snapshot) => ({
              collection,
              id,
              ...snapshot
            }))
          );
        return reads.get(key);
      };
      const tx = {
        get: async (collection, id) => {
          const key = collection + "/" + id;
          return structuredClone(
            writes.has(key) ? writes.get(key).data : (await load(collection, id)).data
          );
        },
        set: async (collection, id, data) => {
          await load(collection, id);
          writes.set(collection + "/" + id, {
            collection,
            id,
            data: structuredClone(data)
          });
        },
        remove: async (collection, id) => {
          await load(collection, id);
          writes.set(collection + "/" + id, { collection, id, data: null });
        }
      };
      const result = await fn(tx);
      const commit = await this.rpc("ec_commit", {
        p_reads: (await Promise.all(reads.values())).map(
          ({ collection, id, etag }) => ({ collection, id, etag })
        ),
        p_writes: [...writes.values()]
      });
      if (commit.ok) return result;
      if (commit.conflict)
        await new Promise(
          (resolve) => setTimeout(resolve, 5 + Math.floor(Math.random() * 20))
        );
      if (!commit.conflict)
        throw new DatabaseFailure("http_commit", "RDB_COMMIT_REJECTED");
    }
    throw new DatabaseFailure("http_commit", "RDB_CONFLICT_RETRY_EXHAUSTED");
  }
};

// ../../packages/shared/src/student-id.ts
var STUDENT_ID_MESSAGE = "\u5B66\u53F7\u987B\u4E3A4\u201324\u4F4D\u82F1\u6587\u5B57\u6BCD\u6216\u6570\u5B57\uFF0C\u4E0D\u5141\u8BB8\u7A7A\u683C\u6216\u7279\u6B8A\u5B57\u7B26";
function isValidStudentId(value) {
  return typeof value === "string" && value.length >= 4 && value.length <= 24 && !/[^A-Za-z0-9]/.test(value);
}
function normalizeStudentId(value) {
  if (!isValidStudentId(value)) throw new Error(STUDENT_ID_MESSAGE);
  return value.toUpperCase();
}

// ../../packages/shared/src/forum.ts
var DEFAULT_FORUM_BOARDS = [
  "\u7EFC\u5408\u4EA4\u6D41",
  "\u5355\u7247\u673A\u4E0E\u5D4C\u5165\u5F0F",
  "\u7535\u8DEF\u8BBE\u8BA1\u4E0E PCB",
  "\u710A\u63A5\u4E0E\u7535\u5B50\u5236\u4F5C",
  "\u7535\u8D5B\u4EA4\u6D41",
  "\u9879\u76EE\u5206\u4EAB",
  "\u7F16\u7A0B\u4E0E\u8F6F\u4EF6\u5F00\u53D1"
].map((name, index) => ({
  id: `board-${index + 1}`,
  name,
  description: name === "\u7535\u8D5B\u4EA4\u6D41" ? "\u5168\u56FD\u5927\u5B66\u751F\u7535\u5B50\u8BBE\u8BA1\u7ADE\u8D5B\u5B66\u4E60\u4E0E\u4EA4\u6D41" : "\u5206\u4EAB\u5B9E\u8DF5\u7ECF\u9A8C\uFF0C\u4E00\u8D77\u89E3\u51B3\u95EE\u9898",
  position: index + 1,
  status: "active",
  requireReview: false
}));

// src/members/crypto.ts
var import_node_crypto3 = require("node:crypto");
var digest = (value) => (0, import_node_crypto3.createHash)("sha256").update(value).digest("hex");
var studentIdKey = (studentId) => digest(normalizeStudentId(studentId));

// src/maintenance.ts
async function main() {
  const store = process.env.DB_DRIVER === "postgres-tcp" ? new PgStore() : new HttpStore(), uid = process.argv[2];
  if (!uid) throw new Error("Pass anonymized member UID");
  try {
    const privacy = await store.read("privacy_jobs", uid);
    if (!privacy) throw new Error("No pending privacy job");
    let page = 0;
    for (; ; ) {
      const result = await store.list(
        "import_jobs",
        {},
        { offset: page * 100, limit: 100 }
      );
      for (const job of result.items) {
        if (!job.rows.some(
          (row) => row.uid === uid || row.member && (studentIdKey(row.member.studentId) === privacy.studentIdDigest || digest(row.member.studentId) === privacy.studentIdDigest)
        ))
          continue;
        await store.run(async (tx) => {
          const control = await tx.get(
            "system",
            "control"
          );
          if (!control) throw new Error("Not initialized");
          control.revision++;
          await tx.set("system", "control", control);
          const current = await tx.get("import_jobs", job.id);
          if (!current) return;
          for (const row of current.rows)
            if (row.uid === uid || row.member && (studentIdKey(row.member.studentId) === privacy.studentIdDigest || digest(row.member.studentId) === privacy.studentIdDigest)) {
              delete row.member;
              delete row.uid;
              row.error = "\u4E2A\u4EBA\u8D44\u6599\u5DF2\u6309\u9690\u79C1\u8BF7\u6C42\u6E05\u7406";
            }
          await tx.set("import_jobs", job.id, current);
        });
      }
      if ((page + 1) * 100 >= result.total) break;
      page++;
    }
    await cleanStage3Privacy(store, uid);
    await store.run(async (tx) => {
      await tx.set("privacy_jobs", uid, {
        ...privacy,
        status: "completed",
        completedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    });
    console.log(
      "Privacy job completed; original user profile is already anonymized. Backups and external exports follow their own retention policy."
    );
  } finally {
    if (store instanceof PgStore) await store.pool.end();
  }
}
main().catch(() => {
  console.error(
    "Privacy cleanup failed; verify UID, permissions and configuration. Retry is safe."
  );
  process.exitCode = 1;
});
