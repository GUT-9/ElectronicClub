"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/offline-bootstrap.ts
var offline_bootstrap_exports = {};
__export(offline_bootstrap_exports, {
  generateBootstrapSql: () => generateBootstrapSql
});
module.exports = __toCommonJS(offline_bootstrap_exports);
var import_promises = require("node:fs/promises");
var import_node_path = require("node:path");

// ../../packages/shared/src/student-id.ts
var STUDENT_ID_MESSAGE = "\u5B66\u53F7\u987B\u4E3A4\u201324\u4F4D\u82F1\u6587\u5B57\u6BCD\u6216\u6570\u5B57\uFF0C\u4E0D\u5141\u8BB8\u7A7A\u683C\u6216\u7279\u6B8A\u5B57\u7B26";
function isValidStudentId(value) {
  return typeof value === "string" && value.length >= 4 && value.length <= 24 && !/[^A-Za-z0-9]/.test(value);
}
function normalizeStudentId(value) {
  if (!isValidStudentId(value)) throw new Error(STUDENT_ID_MESSAGE);
  return value.toUpperCase();
}

// ../../packages/shared/src/forum.ts
var FORUM_PERMISSIONS = [
  "forum.boards.manage",
  "forum.posts.review",
  "forum.posts.pin",
  "forum.posts.feature",
  "forum.posts.lock",
  "forum.posts.delete",
  "forum.comments.moderate",
  "forum.reports.manage",
  "forum.users.restrict"
];
var DEFAULT_FORUM_BOARDS = [
  "\u7EFC\u5408\u4EA4\u6D41",
  "\u5355\u7247\u673A\u4E0E\u5D4C\u5165\u5F0F",
  "\u7535\u8DEF\u8BBE\u8BA1\u4E0E PCB",
  "\u710A\u63A5\u4E0E\u7535\u5B50\u5236\u4F5C",
  "\u7535\u8D5B\u4EA4\u6D41",
  "\u9879\u76EE\u5206\u4EAB",
  "\u7F16\u7A0B\u4E0E\u8F6F\u4EF6\u5F00\u53D1"
].map((name, index) => ({
  id: `board-${index + 1}`,
  name,
  description: name === "\u7535\u8D5B\u4EA4\u6D41" ? "\u5168\u56FD\u5927\u5B66\u751F\u7535\u5B50\u8BBE\u8BA1\u7ADE\u8D5B\u5B66\u4E60\u4E0E\u4EA4\u6D41" : "\u5206\u4EAB\u5B9E\u8DF5\u7ECF\u9A8C\uFF0C\u4E00\u8D77\u89E3\u51B3\u95EE\u9898",
  position: index + 1,
  status: "active",
  requireReview: false
}));

// src/members/model.ts
var import_zod = require("zod");
var ApiError = class extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
function ensure(value, status, code, message) {
  if (!value) throw new ApiError(status, code, message);
}
var text = import_zod.z.string().trim().max(100);
var studentIdSchema = import_zod.z.string().refine(isValidStudentId, STUDENT_ID_MESSAGE).transform(normalizeStudentId);
var memberSchema = import_zod.z.object({
  studentId: studentIdSchema,
  name: import_zod.z.string().trim().min(1).max(60),
  gender: import_zod.z.enum(["\u7537", "\u5973", "\u5176\u4ED6", "\u672A\u586B\u5199"]).default("\u672A\u586B\u5199"),
  college: text.default(""),
  major: text.default(""),
  className: text.default(""),
  grade: text.default(""),
  nickname: import_zod.z.string().trim().min(1).max(60).optional(),
  phone: import_zod.z.string().regex(/^[\d+ ()-]{0,30}$/).default(""),
  email: import_zod.z.union([import_zod.z.literal(""), import_zod.z.string().email().max(200)]).default(""),
  avatar: import_zod.z.union([
    import_zod.z.literal(""),
    import_zod.z.string().url().max(500).refine((x) => x.startsWith("https://"), "\u5934\u50CF\u4EC5\u652F\u6301HTTPS\u5730\u5740")
  ]).default(""),
  position: text.default("")
}).strict();
var patchFields = import_zod.z.object({
  studentId: studentIdSchema,
  name: import_zod.z.string().trim().min(1).max(60),
  nickname: import_zod.z.string().trim().min(1).max(60),
  gender: import_zod.z.enum(["\u7537", "\u5973", "\u5176\u4ED6", "\u672A\u586B\u5199"]),
  college: text,
  major: text,
  className: text,
  grade: text,
  phone: import_zod.z.string().regex(/^[\d+ ()-]{0,30}$/),
  email: import_zod.z.union([import_zod.z.literal(""), import_zod.z.string().email().max(200)]),
  avatar: import_zod.z.union([
    import_zod.z.literal(""),
    import_zod.z.string().url().max(500).refine((x) => x.startsWith("https://"))
  ]),
  position: text
});
var profileSchema = patchFields.pick({
  nickname: true,
  gender: true,
  phone: true,
  email: true,
  avatar: true
}).partial().strict();
var editSchema = patchFields.partial().strict();
var passwordSchema = import_zod.z.string().min(8).max(128).refine(
  (x) => /[a-zA-Z]/.test(x) && /\d/.test(x),
  "\u5BC6\u7801\u81F3\u5C118\u4F4D\u4E14\u5305\u542B\u5B57\u6BCD\u548C\u6570\u5B57"
);
var permissionDefinitions = [
  ["members.read", "\u6210\u5458\u67E5\u8BE2", "\u6210\u5458"],
  ["members.create", "\u6210\u5458\u521B\u5EFA", "\u6210\u5458"],
  ["members.edit", "\u8EAB\u4EFD\u8D44\u6599\u7F16\u8F91", "\u6210\u5458"],
  ["members.import", "Excel\u5BFC\u5165", "\u6210\u5458"],
  ["members.export", "\u6210\u5458\u5BFC\u51FA", "\u6210\u5458"],
  ["members.delete", "\u8F6F\u5220\u9664\u4E0E\u6062\u590D", "\u6210\u5458"],
  ["members.password", "\u5BC6\u7801\u91CD\u7F6E", "\u6210\u5458"],
  ["members.status", "\u7981\u7528\u4E0E\u6062\u590D\u8D26\u53F7", "\u6210\u5458"],
  ["roles.read", "\u89D2\u8272\u4E0E\u6743\u9650\u67E5\u8BE2", "\u6743\u9650"],
  ["roles.assign", "\u5206\u914D\u6210\u5458\u89D2\u8272", "\u6743\u9650"],
  ["roles.manage", "\u521B\u5EFA\u53CA\u7BA1\u7406\u89D2\u8272", "\u6743\u9650"],
  ["audit.read", "\u5BA1\u8BA1\u65E5\u5FD7\u67E5\u8BE2", "\u7CFB\u7EDF"],
  ["events.create", "\u521B\u5EFA\u6D3B\u52A8", "\u6D3B\u52A8"],
  ["events.edit", "\u7F16\u8F91\u5168\u90E8\u6D3B\u52A8/\u5206\u914D\u8D1F\u8D23\u4EBA", "\u6D3B\u52A8"],
  ["events.delete", "\u5220\u9664\u6D3B\u52A8", "\u6D3B\u52A8"],
  ["events.registrations.read", "\u67E5\u8BE2\u62A5\u540D\u540D\u5355", "\u6D3B\u52A8"],
  ["events.registrations.review", "\u5BA1\u6838\u62A5\u540D", "\u6D3B\u52A8"],
  ["events.registrations.export", "\u5BFC\u51FA\u62A5\u540D\u540D\u5355", "\u6D3B\u52A8"],
  ["events.checkin.manage", "\u7BA1\u7406\u7B7E\u5230", "\u6D3B\u52A8"],
  ["articles.create", "\u521B\u5EFA\u6587\u7AE0", "\u5185\u5BB9"],
  ["articles.edit", "\u7F16\u8F91\u6587\u7AE0", "\u5185\u5BB9"],
  ["articles.publish", "\u53D1\u5E03/\u64A4\u56DE\u6587\u7AE0", "\u5185\u5BB9"],
  ["articles.delete", "\u5220\u9664\u6587\u7AE0", "\u5185\u5BB9"],
  ["announcements.popup.manage", "\u5168\u7AD9\u5F39\u7A97\u7BA1\u7406", "\u5185\u5BB9"],
  ["forum.boards.manage", "\u7248\u5757\u7BA1\u7406", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.review", "\u5BA1\u6838\u5E16\u5B50", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.pin", "\u5E16\u5B50\u7F6E\u9876", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.feature", "\u5E16\u5B50\u52A0\u7CBE", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.lock", "\u9501\u5E16\u4E0E\u5173\u95ED\u8BC4\u8BBA", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.delete", "\u5220\u9664\u8FDD\u89C4\u5E16\u5B50", "\u7535\u5B50\u793E\u533A"],
  ["forum.comments.moderate", "\u8BC4\u8BBA\u5BA1\u6838", "\u7535\u5B50\u793E\u533A"],
  ["forum.reports.manage", "\u4E3E\u62A5\u5904\u7406", "\u7535\u5B50\u793E\u533A"],
  ["forum.users.restrict", "\u9650\u5236\u793E\u533A\u53D1\u8A00", "\u7535\u5B50\u793E\u533A"],
  ["activities.create", "\u521B\u5EFA\u6D3B\u52A8", "\u540E\u7EED\u4E1A\u52A1"],
  ["activities.manage", "\u7BA1\u7406\u6D3B\u52A8", "\u540E\u7EED\u4E1A\u52A1"],
  ["activities.roster.read", "\u67E5\u770B\u62A5\u540D\u540D\u5355", "\u540E\u7EED\u4E1A\u52A1"],
  ["activities.roster.export", "\u5BFC\u51FA\u62A5\u540D\u540D\u5355", "\u540E\u7EED\u4E1A\u52A1"],
  ["articles.manage", "\u6587\u7AE0\u516C\u544A\u7BA1\u7406", "\u540E\u7EED\u4E1A\u52A1"],
  ["community.moderate", "\u5E16\u5B50\u8BC4\u8BBA\u5BA1\u6838", "\u540E\u7EED\u4E1A\u52A1"],
  ["settings.manage", "\u7CFB\u7EDF\u8BBE\u7F6E", "\u540E\u7EED\u4E1A\u52A1"],
  ["popups.manage", "\u5168\u7AD9\u5F39\u7A97", "\u540E\u7EED\u4E1A\u52A1"]
].map(([id, name, group]) => ({
  id,
  name,
  group,
  implemented: group !== "\u540E\u7EED\u4E1A\u52A1"
}));
var roleSchema = import_zod.z.object({
  name: import_zod.z.string().trim().min(1).max(60),
  description: import_zod.z.string().trim().max(300),
  permissionIds: import_zod.z.array(import_zod.z.string()).max(64).transform((x) => [...new Set(x)])
}).strict();
var listSchema = import_zod.z.object({
  page: import_zod.z.coerce.number().int().min(1).max(1e4).default(1),
  pageSize: import_zod.z.coerce.number().int().min(1).max(100).default(20),
  search: import_zod.z.string().max(100).default(""),
  college: text.default(""),
  className: text.default(""),
  roleId: import_zod.z.string().max(64).default(""),
  status: import_zod.z.enum(["active", "disabled", "deleted", "all"]).default("active")
}).strict();

// src/forum/storage.ts
var IMAGE_STORAGE_KEY = "forum:image-storage";
async function changeImageStorage(tx, delta) {
  const budget = Number(process.env.FORUM_IMAGE_BUDGET_BYTES ?? 33554432);
  ensure(
    Number.isSafeInteger(budget) && budget >= 1024 && budget <= 536870912,
    503,
    "FORUM_STORAGE_CONFIG",
    "\u793E\u533A\u56FE\u7247\u9884\u7B97\u914D\u7F6E\u65E0\u6548"
  );
  const state = await tx.get(
    "system",
    IMAGE_STORAGE_KEY
  ) ?? { bytes: 0 };
  ensure(
    delta <= 0 || state.bytes + delta <= budget,
    409,
    "FORUM_STORAGE_BUDGET",
    "\u793E\u533A\u56FE\u7247\u7A7A\u95F4\u5DF2\u8FBE\u9884\u8BBE\u9884\u7B97\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u6574\u7406"
  );
  await tx.set("system", IMAGE_STORAGE_KEY, {
    bytes: Math.max(0, state.bytes + delta)
  });
}

// src/forum/service.ts
var import_node_crypto2 = require("node:crypto");
var import_zod3 = require("zod");

// src/members/crypto.ts
var import_node_crypto = require("node:crypto");
var digest = (value) => (0, import_node_crypto.createHash)("sha256").update(value).digest("hex");
var randomToken = () => (0, import_node_crypto.randomBytes)(32).toString("base64url");
async function hashPassword(password) {
  const salt = (0, import_node_crypto.randomBytes)(16).toString("hex");
  const key = await derive(password, salt);
  return `scrypt$${salt}$${key.toString("hex")}`;
}
function derive(password, salt) {
  return new Promise(
    (resolve2, reject) => (0, import_node_crypto.scrypt)(
      password,
      salt,
      64,
      { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 },
      (err, key) => err ? reject(err) : resolve2(key)
    )
  );
}
async function verifyPassword(password, hash) {
  const parts = hash.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") {
    await derive(password, "invalid-credential-padding");
    return false;
  }
  const key = await derive(password, parts[1]);
  const expected = Buffer.from(parts[2], "hex");
  return key.length === expected.length && (0, import_node_crypto.timingSafeEqual)(key, expected);
}
var studentIdKey = (studentId) => digest(normalizeStudentId(studentId));

// src/forum/model.ts
var import_zod2 = require("zod");
var boardInput = import_zod2.z.object({
  name: import_zod2.z.string().trim().min(1).max(40),
  description: import_zod2.z.string().trim().max(300).default(""),
  position: import_zod2.z.number().int().min(0).max(1e3).default(0),
  status: import_zod2.z.enum(["active", "hidden", "disabled"]).default("active"),
  requireReview: import_zod2.z.boolean().default(false)
}).strict();
var postInput = import_zod2.z.object({
  title: import_zod2.z.string().trim().min(2).max(120),
  body: import_zod2.z.string().trim().min(2).max(6e3),
  boardId: import_zod2.z.string().min(1).max(60),
  imageIds: import_zod2.z.array(import_zod2.z.string().uuid()).max(3).default([])
}).strict();
var commentInput = import_zod2.z.object({
  body: import_zod2.z.string().trim().min(1).max(1500),
  parentId: import_zod2.z.string().uuid().nullable().default(null)
}).strict();
var moderationInput = import_zod2.z.object({
  action: import_zod2.z.enum([
    "approve",
    "hide",
    "delete",
    "pin",
    "feature",
    "lock",
    "close-comments"
  ]),
  value: import_zod2.z.boolean().default(true),
  reason: import_zod2.z.string().trim().min(1).max(300)
}).strict();
var reasonInput = import_zod2.z.object({ reason: import_zod2.z.string().trim().min(2).max(500) }).strict();
var restrictionInput = import_zod2.z.object({
  studentId: import_zod2.z.string().min(4).max(24),
  posts: import_zod2.z.boolean(),
  comments: import_zod2.z.boolean(),
  postsUntil: import_zod2.z.string().datetime({ offset: true }).nullable(),
  commentsUntil: import_zod2.z.string().datetime({ offset: true }).nullable(),
  reason: import_zod2.z.string().trim().min(2).max(300)
}).strict();
var imageInput = import_zod2.z.object({ dataUrl: import_zod2.z.string().max(45e3) }).strict();

// src/forum/images.ts
var import_node_zlib = require("node:zlib");
var bad = () => {
  throw new ApiError(
    400,
    "INVALID_IMAGE",
    "\u56FE\u7247\u683C\u5F0F\u6216\u6587\u4EF6\u5185\u5BB9\u4E0D\u5408\u6CD5\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u56FE\u7247"
  );
};
function inspectImage(uri) {
  const match = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(uri);
  if (!match) return bad();
  const buffer = Buffer.from(match[2], "base64");
  if (buffer.toString("base64") !== match[2] || buffer.length > 32768 || buffer.length < 20)
    return bad();
  let width = 0, height = 0;
  if (match[1] === "png") {
    if (!buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])))
      return bad();
    let offset = 8, header = false, pixels = false, ended = false, channels = 0;
    const chunks = [];
    while (offset + 12 <= buffer.length) {
      const n = buffer.readUInt32BE(offset), kind = buffer.toString("ascii", offset + 4, offset + 8);
      if (n > buffer.length - offset - 12 || crc32(buffer.subarray(offset + 4, offset + 8 + n)) !== buffer.readUInt32BE(offset + 8 + n))
        return bad();
      if (kind === "IHDR") {
        if (header || offset !== 8 || n !== 13) return bad();
        header = true;
        width = buffer.readUInt32BE(offset + 8);
        height = buffer.readUInt32BE(offset + 12);
        channels = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[buffer[offset + 17]] ?? 0;
        if (buffer[offset + 16] !== 8 || buffer[offset + 18] !== 0 || buffer[offset + 19] !== 0 || buffer[offset + 20] !== 0 || !channels)
          return bad();
      }
      if (kind === "IDAT" && n > 0) {
        pixels = true;
        chunks.push(buffer.subarray(offset + 8, offset + 8 + n));
      }
      if (kind === "IEND") {
        if (n !== 0 || offset + 12 !== buffer.length) return bad();
        ended = true;
      }
      if (kind === "acTL") return bad();
      offset += n + 12;
    }
    if (!header || !pixels || !ended || offset !== buffer.length || width > 2e3 || height > 2e3)
      return bad();
    try {
      const decoded = (0, import_node_zlib.inflateSync)(Buffer.concat(chunks), {
        maxOutputLength: 161e5
      }), stride = width * channels + 1;
      if (decoded.length !== stride * height) return bad();
      for (let row = 0; row < height; row++)
        if (decoded[row * stride] > 4) return bad();
    } catch {
      return bad();
    }
  } else if (match[1] === "jpeg") {
    if (buffer[0] !== 255 || buffer[1] !== 216 || buffer[buffer.length - 2] !== 255 || buffer[buffer.length - 1] !== 217)
      return bad();
    let i = 2, scan = false;
    while (i < buffer.length - 2) {
      if (buffer[i] !== 255) return bad();
      while (buffer[i] === 255) i++;
      const marker = buffer[i++];
      if (marker === 217) return bad();
      if (marker === 0 || marker === 216) return bad();
      if (marker >= 208 && marker <= 215) continue;
      if (i + 2 > buffer.length) return bad();
      const n = buffer.readUInt16BE(i);
      if (n < 2 || i + n > buffer.length) return bad();
      if ([192, 193, 194].includes(marker)) {
        if (n < 8) return bad();
        height = buffer.readUInt16BE(i + 3);
        width = buffer.readUInt16BE(i + 5);
      }
      if (marker === 218) {
        scan = true;
        i += n;
        while (i < buffer.length - 1) {
          if (buffer[i] !== 255) {
            i++;
            continue;
          }
          const next = buffer[i + 1];
          if (next === 0 || next >= 208 && next <= 215) {
            i += 2;
            continue;
          }
          break;
        }
        continue;
      }
      i += n;
    }
    if (!scan || !width || !height) return bad();
  } else {
    if (buffer.toString("ascii", 0, 4) !== "RIFF" || buffer.toString("ascii", 8, 12) !== "WEBP" || buffer.readUInt32LE(4) + 8 !== buffer.length)
      return bad();
    let offset = 12, frame = false;
    while (offset + 8 <= buffer.length) {
      const type = buffer.toString("ascii", offset, offset + 4), n = buffer.readUInt32LE(offset + 4), p = offset + 8;
      if (n > buffer.length - p) return bad();
      if (type === "ANIM" || type === "ANMF") return bad();
      if (type === "VP8X") {
        if (n < 10 || (buffer[p] & 2) !== 0) return bad();
        width = 1 + buffer.readUIntLE(p + 4, 3);
        height = 1 + buffer.readUIntLE(p + 7, 3);
      }
      if (type === "VP8 ") {
        if (n < 10 || !buffer.subarray(p + 3, p + 6).equals(Buffer.from([157, 1, 42])))
          return bad();
        width = buffer.readUInt16LE(p + 6) & 16383;
        height = buffer.readUInt16LE(p + 8) & 16383;
        frame = true;
      }
      if (type === "VP8L") {
        if (n < 5 || buffer[p] !== 47) return bad();
        const bits = buffer.readUInt32LE(p + 1);
        width = 1 + (bits & 16383);
        height = 1 + (bits >>> 14 & 16383);
        frame = true;
      }
      offset = p + n + n % 2;
    }
    if (!frame || offset !== buffer.length) return bad();
  }
  if (!width || !height || width > 2e3 || height > 2e3 || width * height > 4e6)
    return bad();
  return {
    buffer,
    width,
    height,
    mime: "image/" + match[1],
    bytes: buffer.length
  };
}
function crc32(data) {
  let crc = 4294967295;
  for (const byte of data) {
    crc ^= byte;
    for (let n = 0; n < 8; n++)
      crc = crc & 1 ? crc >>> 1 ^ 3988292384 : crc >>> 1;
  }
  return (crc ^ 4294967295) >>> 0;
}

// src/forum/service.ts
var postModeration = [
  "forum.posts.review",
  "forum.posts.pin",
  "forum.posts.feature",
  "forum.posts.lock",
  "forum.posts.delete"
];
var ForumService = class {
  constructor(store, secure, clock = () => Date.now()) {
    this.store = store;
    this.secure = secure;
    this.clock = clock;
  }
  now() {
    return new Date(this.clock()).toISOString();
  }
  can(ctx, p) {
    return !!ctx && (ctx.super || ctx.permissions.includes(p));
  }
  require(ctx, p) {
    ensure(this.can(ctx, p), 403, "FORBIDDEN", "\u6CA1\u6709\u6B64\u793E\u533A\u7BA1\u7406\u6743\u9650");
  }
  member(ctx) {
    ensure(ctx, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
    return ctx;
  }
  async audit(tx, ctx, action, target, details = {}) {
    const id = (0, import_node_crypto2.randomUUID)();
    await tx.set("audit_logs", id, {
      id,
      actor: ctx.member.uid,
      action,
      target,
      details,
      fields: [],
      createdAt: this.now()
    });
  }
  async notify(tx, uid, postId, message, commentId = null) {
    const id = (0, import_node_crypto2.randomUUID)();
    await tx.set("forum_notifications", id, {
      id,
      recipientUid: uid,
      postId,
      commentId,
      message,
      read: false,
      createdAt: this.now()
    });
  }
  async rate(tx, ctx, kind, limit, windowMs) {
    const id = `forum:rate:${ctx.member.uid}:${kind}`;
    let state = await tx.get("system", id);
    if (!state || state.start + windowMs <= this.clock())
      state = { count: 0, start: this.clock() };
    ensure(
      state.count < limit,
      429,
      "FORUM_RATE_LIMIT",
      "\u64CD\u4F5C\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5"
    );
    state.count++;
    await tx.set("system", id, state);
  }
  async allowed(tx, ctx, kind) {
    const r = await tx.get(
      "forum_user_restrictions",
      ctx.member.uid
    );
    const end = kind === "posts" ? r?.postsUntil : r?.commentsUntil;
    ensure(
      !r || !r[kind] || !!end && Date.parse(end) <= this.clock(),
      403,
      "FORUM_RESTRICTED",
      "\u8D26\u53F7\u6682\u65F6\u88AB\u9650\u5236\u6B64\u793E\u533A\u64CD\u4F5C"
    );
  }
  async board(tx, id) {
    const b = await tx.get("forum_boards", id);
    ensure(b, 404, "NOT_FOUND", "\u7248\u5757\u4E0D\u5B58\u5728");
    return { ...b, id };
  }
  async post(tx, id, ctx) {
    const p = await tx.get("forum_posts", id);
    ensure(p && p.status !== "deleted", 404, "NOT_FOUND", "\u5E16\u5B50\u4E0D\u5B58\u5728\u6216\u5DF2\u5220\u9664");
    const board = await this.board(tx, p.boardId);
    const moderation = this.can(ctx, "forum.posts.review") || this.can(ctx, "forum.posts.delete");
    ensure(
      p.status === "published" && board.status !== "hidden" || ctx?.member.uid === p.authorUid || moderation,
      404,
      "NOT_FOUND",
      "\u5E16\u5B50\u4E0D\u5B58\u5728\u6216\u5C1A\u672A\u516C\u5F00"
    );
    return { ...p, id };
  }
  async author(tx, uid) {
    const user = await tx.get("users", uid);
    return {
      uid,
      nickname: user && user.status !== "deleted" ? user.nickname : "\u5DF2\u6CE8\u9500\u6210\u5458",
      avatar: user && user.status === "active" && /^(https:\/\/|data:image\/(png|jpeg|webp);base64,)/.test(user.avatar) ? user.avatar : ""
    };
  }
  async postView(tx, p, ctx) {
    const { moderationReason, ...publicFields } = p;
    return {
      ...publicFields,
      ...ctx?.member.uid === p.authorUid || this.can(ctx, "forum.posts.review") ? { moderationReason } : {},
      author: await this.author(tx, p.authorUid),
      board: await this.board(tx, p.boardId)
    };
  }
  async publicPosts(tx, items, ctx) {
    const values = await Promise.all(
      items.map(async (row) => {
        const current = await tx.get("forum_posts", row.id);
        if (!current || current.status !== "published") return null;
        const board = await this.board(tx, current.boardId);
        if (board.status === "hidden") return null;
        const view = await this.postView(tx, { ...current, id: row.id }, ctx);
        return { ...view, body: view.body.slice(0, 240) };
      })
    );
    return values.filter((value) => value !== null);
  }
  async commentView(tx, c, moderation = false) {
    if (c.status === "deleted" || c.status === "hidden" && !moderation)
      return {
        ...c,
        body: c.status === "deleted" ? "\u8BE5\u8BC4\u8BBA\u5DF2\u5220\u9664" : "\u8BE5\u8BC4\u8BBA\u6682\u4E0D\u53EF\u89C1",
        author: { uid: "", nickname: "", avatar: "" }
      };
    const parent = c.parentId ? await tx.get("forum_comments", c.parentId) : null;
    return {
      ...c,
      author: await this.author(tx, c.authorUid),
      parent: parent ? {
        id: parent.id,
        floor: parent.floor,
        nickname: parent.status === "published" ? (await this.author(tx, parent.authorUid)).nickname : "\u5DF2\u5220\u9664\u6216\u9690\u85CF"
      } : null
    };
  }
  async page(collection, filter, q) {
    const page = import_zod3.z.coerce.number().int().min(1).max(1e4).parse(q.page ?? 1), pageSize = import_zod3.z.coerce.number().int().min(1).max(30).parse(q.pageSize ?? 20);
    return {
      ...await this.store.list(collection, filter, {
        offset: (page - 1) * pageSize,
        limit: pageSize
      }),
      page,
      pageSize
    };
  }
  async attach(tx, ctx, postId, ids) {
    ensure(
      new Set(ids).size === ids.length,
      400,
      "DUPLICATE_IMAGE",
      "\u56FE\u7247\u4E0D\u80FD\u91CD\u590D"
    );
    for (const id of ids) {
      const image2 = await tx.get("forum_images", id);
      ensure(
        image2 && image2.ownerUid === ctx.member.uid && (!image2.postId || image2.postId === postId),
        403,
        "IMAGE_SCOPE",
        "\u56FE\u7247\u4E0D\u5C5E\u4E8E\u5F53\u524D\u6210\u5458\u6216\u5DF2\u7528\u4E8E\u5176\u4ED6\u5E16\u5B50"
      );
      await tx.set("forum_images", id, { ...image2, postId, status: "attached" });
    }
  }
  async execute(token, method, path, input, q) {
    const parts = path.slice("/api/forum".length).split("/").filter(Boolean), [kind, id, action] = parts;
    const publicRead = method === "GET" && ["boards", "posts", "images"].includes(kind ?? "") && q.admin !== "true";
    const work = async (tx, ctx) => {
      if (kind === "boards") {
        if (method === "GET") {
          if (q.admin === "true") this.require(ctx, "forum.boards.manage");
          if (id) {
            const board2 = await this.board(tx, id);
            ensure(
              board2.status !== "hidden" || this.can(ctx, "forum.boards.manage"),
              404,
              "NOT_FOUND",
              "\u7248\u5757\u4E0D\u5B58\u5728"
            );
            return { data: board2 };
          }
          return {
            data: await this.page(
              "forum_boards",
              q.admin === "true" ? {} : { _public: true },
              q
            )
          };
        }
        ensure(method === "POST", 404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
        this.require(ctx, "forum.boards.manage");
        const data = boardInput.parse(input), now = this.now(), previous = id ? await this.board(tx, id) : null;
        const board = {
          ...data,
          id: id ?? (0, import_node_crypto2.randomUUID)(),
          createdAt: previous?.createdAt ?? now,
          updatedAt: now
        };
        await tx.set("forum_boards", board.id, board);
        await this.audit(tx, ctx, "forum.boards.save", board.id, {
          status: board.status,
          requireReview: board.requireReview
        });
        return { data: board };
      }
      if (kind === "images") {
        if (method === "POST" && !id) {
          const user = this.member(ctx);
          await this.allowed(tx, user, "posts");
          await this.rate(tx, user, "images", 6, 6e5);
          const pending = await this.store.list(
            "forum_images",
            { ownerUid: user.member.uid, status: "staged" },
            { offset: 0, limit: 1 }
          );
          ensure(
            pending.total < 6,
            409,
            "IMAGE_QUOTA",
            "\u672A\u4F7F\u7528\u56FE\u7247\u8FC7\u591A\uFF0C\u8BF7\u5148\u53D1\u5E03\u5E16\u5B50\u6216\u79FB\u9664\u672A\u4F7F\u7528\u56FE\u7247"
          );
          const data = imageInput.parse(input), image3 = inspectImage(data.dataUrl);
          const record = {
            id: (0, import_node_crypto2.randomUUID)(),
            ownerUid: user.member.uid,
            postId: null,
            dataUrl: data.dataUrl,
            mime: image3.mime,
            width: image3.width,
            height: image3.height,
            bytes: image3.bytes,
            status: "staged",
            createdAt: this.now()
          };
          await changeImageStorage(tx, record.dataUrl.length);
          await tx.set("forum_images", record.id, record);
          return {
            data: {
              id: record.id,
              width: record.width,
              height: record.height,
              bytes: record.bytes
            }
          };
        }
        if (method === "POST" && id && action === "delete") {
          const user = this.member(ctx), image3 = await tx.get("forum_images", id);
          ensure(
            image3 && image3.ownerUid === user.member.uid && image3.status === "staged",
            403,
            "IMAGE_SCOPE",
            "\u53EA\u80FD\u79FB\u9664\u672C\u4EBA\u672A\u53D1\u5E03\u7684\u56FE\u7247"
          );
          await tx.remove("forum_images", id);
          await changeImageStorage(tx, -image3.dataUrl.length);
          return { data: { ok: true } };
        }
        ensure(method === "GET" && id, 404, "NOT_FOUND", "\u56FE\u7247\u4E0D\u5B58\u5728");
        const image2 = await tx.get("forum_images", id);
        ensure(image2, 404, "NOT_FOUND", "\u56FE\u7247\u4E0D\u5B58\u5728");
        if (image2.postId) {
          const post = await this.post(tx, image2.postId, ctx);
          ensure(
            post.imageIds.includes(id),
            404,
            "NOT_FOUND",
            "\u56FE\u7247\u5DF2\u4ECE\u5E16\u5B50\u79FB\u9664"
          );
        } else
          ensure(
            ctx?.member.uid === image2.ownerUid,
            404,
            "NOT_FOUND",
            "\u56FE\u7247\u5C1A\u672A\u53D1\u5E03"
          );
        ensure(
          ["image/jpeg", "image/png", "image/webp"].includes(image2.mime),
          404,
          "NOT_FOUND",
          "\u56FE\u7247\u4E0D\u5B58\u5728"
        );
        const buffer = Buffer.from(image2.dataUrl.split(",")[1] ?? "", "base64");
        ensure(
          buffer.length <= 32768 && buffer.length === image2.bytes,
          404,
          "NOT_FOUND",
          "\u56FE\u7247\u6570\u636E\u4E0D\u5B8C\u6574"
        );
        return { binary: buffer, contentType: image2.mime };
      }
      if (kind === "posts" && !id && method === "GET") {
        const filter = { _public: true };
        if (q.boardId) filter.boardId = import_zod3.z.string().max(60).parse(q.boardId);
        if (q.search) filter._search = import_zod3.z.string().max(80).parse(q.search);
        const sort = import_zod3.z.enum(["latest", "reply", "hot", "featured"]).parse(q.sort ?? "latest");
        filter._sort = sort;
        if (sort === "featured") filter._featured = true;
        const result = await this.page("forum_posts", filter, q);
        return {
          data: {
            ...result,
            items: await this.publicPosts(tx, result.items, ctx)
          }
        };
      }
      if (kind === "posts" && !id && method === "POST") {
        const user = this.member(ctx);
        await this.allowed(tx, user, "posts");
        await this.rate(tx, user, "post-cooldown", 1, 3e4);
        await this.rate(tx, user, "post-hour", 10, 36e5);
        const data = postInput.parse(input), board = await this.board(tx, data.boardId);
        ensure(
          board.status === "active",
          409,
          "BOARD_DISABLED",
          "\u6B64\u7248\u5757\u6682\u4E0D\u63A5\u53D7\u65B0\u5E16"
        );
        const now = this.now();
        const p = {
          ...data,
          id: (0, import_node_crypto2.randomUUID)(),
          authorUid: user.member.uid,
          status: board.requireReview ? "pending" : "published",
          pinned: false,
          featured: false,
          locked: false,
          commentsClosed: false,
          viewCount: 0,
          likeCount: 0,
          commentCount: 0,
          commentSequence: 0,
          lastReplyAt: now,
          createdAt: now,
          updatedAt: now
        };
        await tx.set("forum_posts", p.id, p);
        await this.attach(tx, user, p.id, p.imageIds);
        await this.audit(tx, user, "forum.posts.create", p.id);
        return { data: await this.postView(tx, p, user) };
      }
      if (kind === "posts" && id) {
        const post = await this.post(tx, id, ctx);
        if (method === "GET" && !action)
          return { data: await this.postView(tx, post, ctx) };
        if (action === "comments" && method === "GET") {
          if (q.anchor) {
            const anchor = await tx.get(
              "forum_comments",
              q.anchor
            );
            ensure(
              anchor && anchor.postId === id && ["published", "deleted"].includes(anchor.status),
              404,
              "NOT_FOUND",
              "\u56DE\u590D\u5DF2\u9690\u85CF\u6216\u4E0D\u5B58\u5728"
            );
            const before = await this.store.list(
              "forum_comments",
              { postId: id, _public: true, _beforeFloor: String(anchor.floor) },
              { offset: 0, limit: 1 }
            );
            q = {
              ...q,
              page: String(1 + Math.floor(before.total / 20)),
              pageSize: "20"
            };
          }
          const result = await this.page(
            "forum_comments",
            {
              postId: id,
              ...post.status === "published" ? { _public: true } : { status: "published" }
            },
            q
          );
          return {
            data: {
              ...result,
              items: (await Promise.all(
                result.items.map(async (c) => {
                  const current = await tx.get(
                    "forum_comments",
                    c.id
                  );
                  return current && ["published", "deleted"].includes(current.status) ? this.commentView(tx, { ...current, id: c.id }) : null;
                })
              )).filter((value) => value !== null)
            }
          };
        }
        const user = this.member(ctx);
        if (action === "state" && method === "GET") {
          return {
            data: {
              liked: !!await tx.get(
                "forum_likes",
                `${id}:${user.member.uid}`
              ),
              favorited: !!await tx.get(
                "forum_favorites",
                `${id}:${user.member.uid}`
              ),
              own: post.authorUid === user.member.uid
            }
          };
        }
        if (action === "view" && method === "POST") {
          const key = `forum:view:${id}:${user.member.uid}`, last = await tx.get("system", key);
          if (!last || last.at + 864e5 <= this.clock()) {
            post.viewCount++;
            await tx.set("system", key, { at: this.clock() });
            await tx.set("forum_posts", id, post);
          }
          return { data: { viewCount: post.viewCount } };
        }
        if (action === "update" && method === "POST") {
          ensure(
            post.authorUid === user.member.uid,
            403,
            "FORBIDDEN",
            "\u53EA\u80FD\u7F16\u8F91\u672C\u4EBA\u5E16\u5B50"
          );
          ensure(!post.locked, 409, "POST_LOCKED", "\u5E16\u5B50\u5DF2\u9501\u5B9A");
          await this.allowed(tx, user, "posts");
          await this.rate(tx, user, "post-edit", 5, 6e4);
          const data = postInput.parse(input), board = await this.board(tx, data.boardId);
          ensure(board.status === "active", 409, "BOARD_DISABLED", "\u7248\u5757\u5DF2\u505C\u7528");
          await this.attach(tx, user, id, data.imageIds);
          const next = {
            ...post,
            ...data,
            status: board.requireReview || post.status === "hidden" || post.status === "pending" ? "pending" : "published",
            updatedAt: this.now()
          };
          await tx.set("forum_posts", id, next);
          for (const removed of post.imageIds.filter(
            (v) => !data.imageIds.includes(v)
          )) {
            const old = await tx.get("forum_images", removed);
            if (old) {
              await tx.remove("forum_images", removed);
              await changeImageStorage(tx, -old.dataUrl.length);
            }
          }
          await this.audit(tx, user, "forum.posts.edit", id);
          return { data: await this.postView(tx, next, user) };
        }
        if (action === "delete" && method === "POST") {
          ensure(
            post.authorUid === user.member.uid,
            403,
            "FORBIDDEN",
            "\u53EA\u80FD\u5220\u9664\u672C\u4EBA\u5E16\u5B50"
          );
          await tx.set("forum_posts", id, {
            ...post,
            status: "deleted",
            updatedAt: this.now()
          });
          await this.audit(tx, user, "forum.posts.delete-own", id);
          return { data: { ok: true } };
        }
        if (action === "comments" && method === "POST") {
          ensure(
            post.status === "published" && !post.locked && !post.commentsClosed,
            409,
            "COMMENTS_CLOSED",
            "\u5E16\u5B50\u672A\u516C\u5F00\u3001\u5DF2\u9501\u5B9A\u6216\u5DF2\u5173\u95ED\u8BC4\u8BBA"
          );
          const board = await this.board(tx, post.boardId);
          ensure(
            board.status === "active",
            409,
            "BOARD_DISABLED",
            "\u7248\u5757\u6682\u4E0D\u63A5\u53D7\u8BC4\u8BBA"
          );
          await this.allowed(tx, user, "comments");
          await this.rate(tx, user, "comment-cooldown", 1, 5e3);
          await this.rate(tx, user, "comment-hour", 60, 36e5);
          const data = commentInput.parse(input), parent = data.parentId ? await tx.get("forum_comments", data.parentId) : null;
          if (data.parentId)
            ensure(
              parent && parent.postId === id && parent.status === "published",
              400,
              "INVALID_PARENT",
              "\u56DE\u590D\u76EE\u6807\u4E0D\u5C5E\u4E8E\u6B64\u5E16\u6216\u5DF2\u5220\u9664"
            );
          post.commentSequence++;
          post.commentCount++;
          post.lastReplyAt = this.now();
          const comment = {
            ...data,
            id: (0, import_node_crypto2.randomUUID)(),
            postId: id,
            authorUid: user.member.uid,
            status: "published",
            floor: post.commentSequence,
            createdAt: this.now(),
            updatedAt: this.now()
          };
          await tx.set("forum_posts", id, post);
          await tx.set("forum_comments", comment.id, comment);
          const recipients = /* @__PURE__ */ new Set([post.authorUid, parent?.authorUid]);
          for (const uid of recipients)
            if (uid && uid !== user.member.uid)
              await this.notify(
                tx,
                uid,
                id,
                parent?.authorUid === uid ? "\u6709\u4EBA\u56DE\u590D\u4E86\u4F60\u7684\u8BC4\u8BBA" : "\u6709\u4EBA\u56DE\u590D\u4E86\u4F60\u7684\u5E16\u5B50",
                comment.id
              );
          await this.audit(tx, user, "forum.comments.create", comment.id);
          return { data: await this.commentView(tx, comment) };
        }
        if (["like", "favorite"].includes(action ?? "") && method === "POST") {
          ensure(
            post.status === "published",
            409,
            "POST_NOT_PUBLIC",
            "\u5E16\u5B50\u5C1A\u672A\u516C\u5F00"
          );
          await this.rate(tx, user, "reactions", 30, 6e4);
          const data = import_zod3.z.object({ active: import_zod3.z.boolean() }).strict().parse(input), collection = action === "like" ? "forum_likes" : "forum_favorites", key = `${id}:${user.member.uid}`, exists = await tx.get(collection, key);
          if (data.active && !exists) {
            await tx.set(collection, key, {
              id: key,
              postId: id,
              uid: user.member.uid,
              createdAt: this.now()
            });
            if (action === "like") post.likeCount++;
          }
          if (!data.active && exists) {
            await tx.remove(collection, key);
            if (action === "like")
              post.likeCount = Math.max(0, post.likeCount - 1);
          }
          if (action === "like") await tx.set("forum_posts", id, post);
          return { data: { active: data.active, likeCount: post.likeCount } };
        }
        if (action === "moderate" && method === "POST") {
          const data = moderationInput.parse(input), permission = {
            approve: "forum.posts.review",
            hide: "forum.posts.review",
            delete: "forum.posts.delete",
            pin: "forum.posts.pin",
            feature: "forum.posts.feature",
            lock: "forum.posts.lock",
            "close-comments": "forum.posts.lock"
          }[data.action];
          this.require(user, permission);
          if (data.action === "approve") post.status = "published";
          if (data.action === "hide")
            post.status = data.value ? "hidden" : "published";
          if (data.action === "delete") post.status = "deleted";
          if (data.action === "pin") post.pinned = data.value;
          if (data.action === "feature") post.featured = data.value;
          if (data.action === "lock") post.locked = data.value;
          if (data.action === "close-comments") post.commentsClosed = data.value;
          post.moderationReason = data.reason;
          post.updatedAt = this.now();
          await tx.set("forum_posts", id, post);
          await this.audit(tx, user, "forum.posts." + data.action, id, {
            reason: data.reason,
            value: data.value
          });
          await this.notify(
            tx,
            post.authorUid,
            id,
            "\u4F60\u7684\u5E16\u5B50\u5DF2\u88AB\u7BA1\u7406\u5458\u5904\u7406\uFF1A" + data.reason
          );
          return { data: await this.postView(tx, post, user) };
        }
      }
      if (kind === "comments" && id && method === "POST") {
        const user = this.member(ctx), comment = await tx.get("forum_comments", id);
        ensure(comment, 404, "NOT_FOUND", "\u8BC4\u8BBA\u4E0D\u5B58\u5728");
        const post = await this.post(tx, comment.postId, user);
        if (action === "delete") {
          ensure(
            comment.authorUid === user.member.uid,
            403,
            "FORBIDDEN",
            "\u53EA\u80FD\u5220\u9664\u672C\u4EBA\u8BC4\u8BBA"
          );
          if (comment.status === "published")
            post.commentCount = Math.max(0, post.commentCount - 1);
          comment.status = "deleted";
          await this.audit(tx, user, "forum.comments.delete-own", id);
        } else if (action === "moderate") {
          this.require(user, "forum.comments.moderate");
          const data = import_zod3.z.object({
            status: import_zod3.z.enum(["published", "hidden", "deleted"]),
            reason: import_zod3.z.string().trim().min(1).max(300)
          }).strict().parse(input);
          if (comment.status === "published" && data.status !== "published")
            post.commentCount = Math.max(0, post.commentCount - 1);
          ensure(
            comment.status !== "deleted" || data.status === "deleted",
            409,
            "COMMENT_DELETED",
            "\u5DF2\u5220\u9664\u8BC4\u8BBA\u4E0D\u80FD\u91CD\u65B0\u516C\u5F00"
          );
          if (comment.status !== "published" && data.status === "published")
            post.commentCount++;
          comment.status = data.status;
          await this.audit(tx, user, "forum.comments." + data.status, id, {
            reason: data.reason,
            status: data.status
          });
          await this.notify(
            tx,
            comment.authorUid,
            post.id,
            "\u4F60\u7684\u8BC4\u8BBA\u5DF2\u88AB\u7BA1\u7406\u5458\u5904\u7406\uFF1A" + data.reason,
            id
          );
        } else return this.notFound();
        comment.updatedAt = this.now();
        await tx.set("forum_comments", id, comment);
        await tx.set("forum_posts", post.id, post);
        return { data: { ok: true } };
      }
      if (kind === "reports" && method === "POST") {
        const user = this.member(ctx);
        if (!id) {
          await this.rate(tx, user, "reports", 5, 864e5);
          const data2 = import_zod3.z.object({
            targetType: import_zod3.z.enum(["post", "comment"]),
            targetId: import_zod3.z.string().uuid(),
            reason: reasonInput.shape.reason
          }).strict().parse(input);
          let postId = data2.targetId;
          if (data2.targetType === "comment") {
            const c = await tx.get(
              "forum_comments",
              data2.targetId
            );
            ensure(
              c && c.status === "published",
              404,
              "NOT_FOUND",
              "\u8BC4\u8BBA\u4E0D\u5B58\u5728"
            );
            postId = c.postId;
          }
          await this.post(tx, postId, user);
          const r2 = {
            ...data2,
            id: (0, import_node_crypto2.randomUUID)(),
            reporterUid: user.member.uid,
            postId,
            status: "open",
            resolution: "",
            createdAt: this.now(),
            updatedAt: this.now()
          };
          await tx.set("forum_reports", r2.id, r2);
          await this.audit(tx, user, "forum.reports.create", r2.id);
          return { data: r2 };
        }
        this.require(user, "forum.reports.manage");
        const data = import_zod3.z.object({
          status: import_zod3.z.enum(["resolved", "dismissed"]),
          resolution: import_zod3.z.string().trim().min(2).max(500)
        }).strict().parse(input), r = await tx.get("forum_reports", id);
        ensure(r, 404, "NOT_FOUND", "\u4E3E\u62A5\u4E0D\u5B58\u5728");
        ensure(r.status === "open", 409, "REPORT_CLOSED", "\u4E3E\u62A5\u5DF2\u5904\u7406");
        await tx.set("forum_reports", id, {
          ...r,
          ...data,
          updatedAt: this.now()
        });
        await this.audit(tx, user, "forum.reports." + data.status, id, {
          status: data.status,
          resolution: data.resolution
        });
        await this.notify(
          tx,
          r.reporterUid,
          r.postId,
          "\u4F60\u7684\u4E3E\u62A5\u5DF2\u5904\u7406\uFF1A" + data.resolution
        );
        return { data: { ok: true } };
      }
      if (kind === "restrictions") {
        const user = this.member(ctx);
        this.require(user, "forum.users.restrict");
        if (method === "GET")
          return { data: await this.page("forum_user_restrictions", {}, q) };
        ensure(method === "POST", 404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
        const data = restrictionInput.parse(input), studentId = studentIdSchema.parse(data.studentId), mapping = await tx.get(
          "student_ids",
          studentIdKey(studentId)
        );
        ensure(mapping, 404, "NOT_FOUND", "\u6210\u5458\u4E0D\u5B58\u5728");
        const target = await tx.get("users", mapping.uid);
        ensure(
          target?.status === "active",
          409,
          "INACTIVE_MEMBER",
          "\u6210\u5458\u8D26\u53F7\u4E0D\u662F\u6B63\u5E38\u72B6\u6001"
        );
        const { studentId: _sid, ...fields } = data;
        void _sid;
        const previous = await tx.get(
          "forum_user_restrictions",
          mapping.uid
        );
        const record = {
          ...fields,
          id: mapping.uid,
          uid: mapping.uid,
          createdAt: previous?.createdAt ?? this.now(),
          updatedAt: this.now()
        };
        await tx.set("forum_user_restrictions", mapping.uid, record);
        await this.audit(tx, user, "forum.users.restrict", mapping.uid, {
          posts: data.posts,
          comments: data.comments,
          reason: data.reason
        });
        return { data: record };
      }
      if (kind === "me") {
        const user = this.member(ctx);
        if (id === "notifications" && action && method === "POST") {
          const n = await tx.get(
            "forum_notifications",
            action
          );
          ensure(
            n && n.recipientUid === user.member.uid,
            404,
            "NOT_FOUND",
            "\u901A\u77E5\u4E0D\u5B58\u5728"
          );
          await tx.set("forum_notifications", action, { ...n, read: true });
          return { data: { ok: true } };
        }
        ensure(method === "GET", 404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
        if (id === "posts") {
          const result = await this.page(
            "forum_posts",
            { authorUid: user.member.uid, _notDeleted: true },
            q
          );
          return {
            data: {
              ...result,
              items: await Promise.all(
                result.items.map(
                  (p) => this.postView(tx, p, user)
                )
              )
            }
          };
        }
        if (id === "comments") {
          const result = await this.page(
            "forum_comments",
            { authorUid: user.member.uid, _notDeleted: true },
            q
          );
          return {
            data: {
              ...result,
              items: await Promise.all(
                result.items.map(
                  (c) => this.commentView(tx, c)
                )
              )
            }
          };
        }
        if (id === "favorites") {
          const result = await this.page(
            "forum_posts",
            { _favoriteUid: user.member.uid, _public: true },
            q
          );
          return {
            data: {
              ...result,
              items: await Promise.all(
                result.items.map(
                  (p) => this.postView(tx, p, user)
                )
              )
            }
          };
        }
        if (id === "notifications")
          return {
            data: await this.page(
              "forum_notifications",
              { recipientUid: user.member.uid },
              q
            )
          };
        if (id === "reports")
          return {
            data: await this.page(
              "forum_reports",
              { reporterUid: user.member.uid },
              q
            )
          };
        if (id === "restrictions")
          return {
            data: await tx.get("forum_user_restrictions", user.member.uid)
          };
      }
      if (kind === "admin" && method === "GET") {
        const user = this.member(ctx);
        if (id === "posts") {
          ensure(
            postModeration.some((p) => this.can(user, p)),
            403,
            "FORBIDDEN",
            "\u6CA1\u6709\u5E16\u5B50\u7BA1\u7406\u6743\u9650"
          );
          const filter = {};
          if (!this.can(user, "forum.posts.review") && !this.can(user, "forum.posts.delete"))
            filter._public = true;
          if (q.status)
            filter.status = import_zod3.z.enum(["pending", "published", "hidden", "deleted"]).parse(q.status);
          if (q.search) filter._search = import_zod3.z.string().max(80).parse(q.search);
          const result = await this.page("forum_posts", filter, q);
          return {
            data: {
              ...result,
              items: await Promise.all(
                result.items.map(
                  (p) => this.postView(tx, p, user)
                )
              )
            }
          };
        }
        if (id === "comments") {
          this.require(user, "forum.comments.moderate");
          return {
            data: await this.page(
              "forum_comments",
              q.postId ? { postId: q.postId } : {},
              q
            )
          };
        }
        if (id === "reports") {
          this.require(user, "forum.reports.manage");
          return {
            data: await this.page(
              "forum_reports",
              q.status ? {
                status: import_zod3.z.enum(["open", "resolved", "dismissed"]).parse(q.status)
              } : {},
              q
            )
          };
        }
        if (id === "audit") {
          ensure(
            FORUM_PERMISSIONS.some((p) => this.can(user, p)),
            403,
            "FORBIDDEN",
            "\u6CA1\u6709\u5BA1\u6838\u8BB0\u5F55\u6743\u9650"
          );
          const result = await this.page("audit_logs", { _forumAudit: true }, q);
          const items = result.items.map((row) => {
            const required = row.action.startsWith("forum.users.") ? "forum.users.restrict" : row.action.startsWith("forum.reports.") ? "forum.reports.manage" : row.action.startsWith("forum.comments.") ? "forum.comments.moderate" : row.action.startsWith("forum.boards.") ? "forum.boards.manage" : row.action === "forum.posts.pin" ? "forum.posts.pin" : row.action === "forum.posts.feature" ? "forum.posts.feature" : [
              "forum.posts.lock",
              "forum.posts.close-comments"
            ].includes(row.action) ? "forum.posts.lock" : "forum.posts.review";
            return this.can(user, required) ? row : { ...row, details: void 0 };
          });
          return { data: { ...result, items } };
        }
      }
      return this.notFound();
    };
    if (publicRead && !token) return this.store.run((tx) => work(tx));
    try {
      return await this.secure(token, (tx, ctx) => work(tx, ctx));
    } catch (error) {
      if (publicRead && error.status === 401)
        return this.store.run((tx) => work(tx));
      throw error;
    }
  }
  notFound() {
    ensure(false, 404, "NOT_FOUND", "\u793E\u533A\u63A5\u53E3\u4E0D\u5B58\u5728");
  }
};

// src/stage3/service.ts
var import_node_crypto3 = require("node:crypto");
var import_zod5 = require("zod");

// src/members/xlsx.ts
var import_exceljs = __toESM(require("exceljs"));
var import_yauzl = require("yauzl");
var columns = ["\u5B66\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u5B66\u9662", "\u4E13\u4E1A", "\u73ED\u7EA7", "\u5E74\u7EA7"];
async function validateZip(buffer) {
  ensure(buffer.length <= 2e6, 413, "FILE_TOO_LARGE", "\u6587\u4EF6\u6700\u59272MB");
  await new Promise(
    (resolve2, reject) => (0, import_yauzl.fromBuffer)(buffer, { lazyEntries: true }, (error, zip) => {
      if (error || !zip) return reject(new Error("\u65E0\u6548\u7684 XLSX \u538B\u7F29\u6587\u4EF6"));
      let size = 0, count = 0, ended = false, actualSize = 0;
      const fail = () => {
        if (!ended) {
          ended = true;
          zip.close();
          reject(new Error("XLSX \u89E3\u538B\u6570\u636E\u8FC7\u5927\u6216\u683C\u5F0F\u5F02\u5E38"));
        }
      };
      zip.on("error", fail);
      zip.on("entry", (entry) => {
        size += entry.uncompressedSize;
        count++;
        if (size > 2e7 || count > 2e3 || entry.fileName.includes("..") || entry.generalPurposeBitFlag & 1)
          fail();
        else
          zip.openReadStream(entry, (err, stream) => {
            if (err || !stream) {
              fail();
              return;
            }
            stream.on("data", (chunk) => {
              actualSize += chunk.length;
              if (actualSize > 2e7) {
                stream.destroy();
                fail();
              }
            });
            stream.on("error", fail);
            stream.on("end", () => {
              if (!ended) zip.readEntry();
            });
          });
      });
      zip.on("end", () => {
        if (!ended) {
          ended = true;
          resolve2();
        }
      });
      zip.readEntry();
    })
  );
}
async function parseWorkbook(buffer) {
  try {
    await validateZip(buffer);
  } catch {
    ensure(false, 400, "INVALID_XLSX", "\u6587\u4EF6\u65E0\u6548\u6216\u89E3\u538B\u4F53\u79EF\u8D85\u8FC720MB");
  }
  const workbook = new import_exceljs.default.Workbook();
  try {
    await workbook.xlsx.load(buffer);
  } catch {
    ensure(false, 400, "INVALID_XLSX", "\u65E0\u6CD5\u89E3\u6790XLSX\u6587\u4EF6");
  }
  const sheet = workbook.worksheets[0];
  ensure(sheet, 400, "NO_SHEET", "\u6587\u4EF6\u6CA1\u6709\u5DE5\u4F5C\u8868");
  ensure(
    columns.every(
      (name, index) => sheet.getRow(1).getCell(index + 1).text === name
    ),
    400,
    "INVALID_COLUMNS",
    "\u8868\u5934\u987B\u4E3A\uFF1A" + columns.join("\u3001")
  );
  ensure(
    sheet.rowCount <= 1001,
    413,
    "TOO_MANY_ROWS",
    "\u6BCF\u6587\u4EF6\u6700\u591A1000\u884C\uFF0C\u8BF7\u5206\u6587\u4EF6\u5BFC\u5165"
  );
  const rows = [];
  const seen = /* @__PURE__ */ new Set();
  for (let line = 2; line <= sheet.rowCount; line++) {
    const row = sheet.getRow(line);
    if (row.actualCellCount === 0 || columns.every((_, i) => !row.getCell(i + 1).text.trim()))
      continue;
    if (typeof row.getCell(1).value !== "string") {
      rows.push({
        line,
        error: "\u5B66\u53F7\u5FC5\u987B\u4E3A\u6587\u672C\u5355\u5143\u683C\uFF1B\u6570\u5B57\u6216\u79D1\u5B66\u8BA1\u6570\u6CD5\u65E0\u6CD5\u53EF\u9760\u6062\u590D\uFF0C\u8BF7\u91CD\u65B0\u586B\u5199\u6A21\u677F"
      });
      continue;
    }
    const values = {};
    let invalid = false;
    for (const [index, key] of [
      "studentId",
      "name",
      "gender",
      "college",
      "major",
      "className",
      "grade"
    ].entries()) {
      const cell = row.getCell(index + 1);
      if (typeof cell.value === "object" && cell.value !== null) {
        invalid = true;
        break;
      }
      values[key] = key === "studentId" ? cell.text : cell.text.trim();
    }
    if (invalid) {
      rows.push({ line, error: "\u4E0D\u652F\u6301\u516C\u5F0F\u3001\u8D85\u94FE\u63A5\u6216\u5BCC\u6587\u672C\u5355\u5143\u683C" });
      continue;
    }
    if (!values.gender) values.gender = "\u672A\u586B\u5199";
    const parsed = memberSchema.safeParse(values);
    if (!parsed.success) {
      rows.push({
        line,
        error: parsed.error.issues.map((e) => `${e.path.join(".")}: ${e.message}`).join("\uFF1B")
      });
      continue;
    }
    const member = {
      studentId: parsed.data.studentId,
      name: parsed.data.name,
      gender: parsed.data.gender,
      college: parsed.data.college,
      major: parsed.data.major,
      className: parsed.data.className,
      grade: parsed.data.grade
    };
    const duplicate = seen.has(member.studentId);
    seen.add(member.studentId);
    rows.push({
      line,
      member,
      ...duplicate ? { error: "\u6587\u4EF6\u5185\u5B66\u53F7\u91CD\u590D" } : {}
    });
  }
  ensure(rows.length > 0, 400, "EMPTY_FILE", "\u6CA1\u6709\u53EF\u5BFC\u5165\u7684\u6570\u636E\u884C");
  return rows;
}
async function exportWorkbook(headers, rows) {
  const book = new import_exceljs.default.Workbook();
  const sheet = book.addWorksheet("\u6570\u636E");
  sheet.addRow(headers);
  sheet.columns = headers.map(() => ({ width: 24, style: { numFmt: "@" } }));
  for (const row of rows) sheet.addRow(row);
  return Buffer.from(await book.xlsx.writeBuffer());
}

// src/stage3/model.ts
var import_zod4 = require("zod");
var text2 = import_zod4.z.string().trim();
var image = import_zod4.z.string().max(15e5).refine(
  (v) => !v || /^https:\/\/[^\s]+$/i.test(v) || /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v),
  "\u56FE\u7247\u987B\u4E3AHTTPS\u5730\u5740\u6216PNG/JPEG/WebP\u56FE\u7247"
);
var date = import_zod4.z.string().datetime({ offset: true }).transform((v) => new Date(v).toISOString());
var optionalDate = import_zod4.z.union([date, import_zod4.z.literal("")]).default("");
var eventSchema = import_zod4.z.object({
  title: text2.min(1).max(120),
  summary: text2.max(500).default(""),
  content: import_zod4.z.string().max(1e5).default(""),
  cover: image.default(""),
  location: text2.max(200).default(""),
  startsAt: date,
  endsAt: date,
  status: import_zod4.z.enum(["draft", "published", "disabled"]).default("draft"),
  registrationEnabled: import_zod4.z.boolean().default(false),
  registrationStartsAt: optionalDate,
  registrationDeadline: optionalDate,
  capacity: import_zod4.z.number().int().min(1).max(1e5).nullable().default(null),
  allowCancellation: import_zod4.z.boolean().default(true),
  approvalRequired: import_zod4.z.boolean().default(false),
  notesEnabled: import_zod4.z.boolean().default(false),
  notesRequired: import_zod4.z.boolean().default(false),
  checkinEnabled: import_zod4.z.boolean().default(false),
  managerIds: import_zod4.z.array(import_zod4.z.string().uuid()).max(30).default([])
}).strict().superRefine((v, ctx) => {
  if (v.endsAt <= v.startsAt)
    ctx.addIssue({ code: "custom", message: "\u7ED3\u675F\u65F6\u95F4\u987B\u665A\u4E8E\u5F00\u59CB\u65F6\u95F4" });
  if (v.registrationEnabled && (!v.registrationDeadline || v.registrationDeadline > v.endsAt))
    ctx.addIssue({
      code: "custom",
      message: "\u5F00\u542F\u62A5\u540D\u5FC5\u987B\u8BBE\u7F6E\u4E0D\u665A\u4E8E\u6D3B\u52A8\u7ED3\u675F\u7684\u622A\u6B62\u65F6\u95F4"
    });
  if (v.registrationStartsAt && v.registrationDeadline && v.registrationStartsAt >= v.registrationDeadline)
    ctx.addIssue({ code: "custom", message: "\u62A5\u540D\u5F00\u59CB\u987B\u65E9\u4E8E\u622A\u6B62" });
  if (v.notesRequired && !v.notesEnabled)
    ctx.addIssue({ code: "custom", message: "\u5FC5\u586B\u5907\u6CE8\u987B\u5148\u542F\u7528\u5907\u6CE8" });
});
var articleSchema = import_zod4.z.object({
  title: text2.min(1).max(120),
  summary: text2.max(500).default(""),
  content: import_zod4.z.string().max(1e5),
  cover: image.default(""),
  category: text2.min(1).max(40).default("\u516C\u544A"),
  pinned: import_zod4.z.boolean().default(false),
  status: import_zod4.z.enum(["draft", "published", "withdrawn"]).default("draft")
}).strict();
var popupSchema = import_zod4.z.object({
  title: text2.min(1).max(120),
  summary: text2.max(500).default(""),
  image: image.default(""),
  buttonText: text2.min(1).max(30).default("\u67E5\u770B\u8BE6\u60C5"),
  targetType: import_zod4.z.enum(["event", "article"]),
  targetId: import_zod4.z.string().uuid(),
  startsAt: date,
  expiresAt: date,
  priority: import_zod4.z.number().int().min(0).max(1e3).default(0)
}).strict().refine((v) => v.expiresAt > v.startsAt, "\u5931\u6548\u65F6\u95F4\u987B\u665A\u4E8E\u751F\u6548\u65F6\u95F4");

// src/stage3/service.ts
var empty = () => ({ events: [], articles: [], popups: [] });
var sha = (v) => (0, import_node_crypto3.createHash)("sha256").update(v).digest("hex");
var publicEvent = (e) => {
  const { managerIds: _managers, registrationIds: _rows, ...data } = e;
  void _managers;
  void _rows;
  return data;
};
var Stage3Service = class {
  constructor(store, secure, clock = () => Date.now()) {
    this.store = store;
    this.secure = secure;
    this.clock = clock;
  }
  now() {
    return new Date(this.clock()).toISOString();
  }
  async content(tx, collection, id) {
    const value = await tx.get(collection, id);
    if (!value) return null;
    if (value.id !== id)
      console.warn(JSON.stringify({
        category: "data",
        stage: "content_read",
        code: "CONTENT_ID_MISMATCH",
        collection
      }));
    return { ...value, id };
  }
  can(ctx, p) {
    return ctx.super || ctx.permissions.includes(p);
  }
  require(ctx, p) {
    ensure(this.can(ctx, p), 403, "FORBIDDEN", "\u6CA1\u6709\u6B64\u64CD\u4F5C\u6743\u9650");
  }
  readableEvent(ctx, e) {
    return ctx.super || e.managerIds.includes(ctx.member.uid) || [
      "events.edit",
      "events.delete",
      "events.registrations.read",
      "events.registrations.review",
      "events.registrations.export",
      "events.checkin.manage"
    ].some((p) => ctx.permissions.includes(p));
  }
  scope(ctx, e, p) {
    ensure(
      this.can(ctx, p) || e.managerIds.includes(ctx.member.uid),
      403,
      "EVENT_SCOPE",
      "\u672A\u83B7\u6B64\u6D3B\u52A8\u7BA1\u7406\u6388\u6743"
    );
  }
  async audit(tx, ctx, action, target) {
    const id = (0, import_node_crypto3.randomUUID)();
    await tx.set("audit_logs", id, {
      id,
      actor: ctx.member.uid,
      action,
      target,
      fields: [],
      createdAt: this.now()
    });
  }
  async catalog(tx) {
    return await tx.get("system", "stage3_catalog") ?? empty();
  }
  async page(items, q) {
    const page = import_zod5.z.coerce.number().int().min(1).max(1e4).parse(q.page ?? 1), pageSize = import_zod5.z.coerce.number().int().min(1).max(100).parse(q.pageSize ?? 20);
    return {
      items: items.slice((page - 1) * pageSize, page * pageSize),
      total: items.length,
      page,
      pageSize
    };
  }
  async rows(tx, e, q) {
    const rows = (await Promise.all(
      e.registrationIds.map(
        (id) => tx.get("registrations", id)
      )
    )).filter((r) => !!r);
    return rows.filter(
      (r) => (!q.status || r.status === q.status) && (!q.college || r.snapshot.college === q.college) && (!q.className || r.snapshot.className === q.className) && (!q.checkedIn || (q.checkedIn === "yes" ? !!r.checkedInAt : !r.checkedInAt)) && (!q.search || `${r.snapshot.studentId} ${r.snapshot.name}`.toUpperCase().includes(q.search.toUpperCase()))
    );
  }
  async retireDue(tx, catalog, except = "") {
    for (const id of catalog.popups) {
      if (id === except) continue;
      const p = await tx.get("popup_announcements", id);
      if (p && p.enabled && p.state !== "retired" && p.startsAt <= this.now())
        await tx.set("popup_announcements", id, {
          ...p,
          state: "retired",
          updatedAt: this.now()
        });
    }
  }
  async popup(tx) {
    const catalog = await this.catalog(tx), now = this.now();
    const all = (await Promise.all(
      catalog.popups.map(
        (id) => tx.get("popup_announcements", id)
      )
    )).filter((v) => !!v);
    const eligible = [];
    for (const p of all) {
      if (!p.enabled || p.state === "retired" || p.startsAt > now || p.expiresAt <= now)
        continue;
      const target = await this.content(
        tx,
        p.targetType === "event" ? "events" : "articles",
        p.targetId
      );
      if (target?.status === "published") eligible.push(p);
    }
    eligible.sort(
      (a, b) => b.priority - a.priority || b.startsAt.localeCompare(a.startsAt) || b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id)
    );
    const chosen = eligible[0] ?? null;
    for (const p of all) {
      const state = p.id === chosen?.id ? "active" : p.state === "active" || p.enabled && p.expiresAt <= now ? "retired" : p.state;
      if (state !== p.state)
        await tx.set("popup_announcements", p.id, {
          ...p,
          state,
          updatedAt: now
        });
    }
    await tx.set("popup_state", "current", {
      id: "current",
      popupId: chosen?.id ?? null,
      version: chosen?.version ?? null,
      updatedAt: now
    });
    return chosen ? { ...chosen, state: "active" } : null;
  }
  async execute(token, method, path, input, q) {
    if (method === "POST" && /^\/api\/(events|articles)\/[^/]+\/update$/.test(path)) {
      path = path.slice(0, -"/update".length);
      method = "PATCH";
    }
    const publicRead = method === "GET" && path.startsWith("/api/public/");
    const work = async (tx, ctx) => {
      const cat = await this.catalog(tx);
      if (path === "/api/public/popup") return { data: await this.popup(tx) };
      if (path.startsWith("/api/public/")) {
        const [, kind2, id2] = path.slice("/api/public".length).split("/");
        const collection = kind2 === "events" ? "events" : kind2 === "articles" ? "articles" : "";
        ensure(collection, 404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
        if (id2) {
          const item = await this.content(tx, collection, id2);
          ensure(
            item?.status === "published",
            404,
            "NOT_FOUND",
            "\u5185\u5BB9\u672A\u53D1\u5E03\u6216\u4E0D\u5B58\u5728"
          );
          return {
            data: collection === "events" ? publicEvent(item) : item
          };
        }
        const ids = collection === "events" ? cat.events : cat.articles;
        const items = (await Promise.all(
          ids.map((id3) => this.content(tx, collection, id3))
        )).filter(
          (v) => !!v && v.status === "published"
        ).filter(
          (v) => (!q.search || v.title.includes(q.search)) && (!q.category || "category" in v && v.category === q.category)
        ).sort(
          (a, b) => Number("pinned" in b && b.pinned) - Number("pinned" in a && a.pinned) || String(b.publishedAt).localeCompare(String(a.publishedAt))
        );
        return {
          data: await this.page(
            items.map(
              (v) => collection === "events" ? publicEvent(v) : v
            ),
            q
          )
        };
      }
      ensure(ctx, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
      const parts = path.slice("/api/".length).split("/"), kind = parts[0], id = parts[1], action = parts[2];
      if (kind === "events") {
        if (!id && method === "GET") {
          const all = (await Promise.all(
            cat.events.map((id2) => this.content(tx, "events", id2))
          )).filter(
            (e) => !!e && e.status !== "deleted" && this.readableEvent(ctx, e) && (!q.search || e.title.includes(q.search)) && (!q.status || e.status === q.status)
          );
          return { data: await this.page(all, q) };
        }
        if (!id && method === "POST") {
          this.require(ctx, "events.create");
          const data = eventSchema.parse(input);
          if (data.managerIds.some((uid) => uid !== ctx.member.uid))
            this.require(ctx, "events.edit");
          for (const uid of data.managerIds) {
            const member = await tx.get("users", uid);
            ensure(
              member?.status === "active",
              400,
              "INVALID_MANAGER",
              "\u8D1F\u8D23\u4EBA\u987B\u4E3A\u6709\u6548\u6210\u5458"
            );
          }
          const event2 = {
            ...data,
            id: (0, import_node_crypto3.randomUUID)(),
            publisherUid: ctx.member.uid,
            publisherName: ctx.member.nickname,
            publishedAt: data.status === "published" ? this.now() : null,
            createdAt: this.now(),
            updatedAt: this.now(),
            registrationIds: [],
            occupied: 0,
            checkinOpen: false
          };
          if (!event2.managerIds.includes(ctx.member.uid))
            event2.managerIds.push(ctx.member.uid);
          await tx.set("events", event2.id, event2);
          for (const uid of event2.managerIds)
            await tx.set("event_managers", `${event2.id}:${uid}`, {
              eventId: event2.id,
              uid
            });
          cat.events.push(event2.id);
          await tx.set("system", "stage3_catalog", cat);
          await this.audit(tx, ctx, "events.create", event2.id);
          return { data: event2 };
        }
        if (id === "manager-lookup" && method === "GET") {
          this.require(ctx, "events.edit");
          const studentId = studentIdSchema.parse(q.studentId);
          const mapping = await tx.get(
            "student_ids",
            studentIdKey(studentId)
          );
          const member = mapping ? await tx.get("users", mapping.uid) : null;
          ensure(
            member?.status === "active",
            404,
            "NOT_FOUND",
            "\u672A\u627E\u5230\u6709\u6548\u6210\u5458"
          );
          await this.audit(tx, ctx, "events.manager_lookup", member.uid);
          return {
            data: {
              uid: member.uid,
              studentId: member.studentId,
              nickname: member.nickname
            }
          };
        }
        const event = await this.content(tx, "events", id);
        ensure(
          event && event.status !== "deleted",
          404,
          "NOT_FOUND",
          "\u6D3B\u52A8\u4E0D\u5B58\u5728"
        );
        if (!action && method === "GET") {
          ensure(
            this.readableEvent(ctx, event),
            403,
            "EVENT_SCOPE",
            "\u672A\u83B7\u6D3B\u52A8\u67E5\u770B\u6388\u6743"
          );
          return { data: event };
        }
        if (!action && method === "PATCH") {
          this.scope(ctx, event, "events.edit");
          const data = eventSchema.parse({
            ...Object.fromEntries(
              Object.keys(eventSchema.shape).map((key) => [
                key,
                event[key]
              ])
            ),
            ...import_zod5.z.record(import_zod5.z.string(), import_zod5.z.unknown()).parse(input)
          });
          if (JSON.stringify(data.managerIds) !== JSON.stringify(event.managerIds))
            this.require(ctx, "events.edit");
          ensure(
            data.capacity === null || data.capacity >= event.occupied,
            409,
            "CAPACITY_BELOW_OCCUPIED",
            "\u4EBA\u6570\u4E0A\u9650\u4E0D\u80FD\u4F4E\u4E8E\u5DF2\u5360\u540D\u989D"
          );
          for (const uid of data.managerIds) {
            const member = await tx.get("users", uid);
            ensure(
              member?.status === "active",
              400,
              "INVALID_MANAGER",
              "\u8D1F\u8D23\u4EBA\u987B\u4E3A\u6709\u6548\u6210\u5458"
            );
          }
          for (const uid of event.managerIds)
            await tx.remove("event_managers", `${event.id}:${uid}`);
          for (const uid of data.managerIds)
            await tx.set("event_managers", `${event.id}:${uid}`, {
              eventId: event.id,
              uid
            });
          const next = {
            ...event,
            ...data,
            publishedAt: event.publishedAt ?? (data.status === "published" ? this.now() : null),
            updatedAt: this.now()
          };
          await tx.set("events", event.id, next);
          await this.audit(tx, ctx, "events.edit", event.id);
          return { data: next };
        }
        if (!action && method === "DELETE") {
          this.require(ctx, "events.delete");
          await tx.set("events", event.id, {
            ...event,
            status: "deleted",
            updatedAt: this.now()
          });
          await this.audit(tx, ctx, "events.delete", event.id);
          return { data: { ok: true } };
        }
        if (action === "member-lookup" && method === "GET") {
          this.scope(ctx, event, "events.checkin.manage");
          const studentId = studentIdSchema.parse(q.studentId);
          const mapping = await tx.get(
            "student_ids",
            studentIdKey(studentId)
          );
          const member = mapping ? await tx.get("users", mapping.uid) : null;
          ensure(
            member?.status === "active",
            404,
            "NOT_FOUND",
            "\u672A\u627E\u5230\u6709\u6548\u6210\u5458"
          );
          await this.audit(tx, ctx, "events.checkin_member_lookup", event.id);
          return {
            data: {
              uid: member.uid,
              studentId: member.studentId,
              nickname: member.nickname
            }
          };
        }
        const registrationId = `${event.id}:${ctx.member.uid}`;
        if (action === "registration" && method === "GET")
          return {
            data: await tx.get("registrations", registrationId)
          };
        if (action === "registration" && method === "POST") {
          const body = import_zod5.z.object({ note: import_zod5.z.string().trim().max(2e3).default("") }).strict().parse(input);
          ensure(
            event.status === "published" && event.registrationEnabled,
            409,
            "REGISTRATION_CLOSED",
            "\u6D3B\u52A8\u672A\u5F00\u653E\u62A5\u540D"
          );
          ensure(
            (!event.registrationStartsAt || this.now() >= event.registrationStartsAt) && this.now() < event.registrationDeadline,
            409,
            "REGISTRATION_TIME",
            "\u4E0D\u5728\u62A5\u540D\u65F6\u95F4\u5185"
          );
          ensure(
            event.notesEnabled || !body.note,
            400,
            "NOTES_DISABLED",
            "\u6D3B\u52A8\u672A\u5F00\u542F\u5907\u6CE8"
          );
          ensure(
            !event.notesRequired || !!body.note,
            400,
            "NOTE_REQUIRED",
            "\u8BF7\u586B\u5199\u5907\u6CE8"
          );
          const previous = await tx.get(
            "registrations",
            registrationId
          );
          ensure(
            !previous?.checkedInAt,
            409,
            "ALREADY_CHECKED_IN",
            "\u5DF2\u7B7E\u5230\u8BB0\u5F55\u4E0D\u80FD\u91CD\u65B0\u62A5\u540D"
          );
          ensure(
            !previous || ["cancelled", "rejected"].includes(previous.status),
            409,
            "ALREADY_REGISTERED",
            "\u8BF7\u52FF\u91CD\u590D\u62A5\u540D"
          );
          ensure(
            event.capacity === null || event.occupied < event.capacity,
            409,
            "EVENT_FULL",
            "\u62A5\u540D\u5DF2\u6EE1"
          );
          const m = ctx.member;
          const r = {
            id: registrationId,
            eventId: event.id,
            uid: m.uid,
            snapshot: {
              studentId: m.studentId,
              name: m.name,
              gender: m.gender,
              college: m.college,
              major: m.major,
              className: m.className,
              grade: m.grade
            },
            note: body.note,
            status: event.approvalRequired ? "pending" : "approved",
            registeredAt: this.now(),
            updatedAt: this.now()
          };
          await tx.set("registrations", r.id, r);
          if (!event.registrationIds.includes(r.id))
            event.registrationIds.push(r.id);
          event.occupied++;
          await tx.set("events", event.id, event);
          await this.audit(tx, ctx, "events.register", r.id);
          return { data: r };
        }
        if (action === "registration" && method === "DELETE") {
          ensure(
            event.allowCancellation && this.now() < event.registrationDeadline,
            409,
            "CANCELLATION_CLOSED",
            "\u4E0D\u5141\u8BB8\u53D6\u6D88\u6216\u5DF2\u8D85\u8FC7\u622A\u6B62\u65F6\u95F4"
          );
          const r = await tx.get("registrations", registrationId);
          ensure(
            r && ["pending", "approved"].includes(r.status) && !r.checkedInAt,
            409,
            "CANNOT_CANCEL",
            "\u6B64\u62A5\u540D\u4E0D\u53EF\u53D6\u6D88"
          );
          await tx.set("registrations", r.id, {
            ...r,
            status: "cancelled",
            updatedAt: this.now()
          });
          event.occupied--;
          await tx.set("events", event.id, event);
          await this.audit(tx, ctx, "events.cancel", r.id);
          return { data: { ok: true } };
        }
        if (action === "registrations" && method === "GET") {
          this.scope(
            ctx,
            event,
            parts[3] === "export.xlsx" ? "events.registrations.export" : "events.registrations.read"
          );
          const rows = await this.rows(tx, event, q);
          await this.audit(
            tx,
            ctx,
            parts[3] === "export.xlsx" ? "events.registrations.export" : "events.registrations.read",
            event.id
          );
          if (parts[3] === "export.xlsx") {
            const statuses = {
              pending: "\u5F85\u5BA1\u6838",
              approved: "\u5DF2\u901A\u8FC7",
              rejected: "\u5DF2\u62D2\u7EDD",
              cancelled: "\u5DF2\u53D6\u6D88",
              manual: "\u8865\u7B7E\uFF08\u672A\u62A5\u540D\uFF09"
            };
            const binary = await exportWorkbook(
              [
                "\u5E8F\u53F7",
                "\u5B66\u53F7",
                "\u59D3\u540D",
                "\u6027\u522B",
                "\u5B66\u9662",
                "\u4E13\u4E1A",
                "\u73ED\u7EA7",
                "\u5E74\u7EA7",
                "\u5907\u6CE8",
                "\u62A5\u540D\u65F6\u95F4",
                "\u62A5\u540D\u72B6\u6001",
                "\u7B7E\u5230\u72B6\u6001"
              ],
              rows.map((r, i) => [
                String(i + 1),
                r.snapshot.studentId,
                r.snapshot.name,
                r.snapshot.gender,
                r.snapshot.college,
                r.snapshot.major,
                r.snapshot.className,
                r.snapshot.grade,
                r.note,
                new Date(r.registeredAt).toLocaleString("zh-CN", {
                  timeZone: "Asia/Shanghai"
                }),
                statuses[r.status],
                r.checkedInAt ? "\u5DF2\u7B7E\u5230" : "\u672A\u7B7E\u5230"
              ])
            );
            return {
              binary,
              filename: `${[...event.title.replace(/[\\/:*?"<>|\r\n]/g, "_")].slice(0, 48).join("")}-\u62A5\u540D\u7B7E\u5230\u540D\u5355-${new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Shanghai" }).format(new Date(this.clock()))}.xlsx`
            };
          }
          return {
            data: {
              ...await this.page(rows, q),
              summary: {
                checkedIn: rows.filter((r) => !!r.checkedInAt).length,
                notCheckedIn: rows.filter((r) => !r.checkedInAt).length
              }
            }
          };
        }
        if (action === "review" && method === "POST") {
          this.scope(ctx, event, "events.registrations.review");
          const body = import_zod5.z.object({
            uid: import_zod5.z.string().uuid(),
            status: import_zod5.z.enum(["approved", "rejected"])
          }).strict().parse(input);
          const r = await tx.get(
            "registrations",
            `${event.id}:${body.uid}`
          );
          ensure(
            r?.status === "pending",
            409,
            "NOT_PENDING",
            "\u6B64\u8BB0\u5F55\u4E0D\u5728\u5F85\u5BA1\u6838\u72B6\u6001"
          );
          if (body.status === "rejected") event.occupied--;
          await tx.set("registrations", r.id, {
            ...r,
            status: body.status,
            reviewedBy: ctx.member.uid,
            updatedAt: this.now()
          });
          await tx.set("events", event.id, event);
          await this.audit(tx, ctx, "events.review", r.id);
          return { data: { ok: true } };
        }
        if (action === "checkin-code" && method === "POST") {
          this.scope(ctx, event, "events.checkin.manage");
          ensure(
            event.checkinEnabled && event.status === "published",
            409,
            "CHECKIN_DISABLED",
            "\u6B64\u6D3B\u52A8\u672A\u542F\u7528\u7B7E\u5230"
          );
          const body = import_zod5.z.object({
            open: import_zod5.z.boolean(),
            ttlSeconds: import_zod5.z.number().int().min(30).max(600).default(120)
          }).strict().parse(input), code = (0, import_node_crypto3.randomBytes)(24).toString("base64url");
          event.checkinOpen = body.open;
          await tx.set("events", event.id, event);
          await tx.set("system", `checkin:${event.id}`, {
            hash: sha(code),
            expiresAt: this.clock() + body.ttlSeconds * 1e3
          });
          await this.audit(tx, ctx, "events.checkin_code", event.id);
          return {
            data: {
              code: body.open ? code : null,
              expiresAt: new Date(
                this.clock() + body.ttlSeconds * 1e3
              ).toISOString(),
              open: body.open
            }
          };
        }
        if (action === "checkin" && method === "POST") {
          const body = import_zod5.z.object({ code: import_zod5.z.string().min(1).max(200) }).strict().parse(input), key = await tx.get(
            "system",
            `checkin:${event.id}`
          );
          ensure(
            event.status === "published" && event.checkinEnabled && event.checkinOpen && key && key.expiresAt > this.clock() && (0, import_node_crypto3.timingSafeEqual)(
              Buffer.from(key.hash, "hex"),
              Buffer.from(sha(body.code), "hex")
            ),
            409,
            "INVALID_CHECKIN_CODE",
            "\u7B7E\u5230\u672A\u5F00\u653E\u6216\u7B7E\u5230\u7801\u5DF2\u5931\u6548"
          );
          const r = await tx.get("registrations", registrationId);
          ensure(
            r?.status === "approved",
            403,
            "REGISTRATION_REQUIRED",
            "\u4EC5\u5DF2\u901A\u8FC7\u62A5\u540D\u7684\u6210\u5458\u53EF\u7B7E\u5230"
          );
          if (!r.checkedInAt) {
            const checked = {
              ...r,
              checkedInAt: this.now(),
              checkinMethod: "code"
            };
            await tx.set("registrations", r.id, checked);
            await tx.set("checkins", r.id, {
              id: r.id,
              eventId: event.id,
              uid: r.uid,
              checkedInAt: checked.checkedInAt,
              method: "code"
            });
            await this.audit(tx, ctx, "events.checkin", r.id);
          }
          return { data: { ok: true } };
        }
        if (action === "manual-checkin" && method === "POST") {
          ensure(
            event.checkinEnabled,
            409,
            "CHECKIN_DISABLED",
            "\u6B64\u6D3B\u52A8\u672A\u542F\u7528\u7B7E\u5230"
          );
          this.scope(ctx, event, "events.checkin.manage");
          const body = import_zod5.z.object({
            uid: import_zod5.z.string().uuid(),
            reason: import_zod5.z.string().trim().min(1).max(500)
          }).strict().parse(input);
          const rid = `${event.id}:${body.uid}`;
          let existing = await tx.get("registrations", rid);
          if (!existing) {
            const m = await tx.get("users", body.uid);
            ensure(
              m?.status === "active",
              400,
              "INVALID_MEMBER",
              "\u8865\u7B7E\u5BF9\u8C61\u987B\u4E3A\u6709\u6548\u6210\u5458"
            );
            existing = {
              id: rid,
              eventId: event.id,
              uid: m.uid,
              snapshot: {
                studentId: m.studentId,
                name: m.name,
                gender: m.gender,
                college: m.college,
                major: m.major,
                className: m.className,
                grade: m.grade
              },
              note: "\u7BA1\u7406\u5458\u8865\u7B7E\uFF1A" + body.reason,
              status: "manual",
              registeredAt: this.now(),
              updatedAt: this.now()
            };
            event.registrationIds.push(rid);
            await tx.set("events", event.id, event);
          }
          if (!existing.checkedInAt) {
            await tx.set("registrations", rid, {
              ...existing,
              checkedInAt: this.now(),
              checkinMethod: "manual",
              updatedAt: this.now()
            });
            await tx.set("checkins", rid, {
              id: rid,
              eventId: event.id,
              uid: body.uid,
              checkedInAt: this.now(),
              method: "manual",
              reason: body.reason,
              actor: ctx.member.uid
            });
            await this.audit(tx, ctx, "events.manual_checkin", rid);
          }
          return { data: { ok: true } };
        }
      }
      if (kind === "articles") {
        if (!id && method === "GET") {
          ensure(
            [
              "articles.create",
              "articles.edit",
              "articles.publish",
              "articles.delete"
            ].some((p) => this.can(ctx, p)),
            403,
            "FORBIDDEN",
            "\u6CA1\u6709\u6587\u7AE0\u6743\u9650"
          );
          return {
            data: await this.page(
              (await Promise.all(
                cat.articles.map((id2) => this.content(tx, "articles", id2))
              )).filter(
                (v) => v && v.status !== "deleted" && (!q.search || v.title.includes(q.search)) && (!q.status || v.status === q.status) && (!q.category || v.category === q.category) && (this.can(ctx, "articles.edit") || this.can(ctx, "articles.publish") || this.can(ctx, "articles.delete") || v.publisherUid === ctx.member.uid)
              ),
              q
            )
          };
        }
        const previous = id ? await this.content(tx, "articles", id) : null;
        if (id)
          ensure(
            previous && previous.status !== "deleted",
            404,
            "NOT_FOUND",
            "\u6587\u7AE0\u4E0D\u5B58\u5728"
          );
        if (action === "publish" && method === "POST") {
          this.require(ctx, "articles.publish");
          const body = import_zod5.z.object({ publish: import_zod5.z.boolean() }).strict().parse(input);
          const next = {
            ...previous,
            status: body.publish ? "published" : "withdrawn",
            publishedAt: previous.publishedAt ?? (body.publish ? this.now() : null),
            updatedAt: this.now()
          };
          await tx.set("articles", id, next);
          await this.audit(tx, ctx, "articles.publish", id);
          return { data: next };
        }
        if (method === "DELETE") {
          this.require(ctx, "articles.delete");
          await tx.set("articles", id, {
            ...previous,
            status: "deleted",
            updatedAt: this.now()
          });
          await this.audit(tx, ctx, "articles.delete", id);
          return { data: { ok: true } };
        }
        if (method === "GET") {
          ensure(
            this.can(ctx, "articles.edit") || this.can(ctx, "articles.publish") || this.can(ctx, "articles.delete") || this.can(ctx, "articles.create") && previous?.publisherUid === ctx.member.uid,
            403,
            "FORBIDDEN",
            "\u6CA1\u6709\u6587\u7AE0\u67E5\u770B\u6743\u9650"
          );
          return { data: previous };
        }
        if (method === "POST" || method === "PATCH") {
          this.require(ctx, previous ? "articles.edit" : "articles.create");
          const body = articleSchema.parse(
            previous ? {
              ...Object.fromEntries(
                Object.keys(articleSchema.shape).map((key) => [
                  key,
                  previous[key]
                ])
              ),
              ...import_zod5.z.record(import_zod5.z.string(), import_zod5.z.unknown()).parse(input)
            } : input
          );
          if (body.status === "published" || previous?.status === "published")
            this.require(ctx, "articles.publish");
          const article = {
            ...body,
            id: previous?.id ?? (0, import_node_crypto3.randomUUID)(),
            publisherUid: previous?.publisherUid ?? ctx.member.uid,
            publisherName: previous?.publisherName ?? ctx.member.nickname,
            publishedAt: previous?.publishedAt ?? (body.status === "published" ? this.now() : null),
            createdAt: previous?.createdAt ?? this.now(),
            updatedAt: this.now()
          };
          await tx.set("articles", article.id, article);
          if (!previous) {
            cat.articles.push(article.id);
            await tx.set("system", "stage3_catalog", cat);
          }
          await this.audit(tx, ctx, "articles.save", article.id);
          return { data: article };
        }
      }
      if (kind === "popups") {
        this.require(ctx, "announcements.popup.manage");
        if (method === "GET") {
          const current = await this.popup(tx);
          return {
            data: {
              current,
              items: (await Promise.all(
                cat.popups.map(
                  (id2) => tx.get("popup_announcements", id2)
                )
              )).filter(Boolean)
            }
          };
        }
        if (method === "POST") {
          const body = popupSchema.parse(input), target = await this.content(
            tx,
            body.targetType === "event" ? "events" : "articles",
            body.targetId
          );
          ensure(
            target?.status === "published",
            400,
            "UNPUBLISHED_TARGET",
            "\u8BF7\u5148\u53D1\u5E03\u5173\u8054\u5185\u5BB9"
          );
          const item = {
            ...body,
            id: (0, import_node_crypto3.randomUUID)(),
            version: (0, import_node_crypto3.randomUUID)(),
            enabled: true,
            state: "scheduled",
            createdAt: this.now(),
            updatedAt: this.now()
          };
          if (item.startsAt <= this.now()) await this.retireDue(tx, cat);
          cat.popups.push(item.id);
          await tx.set("popup_announcements", item.id, item);
          await tx.set("system", "stage3_catalog", cat);
          await this.popup(tx);
          await this.audit(tx, ctx, "popups.create", item.id);
          return {
            data: await tx.get(
              "popup_announcements",
              item.id
            )
          };
        }
        if (id && method === "PATCH") {
          const old = await tx.get("popup_announcements", id);
          ensure(old, 404, "NOT_FOUND", "\u5F39\u7A97\u4E0D\u5B58\u5728");
          const body = import_zod5.z.object({ enabled: import_zod5.z.boolean() }).strict().parse(input);
          if (body.enabled) {
            ensure(
              old.expiresAt > this.now(),
              409,
              "POPUP_EXPIRED",
              "\u516C\u544A\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u53D1\u5E03\u65B0\u7248\u672C"
            );
            if (old.startsAt <= this.now()) await this.retireDue(tx, cat, id);
          }
          await tx.set("popup_announcements", id, {
            ...old,
            enabled: body.enabled,
            state: body.enabled ? "scheduled" : "disabled",
            version: (0, import_node_crypto3.randomUUID)(),
            createdAt: this.now(),
            updatedAt: this.now()
          });
          await this.popup(tx);
          await this.audit(tx, ctx, "popups.toggle", id);
          return { data: { ok: true } };
        }
      }
      throw new ApiError(404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
    };
    return publicRead ? this.store.run((tx) => work(tx)) : this.secure(token, (tx, ctx) => work(tx, ctx));
  }
};

// src/members/service.ts
var import_node_crypto4 = require("node:crypto");
var import_zod6 = require("zod");
var failure = (status, code, message) => ({
  status,
  error: { code, message }
});
var MemberService = class {
  constructor(store, clock = () => Date.now()) {
    this.store = store;
    this.clock = clock;
  }
  now() {
    return new Date(this.clock()).toISOString();
  }
  async control(tx) {
    const control = await tx.get("system", "control");
    ensure(control?.initialized, 503, "NOT_INITIALIZED", "\u6210\u5458\u7CFB\u7EDF\u5C1A\u672A\u521D\u59CB\u5316");
    control.revision++;
    await tx.set("system", "control", control);
    return control;
  }
  async audit(tx, actor, action, target, fields = []) {
    const id = (0, import_node_crypto4.randomUUID)();
    const log = {
      id,
      actor,
      action,
      target,
      fields,
      createdAt: this.now()
    };
    await tx.set("audit_logs", id, log);
  }
  async identity(tx, user) {
    const roles = await Promise.all(
      user.roleIds.map((id) => tx.get("roles", id))
    );
    const permissions = [
      ...new Set(roles.flatMap((role) => role?.permissionIds ?? []))
    ];
    return {
      roles: roles.flatMap(
        (role) => role ? [{ id: role.id, name: role.name }] : []
      ),
      member: user,
      permissions,
      super: roles.some((role) => role?.super === true)
    };
  }
  require(ctx, permission) {
    ensure(
      ctx.super || ctx.permissions.includes(permission),
      403,
      "FORBIDDEN",
      "\u6CA1\u6709\u6267\u884C\u6B64\u64CD\u4F5C\u7684\u6743\u9650"
    );
  }
  async authenticate(tx, token, control, allowActivation = false) {
    ensure(token, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
    const sessionId = digest(token);
    const session = await tx.get("sessions", sessionId);
    ensure(
      session && session.expiresAt > this.clock() && session.idleExpiresAt > this.clock(),
      401,
      "SESSION_EXPIRED",
      "\u4F1A\u8BDD\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55"
    );
    const user = await tx.get("users", session.uid);
    ensure(
      user && user.status === "active" && user.version === session.version,
      401,
      "SESSION_REVOKED",
      "\u8D26\u53F7\u6216\u4F1A\u8BDD\u5DF2\u5931\u6548"
    );
    ensure(
      !user.mustChangePassword || allowActivation,
      403,
      "PASSWORD_CHANGE_REQUIRED",
      "\u8BF7\u5148\u4FEE\u6539\u521D\u59CB\u5BC6\u7801"
    );
    if (user.mustChangePassword)
      ensure(
        Date.parse(user.activationExpiresAt) > this.clock(),
        401,
        "ACTIVATION_EXPIRED",
        "\u6FC0\u6D3B\u51ED\u636E\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u91CD\u7F6E"
      );
    session.idleExpiresAt = Math.min(
      session.expiresAt,
      this.clock() + 30 * 6e4
    );
    await tx.set("sessions", sessionId, session);
    return { ...await this.identity(tx, user), control, sessionId };
  }
  async secure(token, fn, activation = false) {
    return this.store.run(
      async (tx) => fn(
        tx,
        await this.authenticate(tx, token, await this.control(tx), activation)
      )
    );
  }
  async manageable(tx, ctx, user) {
    const identity = await this.identity(tx, user);
    ensure(
      ctx.super || !identity.super && identity.permissions.every((p) => ctx.permissions.includes(p)),
      403,
      "SCOPE_EXCEEDED",
      "\u4E0D\u80FD\u7BA1\u7406\u6743\u9650\u9AD8\u4E8E\u81EA\u8EAB\u7684\u6210\u5458"
    );
  }
  async adjustRoles(tx, user, newIds) {
    for (const id of /* @__PURE__ */ new Set([...user.roleIds, ...newIds])) {
      const role = await tx.get("roles", id);
      ensure(role, 400, "INVALID_ROLE", "\u89D2\u8272\u4E0D\u5B58\u5728");
      role.memberCount += Number(newIds.includes(id)) - Number(user.roleIds.includes(id));
      await tx.set("roles", id, role);
    }
  }
  async protectLast(tx, ctx, user, changes) {
    const was = (await this.identity(tx, user)).super && user.status === "active";
    const next = { ...user, ...changes };
    const will = (await this.identity(tx, next)).super && next.status === "active";
    const count = ctx.control.superAdminCount + Number(will) - Number(was);
    ensure(
      count >= 1,
      409,
      "LAST_SUPER_ADMIN",
      "\u4E0D\u80FD\u5220\u9664\u3001\u7981\u7528\u6216\u964D\u7EA7\u6700\u540E\u4E00\u4E2A\u8D85\u7EA7\u7BA1\u7406\u5458"
    );
    ctx.control.superAdminCount = count;
    await tx.set("system", "control", ctx.control);
  }
  async createMember(tx, input, actor, password = "123456", roleIds = ["role_member"], mustChangePassword = true) {
    const data = memberSchema.parse(input);
    ensure(
      !await tx.get("student_ids", studentIdKey(data.studentId)),
      409,
      "STUDENT_ID_EXISTS",
      "\u5B66\u53F7\u5DF2\u5B58\u5728\uFF08\u5305\u62EC\u8F6F\u5220\u9664\u8D26\u53F7\uFF09"
    );
    const uid = (0, import_node_crypto4.randomUUID)();
    const now = this.now();
    const user = {
      ...data,
      uid,
      nickname: data.nickname ?? data.name,
      roleIds,
      status: "active",
      mustChangePassword,
      createdAt: now,
      updatedAt: now,
      version: 1,
      activationExpiresAt: new Date(this.clock() + 7 * 864e5).toISOString()
    };
    await this.adjustRoles(tx, { ...user, roleIds: [] }, roleIds);
    await tx.set("users", uid, user);
    await tx.set("student_ids", studentIdKey(data.studentId), { uid });
    await tx.set("credentials", uid, { hash: await hashPassword(password) });
    await this.audit(tx, actor, "members.create", uid, Object.keys(data));
    return user;
  }
  async bootstrap(input, password) {
    const data = memberSchema.parse(input);
    passwordSchema.parse(password);
    return this.store.run(async (tx) => {
      ensure(
        !await tx.get("system", "control"),
        409,
        "ALREADY_INITIALIZED",
        "\u521D\u59CB\u5316\u5DF2\u5B8C\u6210\uFF0C\u62D2\u7EDD\u91CD\u590D\u521D\u59CB\u5316"
      );
      const now = this.now();
      for (const permission of permissionDefinitions)
        await tx.set("permissions", permission.id, {
          ...permission,
          createdAt: now
        });
      const names = [
        "\u8D85\u7EA7\u7BA1\u7406\u5458",
        "\u7BA1\u7406\u5458",
        "\u4F1A\u957F",
        "\u526F\u4F1A\u957F",
        "\u90E8\u957F",
        "\u526F\u90E8\u957F",
        "\u666E\u901A\u6210\u5458"
      ];
      const ids = [
        "role_super",
        "role_admin",
        "role_president",
        "role_vice_president",
        "role_head",
        "role_vice_head",
        "role_member"
      ];
      for (let i = 0; i < ids.length; i++) {
        const role = {
          id: ids[i],
          name: names[i],
          description: "\u521D\u59CB\u89D2\u8272\uFF1B\u793E\u56E2\u804C\u4F4D\u53E6\u5B58\u4E8E\u6210\u5458 position \u5B57\u6BB5",
          permissionIds: i === 0 ? permissionDefinitions.map((p) => p.id) : i === 1 ? permissionDefinitions.filter((p) => p.implemented).map((p) => p.id) : [],
          memberCount: 0,
          builtin: true,
          super: i === 0,
          createdAt: now
        };
        await tx.set("roles", role.id, role);
      }
      const user = await this.createMember(
        tx,
        data,
        "bootstrap",
        password,
        ["role_super"],
        false
      );
      await tx.set("system", "control", {
        initialized: true,
        superAdminCount: 1,
        revision: 1
      });
      await this.audit(tx, "bootstrap", "system.initialize", user.uid);
      return user;
    });
  }
  async login(input, ip) {
    const body = import_zod6.z.object({
      studentId: studentIdSchema,
      password: import_zod6.z.string().min(1).max(128)
    }).strict().parse(input);
    return this.store.run(async (tx) => {
      await this.control(tx);
      for (const [key, limit] of [
        [`account:${body.studentId}`, 10],
        [`ip:${ip}`, 200]
      ]) {
        const id = digest(key);
        let rate = await tx.get(
          "login_limits",
          id
        );
        if (!rate || rate.until <= this.clock())
          rate = { count: 0, until: this.clock() + 15 * 6e4 };
        if (rate.count >= limit)
          return failure(
            429,
            "RATE_LIMITED",
            "\u767B\u5F55\u5C1D\u8BD5\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF715\u5206\u949F\u540E\u518D\u8BD5"
          );
        rate.count++;
        await tx.set("login_limits", id, { ...rate, createdAt: this.now() });
      }
      const mapping = await tx.get(
        "student_ids",
        studentIdKey(body.studentId)
      );
      const user = mapping ? await tx.get("users", mapping.uid) : null;
      const credential = user ? await tx.get("credentials", user.uid) : null;
      const valid = await verifyPassword(body.password, credential?.hash ?? "");
      if (!user || user.status !== "active" || !valid) {
        await this.audit(tx, "anonymous", "auth.login_failed", "redacted");
        return failure(401, "INVALID_CREDENTIALS", "\u5B66\u53F7\u3001\u5BC6\u7801\u9519\u8BEF\u6216\u8D26\u53F7\u4E0D\u53EF\u7528");
      }
      if (user.mustChangePassword && Date.parse(user.activationExpiresAt) <= this.clock())
        return failure(
          401,
          "ACTIVATION_EXPIRED",
          "\u521D\u59CB\u51ED\u636E\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u91CD\u7F6E"
        );
      await tx.set("login_limits", digest(`account:${body.studentId}`), {
        count: 0,
        until: this.clock() + 15 * 6e4,
        createdAt: this.now()
      });
      const token = randomToken();
      const expiresAt = this.clock() + (user.mustChangePassword ? 15 * 6e4 : 8 * 36e5);
      await tx.set("sessions", digest(token), {
        createdAt: this.now(),
        uid: user.uid,
        version: user.version,
        expiresAt,
        idleExpiresAt: Math.min(expiresAt, this.clock() + 30 * 6e4)
      });
      await this.audit(tx, user.uid, "auth.login", user.uid);
      return { data: await this.identity(tx, user), token };
    });
  }
  async authorize(token, permission) {
    return this.secure(token, async (_tx, ctx) => this.require(ctx, permission));
  }
  async prepareImport(token, input) {
    const body = import_zod6.z.object({ file: import_zod6.z.string().min(1).max(3e6) }).strict().parse(input);
    await this.secure(
      token,
      async (_tx, ctx) => this.require(ctx, "members.import")
    );
    const file = Buffer.from(body.file, "base64");
    const hash = digest(file.toString("base64"));
    const rows = await parseWorkbook(file);
    for (let start = 0; start < rows.length; start += 20)
      await Promise.all(
        rows.slice(start, start + 20).map(async (row) => {
          if (row.member && !row.error && await this.store.read(
            "student_ids",
            studentIdKey(row.member.studentId)
          ))
            row.error = "\u5B66\u53F7\u5DF2\u5B58\u5728\uFF08\u5305\u62EC\u8F6F\u5220\u9664\u8D26\u53F7\uFF09";
        })
      );
    ensure(
      Buffer.byteLength(JSON.stringify(rows)) <= 7e5,
      413,
      "IMPORT_TOO_LARGE",
      "\u89E3\u6790\u540E\u6570\u636E\u8FC7\u5927\uFF0C\u8BF7\u62C6\u5206\u6587\u4EF6"
    );
    return this.secure(token, async (tx, ctx) => {
      this.require(ctx, "members.import");
      const existing = await tx.get("import_jobs", hash);
      if (existing) {
        ensure(
          existing.owner === ctx.member.uid || ctx.super,
          403,
          "FORBIDDEN",
          "\u8BE5\u6587\u4EF6\u5DF2\u7531\u5176\u4ED6\u7BA1\u7406\u5458\u5BFC\u5165"
        );
        return { data: existing };
      }
      const job = {
        id: hash,
        hash,
        owner: ctx.member.uid,
        rows,
        offset: 0,
        created: 0,
        skipped: 0,
        status: "preview",
        createdAt: this.now(),
        updatedAt: this.now()
      };
      await tx.set("import_jobs", hash, job);
      await this.audit(tx, ctx.member.uid, "imports.preview", hash);
      return { data: job };
    });
  }
  async execute(token, method, path, input, query) {
    if (/^\/api\/forum(?:\/|$)/.test(path))
      return new ForumService(this.store, (token2, fn) => this.secure(token2, fn), this.clock).execute(token, method, path, input, query);
    if (/^\/api\/(?:public|events|articles|popups)(?:\/|$)/.test(path))
      return new Stage3Service(
        this.store,
        (token2, fn) => this.secure(token2, fn),
        this.clock
      ).execute(token, method, path, input, query);
    if (method === "POST" && path === "/api/imports/preview")
      return this.prepareImport(token, input);
    return this.secure(
      token,
      async (tx, ctx) => {
        const user = ctx.member;
        if (path === "/api/auth/me" && method === "GET")
          return {
            data: {
              member: user,
              roles: ctx.roles,
              permissions: ctx.permissions,
              super: ctx.super
            }
          };
        if (path === "/api/auth/logout" && method === "POST") {
          await tx.remove("sessions", ctx.sessionId);
          await this.audit(tx, user.uid, "auth.logout", user.uid);
          return { data: { ok: true }, clearCookie: true };
        }
        if (path === "/api/auth/password" && method === "POST") {
          const body = import_zod6.z.object({
            oldPassword: import_zod6.z.string().max(128),
            newPassword: passwordSchema
          }).strict().parse(input);
          const credential = await tx.get("credentials", user.uid);
          ensure(
            credential && await verifyPassword(body.oldPassword, credential.hash),
            400,
            "WRONG_PASSWORD",
            "\u539F\u5BC6\u7801\u9519\u8BEF"
          );
          ensure(
            body.oldPassword !== body.newPassword,
            400,
            "PASSWORD_UNCHANGED",
            "\u65B0\u5BC6\u7801\u4E0D\u80FD\u4E0E\u539F\u5BC6\u7801\u76F8\u540C"
          );
          await tx.set("credentials", user.uid, {
            hash: await hashPassword(body.newPassword)
          });
          await tx.set("users", user.uid, {
            ...user,
            mustChangePassword: false,
            version: user.version + 1,
            updatedAt: this.now()
          });
          await this.audit(tx, user.uid, "auth.password_change", user.uid);
          return { data: { ok: true }, clearCookie: true };
        }
        if (path === "/api/auth/revoke-sessions" && method === "POST") {
          await tx.set("users", user.uid, {
            ...user,
            version: user.version + 1,
            updatedAt: this.now()
          });
          await this.audit(tx, user.uid, "auth.revoke_all", user.uid);
          return { data: { ok: true }, clearCookie: true };
        }
        if (path === "/api/profile" && method === "PATCH") {
          const changes = profileSchema.parse(input);
          const next = { ...user, ...changes, updatedAt: this.now() };
          await tx.set("users", user.uid, next);
          await this.audit(
            tx,
            user.uid,
            "members.profile",
            user.uid,
            Object.keys(changes)
          );
          return { data: next };
        }
        if (path === "/api/members" && method === "GET") {
          this.require(ctx, "members.read");
          const options = listSchema.parse(query);
          const filter = {};
          if (options.status === "all") filter._notDeleted = true;
          else filter.status = options.status;
          if (options.search) filter._search = options.search;
          for (const key of ["college", "className"])
            if (options[key]) filter[key] = options[key];
          if (options.roleId) filter.roleIds = options.roleId;
          const result = await this.store.list("users", filter, {
            offset: (options.page - 1) * options.pageSize,
            limit: options.pageSize
          });
          return {
            data: { ...result, page: options.page, pageSize: options.pageSize }
          };
        }
        if (path === "/api/members" && method === "POST") {
          this.require(ctx, "members.create");
          return { data: await this.createMember(tx, input, user.uid) };
        }
        if (path === "/api/members/export" && method === "GET") {
          this.require(ctx, "members.export");
          this.require(ctx, "members.read");
          const options = import_zod6.z.object({
            page: import_zod6.z.coerce.number().int().min(1).max(1e4).default(1)
          }).strict().parse(query);
          const result = await this.store.list(
            "users",
            { _notDeleted: true },
            { offset: (options.page - 1) * 100, limit: 100 }
          );
          await this.audit(tx, user.uid, "members.export", "users", [
            `page:${options.page}`
          ]);
          return { data: { ...result, page: options.page, pageSize: 100 } };
        }
        const memberMatch = path.match(
          /^\/api\/members\/([a-zA-Z0-9-]+)(?:\/(roles|password|status|restore|anonymize))?$/
        );
        if (memberMatch) {
          const id = memberMatch[1];
          const action = memberMatch[2];
          const target = await tx.get("users", id);
          ensure(target, 404, "NOT_FOUND", "\u6210\u5458\u4E0D\u5B58\u5728");
          if (!action && method === "GET") {
            this.require(ctx, "members.read");
            return { data: target };
          }
          const required = action === "roles" ? "roles.assign" : action === "password" ? "members.password" : action === "status" ? "members.status" : action === "restore" || action === "anonymize" || method === "DELETE" ? "members.delete" : "members.edit";
          this.require(ctx, required);
          await this.manageable(tx, ctx, target);
          let next = { ...target, updatedAt: this.now() };
          let fields = [];
          if (!action && method === "PATCH") {
            ensure(target.status !== "deleted", 409, "DELETED", "\u8BF7\u5148\u6062\u590D\u6210\u5458");
            const changes = editSchema.parse(input);
            fields = Object.keys(changes);
            if (changes.studentId && changes.studentId !== target.studentId) {
              ensure(
                !await tx.get("student_ids", studentIdKey(changes.studentId)),
                409,
                "STUDENT_ID_EXISTS",
                "\u5B66\u53F7\u5DF2\u5B58\u5728"
              );
              await tx.remove("student_ids", studentIdKey(target.studentId));
              await tx.set("student_ids", studentIdKey(changes.studentId), {
                uid: id
              });
              next.version++;
            }
            next = { ...next, ...changes };
          } else if (action === "roles" && method === "PUT") {
            ensure(target.status !== "deleted", 409, "DELETED", "\u8BF7\u5148\u6062\u590D\u6210\u5458");
            const body = import_zod6.z.object({
              roleIds: import_zod6.z.array(import_zod6.z.string().min(1).max(64)).min(1).max(10)
            }).strict().parse(input);
            const roleIds = [...new Set(body.roleIds)];
            for (const roleId of roleIds) {
              const role = await tx.get("roles", roleId);
              ensure(role, 400, "INVALID_ROLE", "\u89D2\u8272\u4E0D\u5B58\u5728");
              ensure(
                ctx.super || !role.super && role.permissionIds.every(
                  (p) => ctx.permissions.includes(p)
                ),
                403,
                "SCOPE_EXCEEDED",
                "\u4E0D\u80FD\u5206\u914D\u8D85\u51FA\u81EA\u8EAB\u6743\u9650\u7684\u89D2\u8272"
              );
            }
            await this.protectLast(tx, ctx, target, { roleIds });
            await this.adjustRoles(tx, target, roleIds);
            next.roleIds = roleIds;
            next.version++;
            fields = ["roleIds"];
          } else if (action === "password" && method === "POST") {
            import_zod6.z.object({}).strict().parse(input);
            ensure(target.status !== "deleted", 409, "DELETED", "\u8BF7\u5148\u6062\u590D\u6210\u5458");
            await tx.set("credentials", id, {
              hash: await hashPassword("123456")
            });
            next.mustChangePassword = true;
            next.activationExpiresAt = new Date(
              this.clock() + 7 * 864e5
            ).toISOString();
            next.version++;
            fields = ["credentials"];
          } else if (action === "status" && method === "PATCH") {
            const body = import_zod6.z.object({ status: import_zod6.z.enum(["active", "disabled"]) }).strict().parse(input);
            ensure(
              target.status !== "deleted",
              409,
              "DELETED",
              "\u8BF7\u4F7F\u7528\u6062\u590D\u64CD\u4F5C"
            );
            await this.protectLast(tx, ctx, target, body);
            next.status = body.status;
            next.version++;
            fields = ["status"];
          } else if (action === "restore" && method === "POST") {
            ensure(
              target.status === "deleted" && !target.anonymizedAt,
              409,
              "NOT_RESTORABLE",
              "\u8D26\u53F7\u4E0D\u53EF\u6062\u590D"
            );
            next.status = "disabled";
            delete next.deletedAt;
            next.version++;
            fields = ["status"];
          } else if (!action && method === "DELETE") {
            await this.protectLast(tx, ctx, target, { status: "deleted" });
            next.status = "deleted";
            next.deletedAt = this.now();
            next.version++;
            fields = ["status", "deletedAt"];
          } else if (action === "anonymize" && method === "POST") {
            ensure(
              ctx.super && target.status === "deleted",
              403,
              "FORBIDDEN",
              "\u4EC5\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u533F\u540D\u5316\u5DF2\u8F6F\u5220\u9664\u6210\u5458"
            );
            ensure(
              !target.anonymizedAt,
              409,
              "ALREADY_ANONYMIZED",
              "\u5DF2\u7ECF\u533F\u540D\u5316"
            );
            await tx.set("privacy_jobs", id, {
              id,
              uid: id,
              studentIdDigest: studentIdKey(target.studentId),
              status: "pending",
              createdAt: this.now()
            });
            await this.adjustRoles(tx, target, []);
            await tx.remove("student_ids", studentIdKey(target.studentId));
            await tx.remove("credentials", id);
            next = {
              ...next,
              studentId: "",
              name: "\u5DF2\u533F\u540D\u5316",
              nickname: "\u5DF2\u533F\u540D\u5316",
              gender: "\u672A\u586B\u5199",
              college: "",
              major: "",
              className: "",
              grade: "",
              phone: "",
              email: "",
              avatar: "",
              position: "",
              roleIds: [],
              anonymizedAt: this.now(),
              version: next.version + 1
            };
            fields = ["personalData"];
          } else throw new ApiError(405, "METHOD_NOT_ALLOWED", "\u65B9\u6CD5\u4E0D\u652F\u6301");
          await tx.set("users", id, next);
          await this.audit(
            tx,
            user.uid,
            `members.${action ?? (method === "DELETE" ? "delete" : "edit")}`,
            id,
            fields
          );
          return { data: next };
        }
        if (path === "/api/permissions" && method === "GET") {
          this.require(ctx, "roles.read");
          return {
            data: (await this.store.list(
              "permissions",
              {},
              { offset: 0, limit: 100 }
            )).items
          };
        }
        if (path === "/api/roles" && method === "GET") {
          this.require(ctx, "roles.read");
          const page = import_zod6.z.coerce.number().int().min(1).max(100).parse(query.page ?? 1);
          const result = await this.store.list(
            "roles",
            {},
            { offset: (page - 1) * 100, limit: 100 }
          );
          return { data: { ...result, page, pageSize: 100 } };
        }
        if (path === "/api/roles" && method === "POST" || /^\/api\/roles\/[a-zA-Z0-9_-]+$/.test(path)) {
          this.require(ctx, "roles.manage");
          const id = path.split("/")[3] ?? (0, import_node_crypto4.randomUUID)();
          const previous = await tx.get("roles", id);
          if (method !== "POST")
            ensure(previous, 404, "NOT_FOUND", "\u89D2\u8272\u4E0D\u5B58\u5728");
          if (previous)
            ensure(
              !previous.super && (ctx.super || previous.permissionIds.every(
                (p) => ctx.permissions.includes(p)
              )),
              403,
              "SCOPE_EXCEEDED",
              "\u6B64\u89D2\u8272\u8D85\u51FA\u53EF\u7BA1\u7406\u8303\u56F4"
            );
          if (method === "DELETE") {
            ensure(
              previous && !previous.builtin && previous.memberCount === 0,
              409,
              "ROLE_IN_USE",
              "\u521D\u59CB\u89D2\u8272\u6216\u4ECD\u88AB\u6210\u5458\u4F7F\u7528\u7684\u89D2\u8272\u4E0D\u53EF\u5220\u9664"
            );
            await tx.remove("roles", id);
            await this.audit(tx, user.uid, "roles.delete", id);
            return { data: { ok: true } };
          }
          ensure(
            method === "POST" || method === "PUT",
            405,
            "METHOD_NOT_ALLOWED",
            "\u65B9\u6CD5\u4E0D\u652F\u6301"
          );
          ensure(
            !(method === "POST" && path !== "/api/roles"),
            405,
            "METHOD_NOT_ALLOWED",
            "\u65B9\u6CD5\u4E0D\u652F\u6301"
          );
          const data = roleSchema.parse(input);
          ensure(
            data.name !== "\u8D85\u7EA7\u7BA1\u7406\u5458",
            400,
            "RESERVED_ROLE_NAME",
            "\u8D85\u7EA7\u7BA1\u7406\u5458\u4E3A\u4FDD\u7559\u89D2\u8272\u540D\u79F0"
          );
          for (const permission of data.permissionIds) {
            ensure(
              await tx.get("permissions", permission),
              400,
              "INVALID_PERMISSION",
              "\u6743\u9650\u4E0D\u5B58\u5728"
            );
            ensure(
              ctx.super || ctx.permissions.includes(permission),
              403,
              "SCOPE_EXCEEDED",
              "\u4E0D\u80FD\u6388\u4E88\u8D85\u51FA\u81EA\u8EAB\u7684\u6743\u9650"
            );
          }
          const role = {
            ...data,
            id,
            builtin: previous?.builtin ?? false,
            super: false,
            memberCount: previous?.memberCount ?? 0,
            createdAt: previous?.createdAt ?? this.now()
          };
          await tx.set("roles", id, role);
          await this.audit(
            tx,
            user.uid,
            previous ? "roles.edit" : "roles.create",
            id,
            ["name", "description", "permissionIds"]
          );
          return { data: role };
        }
        const jobMatch = path.match(
          /^\/api\/imports\/([a-f0-9]{64})(?:\/(process))?$/
        );
        if (jobMatch) {
          this.require(ctx, "members.import");
          const job = await tx.get("import_jobs", jobMatch[1]);
          ensure(job, 404, "NOT_FOUND", "\u5BFC\u5165\u4EFB\u52A1\u4E0D\u5B58\u5728");
          ensure(
            job.owner === user.uid || ctx.super,
            403,
            "FORBIDDEN",
            "\u4E0D\u80FD\u8BFB\u53D6\u4ED6\u4EBA\u7684\u5BFC\u5165\u4EFB\u52A1"
          );
          if (method === "GET" && !jobMatch[2]) return { data: job };
          ensure(
            method === "POST" && jobMatch[2] === "process",
            405,
            "METHOD_NOT_ALLOWED",
            "\u65B9\u6CD5\u4E0D\u652F\u6301"
          );
          const body = import_zod6.z.object({ offset: import_zod6.z.number().int().min(0) }).strict().parse(input);
          if (body.offset !== job.offset || job.status === "completed")
            return { data: job };
          const end = Math.min(job.offset + 20, job.rows.length);
          for (let i = job.offset; i < end; i++) {
            const row = job.rows[i];
            if (!row.error && row.member) {
              if (await tx.get("student_ids", studentIdKey(row.member.studentId)))
                row.error = "\u5B66\u53F7\u5DF2\u5B58\u5728\u6216\u88AB\u5176\u4ED6\u4EFB\u52A1\u521B\u5EFA";
              else
                row.uid = (await this.createMember(tx, row.member, user.uid)).uid;
            }
            if (row.uid) job.created++;
            else job.skipped++;
          }
          job.offset = end;
          job.status = end === job.rows.length ? "completed" : "processing";
          job.updatedAt = this.now();
          await tx.set("import_jobs", job.id, job);
          await this.audit(tx, user.uid, "members.import", job.id, [
            `offset:${body.offset}`,
            `created:${job.created}`,
            `skipped:${job.skipped}`
          ]);
          return { data: job };
        }
        if (path === "/api/audit" && method === "GET") {
          this.require(ctx, "audit.read");
          const page = import_zod6.z.coerce.number().int().min(1).max(1e4).parse(query.page ?? 1);
          const result = await this.store.list(
            "audit_logs",
            {},
            { offset: (page - 1) * 50, limit: 50 }
          );
          return { data: { ...result, page, pageSize: 50 } };
        }
        throw new ApiError(404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
      },
      ["/api/auth/me", "/api/auth/logout", "/api/auth/password"].includes(path)
    );
  }
};

// src/offline-bootstrap.ts
async function generateBootstrapSql(input, password) {
  const records = /* @__PURE__ */ new Map();
  const store = {
    read: async () => null,
    list: async () => {
      throw new Error("NOT_SUPPORTED");
    },
    run: async (fn) => fn({
      get: async (c, id) => records.get(c + "/" + id)?.data ?? null,
      set: async (c, id, data) => {
        records.set(c + "/" + id, { collection: c, id, data });
      },
      remove: async () => {
        throw new Error("NOT_SUPPORTED");
      }
    })
  };
  await new MemberService(store).bootstrap(input, password);
  const literal = (value) => "'" + value.replace(/'/g, "''") + "'";
  let sql = "BEGIN;\nSET LOCAL standard_conforming_strings=on;\nSELECT pg_advisory_xact_lock(1991,1);\nDO $$ BEGIN IF EXISTS(SELECT 1 FROM electronicclub.system WHERE id='control') THEN RAISE EXCEPTION 'ALREADY_INITIALIZED'; END IF; END $$;\n";
  for (const { collection, id, data } of records.values())
    sql += `INSERT INTO electronicclub.${collection}(id,data) VALUES(${literal(id)},${literal(JSON.stringify(data))}::jsonb);
`;
  for (const { collection, id, data } of records.values())
    if (collection === "users")
      for (const role of data.roleIds)
        sql += `INSERT INTO electronicclub.user_roles(user_id,role_id) VALUES(${literal(id)},${literal(role)});
`;
  return sql + "COMMIT;\n";
}
async function main() {
  const output = process.argv.find((arg) => arg.startsWith("--output="))?.slice(9);
  if (!output || !(0, import_node_path.isAbsolute)(output) || (0, import_node_path.resolve)(output).startsWith((0, import_node_path.resolve)(process.cwd()) + import_node_path.sep) || !process.env.BOOTSTRAP_PASSWORD || !process.env.BOOTSTRAP_STUDENT_ID || !process.env.BOOTSTRAP_NAME)
    throw new Error("PRIVATE_CONFIGURATION_REQUIRED");
  const sql = await generateBootstrapSql(
    {
      studentId: process.env.BOOTSTRAP_STUDENT_ID,
      name: process.env.BOOTSTRAP_NAME,
      nickname: process.env.BOOTSTRAP_NICKNAME || void 0
    },
    process.env.BOOTSTRAP_PASSWORD
  );
  await (0, import_promises.writeFile)(output, sql, { mode: 384, flag: "wx" });
  console.log(
    "Private initialization SQL created. Contains sensitive hashes; do not upload to GitHub or the public function ZIP."
  );
}
if (process.argv[1]?.endsWith("offline-bootstrap.ts") || process.argv[1]?.endsWith("offline-bootstrap.js"))
  main().catch(() => {
    console.error("Offline initialization plan failed; no credentials logged.");
    process.exitCode = 1;
  });
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  generateBootstrapSql
});
