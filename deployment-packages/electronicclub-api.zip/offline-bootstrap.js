"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/offline-bootstrap.ts
var offline_bootstrap_exports = {};
__export(offline_bootstrap_exports, {
  generateBootstrapSql: () => generateBootstrapSql
});
module.exports = __toCommonJS(offline_bootstrap_exports);
var import_promises = require("node:fs/promises");
var import_node_path = require("node:path");

// src/members/service.ts
var import_node_crypto2 = require("node:crypto");
var import_zod2 = require("zod");

// ../../packages/shared/src/student-id.ts
var STUDENT_ID_MESSAGE = "\u5B66\u53F7\u987B\u4E3A4\u201324\u4F4D\u82F1\u6587\u5B57\u6BCD\u6216\u6570\u5B57\uFF0C\u4E0D\u5141\u8BB8\u7A7A\u683C\u6216\u7279\u6B8A\u5B57\u7B26";
function isValidStudentId(value) {
  return typeof value === "string" && value.length >= 4 && value.length <= 24 && !/[^A-Za-z0-9]/.test(value);
}
function normalizeStudentId(value) {
  if (!isValidStudentId(value)) throw new Error(STUDENT_ID_MESSAGE);
  return value.toUpperCase();
}

// src/members/model.ts
var import_zod = require("zod");
var ApiError = class extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
function ensure(value, status, code, message) {
  if (!value) throw new ApiError(status, code, message);
}
var text = import_zod.z.string().trim().max(100);
var studentIdSchema = import_zod.z.string().refine(isValidStudentId, STUDENT_ID_MESSAGE).transform(normalizeStudentId);
var memberSchema = import_zod.z.object({
  studentId: studentIdSchema,
  name: import_zod.z.string().trim().min(1).max(60),
  gender: import_zod.z.enum(["\u7537", "\u5973", "\u5176\u4ED6", "\u672A\u586B\u5199"]).default("\u672A\u586B\u5199"),
  college: text.default(""),
  major: text.default(""),
  className: text.default(""),
  grade: text.default(""),
  nickname: import_zod.z.string().trim().min(1).max(60).optional(),
  phone: import_zod.z.string().regex(/^[\d+ ()-]{0,30}$/).default(""),
  email: import_zod.z.union([import_zod.z.literal(""), import_zod.z.string().email().max(200)]).default(""),
  avatar: import_zod.z.union([
    import_zod.z.literal(""),
    import_zod.z.string().url().max(500).refine((x) => x.startsWith("https://"), "\u5934\u50CF\u4EC5\u652F\u6301HTTPS\u5730\u5740")
  ]).default(""),
  position: text.default("")
}).strict();
var patchFields = import_zod.z.object({
  studentId: studentIdSchema,
  name: import_zod.z.string().trim().min(1).max(60),
  nickname: import_zod.z.string().trim().min(1).max(60),
  gender: import_zod.z.enum(["\u7537", "\u5973", "\u5176\u4ED6", "\u672A\u586B\u5199"]),
  college: text,
  major: text,
  className: text,
  grade: text,
  phone: import_zod.z.string().regex(/^[\d+ ()-]{0,30}$/),
  email: import_zod.z.union([import_zod.z.literal(""), import_zod.z.string().email().max(200)]),
  avatar: import_zod.z.union([
    import_zod.z.literal(""),
    import_zod.z.string().url().max(500).refine((x) => x.startsWith("https://"))
  ]),
  position: text
});
var profileSchema = patchFields.pick({
  nickname: true,
  gender: true,
  phone: true,
  email: true,
  avatar: true
}).partial().strict();
var editSchema = patchFields.partial().strict();
var passwordSchema = import_zod.z.string().min(12).max(128).refine(
  (x) => /[a-zA-Z]/.test(x) && /\d/.test(x),
  "\u5BC6\u7801\u81F3\u5C1112\u4F4D\u4E14\u5305\u542B\u5B57\u6BCD\u548C\u6570\u5B57"
);
var permissionDefinitions = [
  ["members.read", "\u6210\u5458\u67E5\u8BE2", "\u6210\u5458"],
  ["members.create", "\u6210\u5458\u521B\u5EFA", "\u6210\u5458"],
  ["members.edit", "\u8EAB\u4EFD\u8D44\u6599\u7F16\u8F91", "\u6210\u5458"],
  ["members.import", "Excel\u5BFC\u5165", "\u6210\u5458"],
  ["members.export", "\u6210\u5458\u5BFC\u51FA", "\u6210\u5458"],
  ["members.delete", "\u8F6F\u5220\u9664\u4E0E\u6062\u590D", "\u6210\u5458"],
  ["members.password", "\u5BC6\u7801\u91CD\u7F6E", "\u6210\u5458"],
  ["members.status", "\u7981\u7528\u4E0E\u6062\u590D\u8D26\u53F7", "\u6210\u5458"],
  ["roles.read", "\u89D2\u8272\u4E0E\u6743\u9650\u67E5\u8BE2", "\u6743\u9650"],
  ["roles.assign", "\u5206\u914D\u6210\u5458\u89D2\u8272", "\u6743\u9650"],
  ["roles.manage", "\u521B\u5EFA\u53CA\u7BA1\u7406\u89D2\u8272", "\u6743\u9650"],
  ["audit.read", "\u5BA1\u8BA1\u65E5\u5FD7\u67E5\u8BE2", "\u7CFB\u7EDF"],
  ["activities.create", "\u521B\u5EFA\u6D3B\u52A8", "\u540E\u7EED\u4E1A\u52A1"],
  ["activities.manage", "\u7BA1\u7406\u6D3B\u52A8", "\u540E\u7EED\u4E1A\u52A1"],
  ["activities.roster.read", "\u67E5\u770B\u62A5\u540D\u540D\u5355", "\u540E\u7EED\u4E1A\u52A1"],
  ["activities.roster.export", "\u5BFC\u51FA\u62A5\u540D\u540D\u5355", "\u540E\u7EED\u4E1A\u52A1"],
  ["articles.manage", "\u6587\u7AE0\u516C\u544A\u7BA1\u7406", "\u540E\u7EED\u4E1A\u52A1"],
  ["community.moderate", "\u5E16\u5B50\u8BC4\u8BBA\u5BA1\u6838", "\u540E\u7EED\u4E1A\u52A1"],
  ["settings.manage", "\u7CFB\u7EDF\u8BBE\u7F6E", "\u540E\u7EED\u4E1A\u52A1"],
  ["popups.manage", "\u5168\u7AD9\u5F39\u7A97", "\u540E\u7EED\u4E1A\u52A1"]
].map(([id, name, group]) => ({
  id,
  name,
  group,
  implemented: group !== "\u540E\u7EED\u4E1A\u52A1"
}));
var roleSchema = import_zod.z.object({
  name: import_zod.z.string().trim().min(1).max(60),
  description: import_zod.z.string().trim().max(300),
  permissionIds: import_zod.z.array(import_zod.z.string()).max(64).transform((x) => [...new Set(x)])
}).strict();
var listSchema = import_zod.z.object({
  page: import_zod.z.coerce.number().int().min(1).max(1e4).default(1),
  pageSize: import_zod.z.coerce.number().int().min(1).max(100).default(20),
  search: import_zod.z.string().max(100).default(""),
  college: text.default(""),
  className: text.default(""),
  roleId: import_zod.z.string().max(64).default(""),
  status: import_zod.z.enum(["active", "disabled", "deleted", "all"]).default("active")
}).strict();

// src/members/crypto.ts
var import_node_crypto = require("node:crypto");
var digest = (value) => (0, import_node_crypto.createHash)("sha256").update(value).digest("hex");
var randomToken = () => (0, import_node_crypto.randomBytes)(32).toString("base64url");
async function hashPassword(password) {
  const salt = (0, import_node_crypto.randomBytes)(16).toString("hex");
  const key = await derive(password, salt);
  return `scrypt$${salt}$${key.toString("hex")}`;
}
function derive(password, salt) {
  return new Promise(
    (resolve2, reject) => (0, import_node_crypto.scrypt)(
      password,
      salt,
      64,
      { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 },
      (err, key) => err ? reject(err) : resolve2(key)
    )
  );
}
async function verifyPassword(password, hash) {
  const parts = hash.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") {
    await derive(password, "invalid-credential-padding");
    return false;
  }
  const key = await derive(password, parts[1]);
  const expected = Buffer.from(parts[2], "hex");
  return key.length === expected.length && (0, import_node_crypto.timingSafeEqual)(key, expected);
}
var studentIdKey = (studentId) => digest(normalizeStudentId(studentId));

// src/members/xlsx.ts
var import_exceljs = __toESM(require("exceljs"));
var import_yauzl = require("yauzl");
var columns = ["\u5B66\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u5B66\u9662", "\u4E13\u4E1A", "\u73ED\u7EA7", "\u5E74\u7EA7"];
async function validateZip(buffer) {
  ensure(buffer.length <= 2e6, 413, "FILE_TOO_LARGE", "\u6587\u4EF6\u6700\u59272MB");
  await new Promise(
    (resolve2, reject) => (0, import_yauzl.fromBuffer)(buffer, { lazyEntries: true }, (error, zip) => {
      if (error || !zip) return reject(new Error("\u65E0\u6548\u7684 XLSX \u538B\u7F29\u6587\u4EF6"));
      let size = 0, count = 0, ended = false, actualSize = 0;
      const fail = () => {
        if (!ended) {
          ended = true;
          zip.close();
          reject(new Error("XLSX \u89E3\u538B\u6570\u636E\u8FC7\u5927\u6216\u683C\u5F0F\u5F02\u5E38"));
        }
      };
      zip.on("error", fail);
      zip.on("entry", (entry) => {
        size += entry.uncompressedSize;
        count++;
        if (size > 2e7 || count > 2e3 || entry.fileName.includes("..") || entry.generalPurposeBitFlag & 1)
          fail();
        else
          zip.openReadStream(entry, (err, stream) => {
            if (err || !stream) {
              fail();
              return;
            }
            stream.on("data", (chunk) => {
              actualSize += chunk.length;
              if (actualSize > 2e7) {
                stream.destroy();
                fail();
              }
            });
            stream.on("error", fail);
            stream.on("end", () => {
              if (!ended) zip.readEntry();
            });
          });
      });
      zip.on("end", () => {
        if (!ended) {
          ended = true;
          resolve2();
        }
      });
      zip.readEntry();
    })
  );
}
async function parseWorkbook(buffer) {
  try {
    await validateZip(buffer);
  } catch {
    ensure(false, 400, "INVALID_XLSX", "\u6587\u4EF6\u65E0\u6548\u6216\u89E3\u538B\u4F53\u79EF\u8D85\u8FC720MB");
  }
  const workbook = new import_exceljs.default.Workbook();
  try {
    await workbook.xlsx.load(buffer);
  } catch {
    ensure(false, 400, "INVALID_XLSX", "\u65E0\u6CD5\u89E3\u6790XLSX\u6587\u4EF6");
  }
  const sheet = workbook.worksheets[0];
  ensure(sheet, 400, "NO_SHEET", "\u6587\u4EF6\u6CA1\u6709\u5DE5\u4F5C\u8868");
  ensure(
    columns.every(
      (name, index) => sheet.getRow(1).getCell(index + 1).text === name
    ),
    400,
    "INVALID_COLUMNS",
    "\u8868\u5934\u987B\u4E3A\uFF1A" + columns.join("\u3001")
  );
  ensure(
    sheet.rowCount <= 1001,
    413,
    "TOO_MANY_ROWS",
    "\u6BCF\u6587\u4EF6\u6700\u591A1000\u884C\uFF0C\u8BF7\u5206\u6587\u4EF6\u5BFC\u5165"
  );
  const rows = [];
  const seen = /* @__PURE__ */ new Set();
  for (let line = 2; line <= sheet.rowCount; line++) {
    const row = sheet.getRow(line);
    if (row.actualCellCount === 0 || columns.every((_, i) => !row.getCell(i + 1).text.trim()))
      continue;
    if (typeof row.getCell(1).value !== "string") {
      rows.push({
        line,
        error: "\u5B66\u53F7\u5FC5\u987B\u4E3A\u6587\u672C\u5355\u5143\u683C\uFF1B\u6570\u5B57\u6216\u79D1\u5B66\u8BA1\u6570\u6CD5\u65E0\u6CD5\u53EF\u9760\u6062\u590D\uFF0C\u8BF7\u91CD\u65B0\u586B\u5199\u6A21\u677F"
      });
      continue;
    }
    const values = {};
    let invalid = false;
    for (const [index, key] of [
      "studentId",
      "name",
      "gender",
      "college",
      "major",
      "className",
      "grade"
    ].entries()) {
      const cell = row.getCell(index + 1);
      if (typeof cell.value === "object" && cell.value !== null) {
        invalid = true;
        break;
      }
      values[key] = key === "studentId" ? cell.text : cell.text.trim();
    }
    if (invalid) {
      rows.push({ line, error: "\u4E0D\u652F\u6301\u516C\u5F0F\u3001\u8D85\u94FE\u63A5\u6216\u5BCC\u6587\u672C\u5355\u5143\u683C" });
      continue;
    }
    if (!values.gender) values.gender = "\u672A\u586B\u5199";
    const parsed = memberSchema.safeParse(values);
    if (!parsed.success) {
      rows.push({
        line,
        error: parsed.error.issues.map((e) => `${e.path.join(".")}: ${e.message}`).join("\uFF1B")
      });
      continue;
    }
    const member = {
      studentId: parsed.data.studentId,
      name: parsed.data.name,
      gender: parsed.data.gender,
      college: parsed.data.college,
      major: parsed.data.major,
      className: parsed.data.className,
      grade: parsed.data.grade
    };
    const duplicate = seen.has(member.studentId);
    seen.add(member.studentId);
    rows.push({
      line,
      member,
      ...duplicate ? { error: "\u6587\u4EF6\u5185\u5B66\u53F7\u91CD\u590D" } : {}
    });
  }
  ensure(rows.length > 0, 400, "EMPTY_FILE", "\u6CA1\u6709\u53EF\u5BFC\u5165\u7684\u6570\u636E\u884C");
  return rows;
}

// src/members/service.ts
var failure = (status, code, message) => ({
  status,
  error: { code, message }
});
var MemberService = class {
  constructor(store, clock = () => Date.now()) {
    this.store = store;
    this.clock = clock;
  }
  now() {
    return new Date(this.clock()).toISOString();
  }
  async control(tx) {
    const control = await tx.get("system", "control");
    ensure(control?.initialized, 503, "NOT_INITIALIZED", "\u6210\u5458\u7CFB\u7EDF\u5C1A\u672A\u521D\u59CB\u5316");
    control.revision++;
    await tx.set("system", "control", control);
    return control;
  }
  async audit(tx, actor, action, target, fields = []) {
    const id = (0, import_node_crypto2.randomUUID)();
    const log = {
      id,
      actor,
      action,
      target,
      fields,
      createdAt: this.now()
    };
    await tx.set("audit_logs", id, log);
  }
  async identity(tx, user) {
    const roles = await Promise.all(
      user.roleIds.map((id) => tx.get("roles", id))
    );
    const permissions = [
      ...new Set(roles.flatMap((role) => role?.permissionIds ?? []))
    ];
    return {
      roles: roles.flatMap(
        (role) => role ? [{ id: role.id, name: role.name }] : []
      ),
      member: user,
      permissions,
      super: roles.some((role) => role?.super === true)
    };
  }
  require(ctx, permission) {
    ensure(
      ctx.super || ctx.permissions.includes(permission),
      403,
      "FORBIDDEN",
      "\u6CA1\u6709\u6267\u884C\u6B64\u64CD\u4F5C\u7684\u6743\u9650"
    );
  }
  async authenticate(tx, token, control, allowActivation = false) {
    ensure(token, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
    const sessionId = digest(token);
    const session = await tx.get("sessions", sessionId);
    ensure(
      session && session.expiresAt > this.clock() && session.idleExpiresAt > this.clock(),
      401,
      "SESSION_EXPIRED",
      "\u4F1A\u8BDD\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55"
    );
    const user = await tx.get("users", session.uid);
    ensure(
      user && user.status === "active" && user.version === session.version,
      401,
      "SESSION_REVOKED",
      "\u8D26\u53F7\u6216\u4F1A\u8BDD\u5DF2\u5931\u6548"
    );
    ensure(
      !user.mustChangePassword || allowActivation,
      403,
      "PASSWORD_CHANGE_REQUIRED",
      "\u8BF7\u5148\u4FEE\u6539\u521D\u59CB\u5BC6\u7801"
    );
    if (user.mustChangePassword)
      ensure(
        Date.parse(user.activationExpiresAt) > this.clock(),
        401,
        "ACTIVATION_EXPIRED",
        "\u6FC0\u6D3B\u51ED\u636E\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u91CD\u7F6E"
      );
    session.idleExpiresAt = Math.min(
      session.expiresAt,
      this.clock() + 30 * 6e4
    );
    await tx.set("sessions", sessionId, session);
    return { ...await this.identity(tx, user), control, sessionId };
  }
  async secure(token, fn, activation = false) {
    return this.store.run(
      async (tx) => fn(
        tx,
        await this.authenticate(tx, token, await this.control(tx), activation)
      )
    );
  }
  async manageable(tx, ctx, user) {
    const identity = await this.identity(tx, user);
    ensure(
      ctx.super || !identity.super && identity.permissions.every((p) => ctx.permissions.includes(p)),
      403,
      "SCOPE_EXCEEDED",
      "\u4E0D\u80FD\u7BA1\u7406\u6743\u9650\u9AD8\u4E8E\u81EA\u8EAB\u7684\u6210\u5458"
    );
  }
  async adjustRoles(tx, user, newIds) {
    for (const id of /* @__PURE__ */ new Set([...user.roleIds, ...newIds])) {
      const role = await tx.get("roles", id);
      ensure(role, 400, "INVALID_ROLE", "\u89D2\u8272\u4E0D\u5B58\u5728");
      role.memberCount += Number(newIds.includes(id)) - Number(user.roleIds.includes(id));
      await tx.set("roles", id, role);
    }
  }
  async protectLast(tx, ctx, user, changes) {
    const was = (await this.identity(tx, user)).super && user.status === "active";
    const next = { ...user, ...changes };
    const will = (await this.identity(tx, next)).super && next.status === "active";
    const count = ctx.control.superAdminCount + Number(will) - Number(was);
    ensure(
      count >= 1,
      409,
      "LAST_SUPER_ADMIN",
      "\u4E0D\u80FD\u5220\u9664\u3001\u7981\u7528\u6216\u964D\u7EA7\u6700\u540E\u4E00\u4E2A\u8D85\u7EA7\u7BA1\u7406\u5458"
    );
    ctx.control.superAdminCount = count;
    await tx.set("system", "control", ctx.control);
  }
  async createMember(tx, input, actor, password = "123456", roleIds = ["role_member"], mustChangePassword = true) {
    const data = memberSchema.parse(input);
    ensure(
      !await tx.get("student_ids", studentIdKey(data.studentId)),
      409,
      "STUDENT_ID_EXISTS",
      "\u5B66\u53F7\u5DF2\u5B58\u5728\uFF08\u5305\u62EC\u8F6F\u5220\u9664\u8D26\u53F7\uFF09"
    );
    const uid = (0, import_node_crypto2.randomUUID)();
    const now = this.now();
    const user = {
      ...data,
      uid,
      nickname: data.nickname ?? data.name,
      roleIds,
      status: "active",
      mustChangePassword,
      createdAt: now,
      updatedAt: now,
      version: 1,
      activationExpiresAt: new Date(this.clock() + 7 * 864e5).toISOString()
    };
    await this.adjustRoles(tx, { ...user, roleIds: [] }, roleIds);
    await tx.set("users", uid, user);
    await tx.set("student_ids", studentIdKey(data.studentId), { uid });
    await tx.set("credentials", uid, { hash: await hashPassword(password) });
    await this.audit(tx, actor, "members.create", uid, Object.keys(data));
    return user;
  }
  async bootstrap(input, password) {
    const data = memberSchema.parse(input);
    passwordSchema.parse(password);
    return this.store.run(async (tx) => {
      ensure(
        !await tx.get("system", "control"),
        409,
        "ALREADY_INITIALIZED",
        "\u521D\u59CB\u5316\u5DF2\u5B8C\u6210\uFF0C\u62D2\u7EDD\u91CD\u590D\u521D\u59CB\u5316"
      );
      const now = this.now();
      for (const permission of permissionDefinitions)
        await tx.set("permissions", permission.id, {
          ...permission,
          createdAt: now
        });
      const names = [
        "\u8D85\u7EA7\u7BA1\u7406\u5458",
        "\u7BA1\u7406\u5458",
        "\u4F1A\u957F",
        "\u526F\u4F1A\u957F",
        "\u90E8\u957F",
        "\u526F\u90E8\u957F",
        "\u666E\u901A\u6210\u5458"
      ];
      const ids = [
        "role_super",
        "role_admin",
        "role_president",
        "role_vice_president",
        "role_head",
        "role_vice_head",
        "role_member"
      ];
      for (let i = 0; i < ids.length; i++) {
        const role = {
          id: ids[i],
          name: names[i],
          description: "\u521D\u59CB\u89D2\u8272\uFF1B\u793E\u56E2\u804C\u4F4D\u53E6\u5B58\u4E8E\u6210\u5458 position \u5B57\u6BB5",
          permissionIds: i === 0 ? permissionDefinitions.map((p) => p.id) : i === 1 ? permissionDefinitions.filter((p) => p.implemented).map((p) => p.id) : [],
          memberCount: 0,
          builtin: true,
          super: i === 0,
          createdAt: now
        };
        await tx.set("roles", role.id, role);
      }
      const user = await this.createMember(
        tx,
        data,
        "bootstrap",
        password,
        ["role_super"],
        false
      );
      await tx.set("system", "control", {
        initialized: true,
        superAdminCount: 1,
        revision: 1
      });
      await this.audit(tx, "bootstrap", "system.initialize", user.uid);
      return user;
    });
  }
  async login(input, ip) {
    const body = import_zod2.z.object({
      studentId: studentIdSchema,
      password: import_zod2.z.string().min(1).max(128)
    }).strict().parse(input);
    return this.store.run(async (tx) => {
      await this.control(tx);
      for (const [key, limit] of [
        [`account:${body.studentId}`, 10],
        [`ip:${ip}`, 200]
      ]) {
        const id = digest(key);
        let rate = await tx.get(
          "login_limits",
          id
        );
        if (!rate || rate.until <= this.clock())
          rate = { count: 0, until: this.clock() + 15 * 6e4 };
        if (rate.count >= limit)
          return failure(
            429,
            "RATE_LIMITED",
            "\u767B\u5F55\u5C1D\u8BD5\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF715\u5206\u949F\u540E\u518D\u8BD5"
          );
        rate.count++;
        await tx.set("login_limits", id, { ...rate, createdAt: this.now() });
      }
      const mapping = await tx.get(
        "student_ids",
        studentIdKey(body.studentId)
      );
      const user = mapping ? await tx.get("users", mapping.uid) : null;
      const credential = user ? await tx.get("credentials", user.uid) : null;
      const valid = await verifyPassword(body.password, credential?.hash ?? "");
      if (!user || user.status !== "active" || !valid) {
        await this.audit(tx, "anonymous", "auth.login_failed", "redacted");
        return failure(401, "INVALID_CREDENTIALS", "\u5B66\u53F7\u3001\u5BC6\u7801\u9519\u8BEF\u6216\u8D26\u53F7\u4E0D\u53EF\u7528");
      }
      if (user.mustChangePassword && Date.parse(user.activationExpiresAt) <= this.clock())
        return failure(
          401,
          "ACTIVATION_EXPIRED",
          "\u521D\u59CB\u51ED\u636E\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u91CD\u7F6E"
        );
      await tx.set("login_limits", digest(`account:${body.studentId}`), {
        count: 0,
        until: this.clock() + 15 * 6e4,
        createdAt: this.now()
      });
      const token = randomToken();
      const expiresAt = this.clock() + (user.mustChangePassword ? 15 * 6e4 : 8 * 36e5);
      await tx.set("sessions", digest(token), {
        createdAt: this.now(),
        uid: user.uid,
        version: user.version,
        expiresAt,
        idleExpiresAt: Math.min(expiresAt, this.clock() + 30 * 6e4)
      });
      await this.audit(tx, user.uid, "auth.login", user.uid);
      return { data: await this.identity(tx, user), token };
    });
  }
  async authorize(token, permission) {
    return this.secure(token, async (_tx, ctx) => this.require(ctx, permission));
  }
  async prepareImport(token, input) {
    const body = import_zod2.z.object({ file: import_zod2.z.string().min(1).max(3e6) }).strict().parse(input);
    await this.secure(
      token,
      async (_tx, ctx) => this.require(ctx, "members.import")
    );
    const file = Buffer.from(body.file, "base64");
    const hash = digest(file.toString("base64"));
    const rows = await parseWorkbook(file);
    for (let start = 0; start < rows.length; start += 20)
      await Promise.all(
        rows.slice(start, start + 20).map(async (row) => {
          if (row.member && !row.error && await this.store.read(
            "student_ids",
            studentIdKey(row.member.studentId)
          ))
            row.error = "\u5B66\u53F7\u5DF2\u5B58\u5728\uFF08\u5305\u62EC\u8F6F\u5220\u9664\u8D26\u53F7\uFF09";
        })
      );
    ensure(
      Buffer.byteLength(JSON.stringify(rows)) <= 7e5,
      413,
      "IMPORT_TOO_LARGE",
      "\u89E3\u6790\u540E\u6570\u636E\u8FC7\u5927\uFF0C\u8BF7\u62C6\u5206\u6587\u4EF6"
    );
    return this.secure(token, async (tx, ctx) => {
      this.require(ctx, "members.import");
      const existing = await tx.get("import_jobs", hash);
      if (existing) {
        ensure(
          existing.owner === ctx.member.uid || ctx.super,
          403,
          "FORBIDDEN",
          "\u8BE5\u6587\u4EF6\u5DF2\u7531\u5176\u4ED6\u7BA1\u7406\u5458\u5BFC\u5165"
        );
        return { data: existing };
      }
      const job = {
        id: hash,
        hash,
        owner: ctx.member.uid,
        rows,
        offset: 0,
        created: 0,
        skipped: 0,
        status: "preview",
        createdAt: this.now(),
        updatedAt: this.now()
      };
      await tx.set("import_jobs", hash, job);
      await this.audit(tx, ctx.member.uid, "imports.preview", hash);
      return { data: job };
    });
  }
  async execute(token, method, path, input, query) {
    if (method === "POST" && path === "/api/imports/preview")
      return this.prepareImport(token, input);
    return this.secure(
      token,
      async (tx, ctx) => {
        const user = ctx.member;
        if (path === "/api/auth/me" && method === "GET")
          return {
            data: {
              member: user,
              roles: ctx.roles,
              permissions: ctx.permissions,
              super: ctx.super
            }
          };
        if (path === "/api/auth/logout" && method === "POST") {
          await tx.remove("sessions", ctx.sessionId);
          await this.audit(tx, user.uid, "auth.logout", user.uid);
          return { data: { ok: true }, clearCookie: true };
        }
        if (path === "/api/auth/password" && method === "POST") {
          const body = import_zod2.z.object({
            oldPassword: import_zod2.z.string().max(128),
            newPassword: passwordSchema
          }).strict().parse(input);
          const credential = await tx.get("credentials", user.uid);
          ensure(
            credential && await verifyPassword(body.oldPassword, credential.hash),
            400,
            "WRONG_PASSWORD",
            "\u539F\u5BC6\u7801\u9519\u8BEF"
          );
          ensure(
            body.oldPassword !== body.newPassword,
            400,
            "PASSWORD_UNCHANGED",
            "\u65B0\u5BC6\u7801\u4E0D\u80FD\u4E0E\u539F\u5BC6\u7801\u76F8\u540C"
          );
          await tx.set("credentials", user.uid, {
            hash: await hashPassword(body.newPassword)
          });
          await tx.set("users", user.uid, {
            ...user,
            mustChangePassword: false,
            version: user.version + 1,
            updatedAt: this.now()
          });
          await this.audit(tx, user.uid, "auth.password_change", user.uid);
          return { data: { ok: true }, clearCookie: true };
        }
        if (path === "/api/auth/revoke-sessions" && method === "POST") {
          await tx.set("users", user.uid, {
            ...user,
            version: user.version + 1,
            updatedAt: this.now()
          });
          await this.audit(tx, user.uid, "auth.revoke_all", user.uid);
          return { data: { ok: true }, clearCookie: true };
        }
        if (path === "/api/profile" && method === "PATCH") {
          const changes = profileSchema.parse(input);
          const next = { ...user, ...changes, updatedAt: this.now() };
          await tx.set("users", user.uid, next);
          await this.audit(
            tx,
            user.uid,
            "members.profile",
            user.uid,
            Object.keys(changes)
          );
          return { data: next };
        }
        if (path === "/api/members" && method === "GET") {
          this.require(ctx, "members.read");
          const options = listSchema.parse(query);
          const filter = {};
          if (options.status === "all") filter._notDeleted = true;
          else filter.status = options.status;
          if (options.search) filter._search = options.search;
          for (const key of ["college", "className"])
            if (options[key]) filter[key] = options[key];
          if (options.roleId) filter.roleIds = options.roleId;
          const result = await this.store.list("users", filter, {
            offset: (options.page - 1) * options.pageSize,
            limit: options.pageSize
          });
          return {
            data: { ...result, page: options.page, pageSize: options.pageSize }
          };
        }
        if (path === "/api/members" && method === "POST") {
          this.require(ctx, "members.create");
          return { data: await this.createMember(tx, input, user.uid) };
        }
        if (path === "/api/members/export" && method === "GET") {
          this.require(ctx, "members.export");
          this.require(ctx, "members.read");
          const options = import_zod2.z.object({
            page: import_zod2.z.coerce.number().int().min(1).max(1e4).default(1)
          }).strict().parse(query);
          const result = await this.store.list(
            "users",
            { _notDeleted: true },
            { offset: (options.page - 1) * 100, limit: 100 }
          );
          await this.audit(tx, user.uid, "members.export", "users", [
            `page:${options.page}`
          ]);
          return { data: { ...result, page: options.page, pageSize: 100 } };
        }
        const memberMatch = path.match(
          /^\/api\/members\/([a-zA-Z0-9-]+)(?:\/(roles|password|status|restore|anonymize))?$/
        );
        if (memberMatch) {
          const id = memberMatch[1];
          const action = memberMatch[2];
          const target = await tx.get("users", id);
          ensure(target, 404, "NOT_FOUND", "\u6210\u5458\u4E0D\u5B58\u5728");
          if (!action && method === "GET") {
            this.require(ctx, "members.read");
            return { data: target };
          }
          const required = action === "roles" ? "roles.assign" : action === "password" ? "members.password" : action === "status" ? "members.status" : action === "restore" || action === "anonymize" || method === "DELETE" ? "members.delete" : "members.edit";
          this.require(ctx, required);
          await this.manageable(tx, ctx, target);
          let next = { ...target, updatedAt: this.now() };
          let fields = [];
          if (!action && method === "PATCH") {
            ensure(target.status !== "deleted", 409, "DELETED", "\u8BF7\u5148\u6062\u590D\u6210\u5458");
            const changes = editSchema.parse(input);
            fields = Object.keys(changes);
            if (changes.studentId && changes.studentId !== target.studentId) {
              ensure(
                !await tx.get("student_ids", studentIdKey(changes.studentId)),
                409,
                "STUDENT_ID_EXISTS",
                "\u5B66\u53F7\u5DF2\u5B58\u5728"
              );
              await tx.remove("student_ids", studentIdKey(target.studentId));
              await tx.set("student_ids", studentIdKey(changes.studentId), {
                uid: id
              });
              next.version++;
            }
            next = { ...next, ...changes };
          } else if (action === "roles" && method === "PUT") {
            ensure(target.status !== "deleted", 409, "DELETED", "\u8BF7\u5148\u6062\u590D\u6210\u5458");
            const body = import_zod2.z.object({
              roleIds: import_zod2.z.array(import_zod2.z.string().min(1).max(64)).min(1).max(10)
            }).strict().parse(input);
            const roleIds = [...new Set(body.roleIds)];
            for (const roleId of roleIds) {
              const role = await tx.get("roles", roleId);
              ensure(role, 400, "INVALID_ROLE", "\u89D2\u8272\u4E0D\u5B58\u5728");
              ensure(
                ctx.super || !role.super && role.permissionIds.every(
                  (p) => ctx.permissions.includes(p)
                ),
                403,
                "SCOPE_EXCEEDED",
                "\u4E0D\u80FD\u5206\u914D\u8D85\u51FA\u81EA\u8EAB\u6743\u9650\u7684\u89D2\u8272"
              );
            }
            await this.protectLast(tx, ctx, target, { roleIds });
            await this.adjustRoles(tx, target, roleIds);
            next.roleIds = roleIds;
            next.version++;
            fields = ["roleIds"];
          } else if (action === "password" && method === "POST") {
            import_zod2.z.object({}).strict().parse(input);
            ensure(target.status !== "deleted", 409, "DELETED", "\u8BF7\u5148\u6062\u590D\u6210\u5458");
            await tx.set("credentials", id, {
              hash: await hashPassword("123456")
            });
            next.mustChangePassword = true;
            next.activationExpiresAt = new Date(
              this.clock() + 7 * 864e5
            ).toISOString();
            next.version++;
            fields = ["credentials"];
          } else if (action === "status" && method === "PATCH") {
            const body = import_zod2.z.object({ status: import_zod2.z.enum(["active", "disabled"]) }).strict().parse(input);
            ensure(
              target.status !== "deleted",
              409,
              "DELETED",
              "\u8BF7\u4F7F\u7528\u6062\u590D\u64CD\u4F5C"
            );
            await this.protectLast(tx, ctx, target, body);
            next.status = body.status;
            next.version++;
            fields = ["status"];
          } else if (action === "restore" && method === "POST") {
            ensure(
              target.status === "deleted" && !target.anonymizedAt,
              409,
              "NOT_RESTORABLE",
              "\u8D26\u53F7\u4E0D\u53EF\u6062\u590D"
            );
            next.status = "disabled";
            delete next.deletedAt;
            next.version++;
            fields = ["status"];
          } else if (!action && method === "DELETE") {
            await this.protectLast(tx, ctx, target, { status: "deleted" });
            next.status = "deleted";
            next.deletedAt = this.now();
            next.version++;
            fields = ["status", "deletedAt"];
          } else if (action === "anonymize" && method === "POST") {
            ensure(
              ctx.super && target.status === "deleted",
              403,
              "FORBIDDEN",
              "\u4EC5\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u533F\u540D\u5316\u5DF2\u8F6F\u5220\u9664\u6210\u5458"
            );
            ensure(
              !target.anonymizedAt,
              409,
              "ALREADY_ANONYMIZED",
              "\u5DF2\u7ECF\u533F\u540D\u5316"
            );
            await tx.set("privacy_jobs", id, {
              id,
              uid: id,
              studentIdDigest: studentIdKey(target.studentId),
              status: "pending",
              createdAt: this.now()
            });
            await this.adjustRoles(tx, target, []);
            await tx.remove("student_ids", studentIdKey(target.studentId));
            await tx.remove("credentials", id);
            next = {
              ...next,
              studentId: "",
              name: "\u5DF2\u533F\u540D\u5316",
              nickname: "\u5DF2\u533F\u540D\u5316",
              gender: "\u672A\u586B\u5199",
              college: "",
              major: "",
              className: "",
              grade: "",
              phone: "",
              email: "",
              avatar: "",
              position: "",
              roleIds: [],
              anonymizedAt: this.now(),
              version: next.version + 1
            };
            fields = ["personalData"];
          } else throw new ApiError(405, "METHOD_NOT_ALLOWED", "\u65B9\u6CD5\u4E0D\u652F\u6301");
          await tx.set("users", id, next);
          await this.audit(
            tx,
            user.uid,
            `members.${action ?? (method === "DELETE" ? "delete" : "edit")}`,
            id,
            fields
          );
          return { data: next };
        }
        if (path === "/api/permissions" && method === "GET") {
          this.require(ctx, "roles.read");
          return {
            data: (await this.store.list(
              "permissions",
              {},
              { offset: 0, limit: 100 }
            )).items
          };
        }
        if (path === "/api/roles" && method === "GET") {
          this.require(ctx, "roles.read");
          const page = import_zod2.z.coerce.number().int().min(1).max(100).parse(query.page ?? 1);
          const result = await this.store.list(
            "roles",
            {},
            { offset: (page - 1) * 100, limit: 100 }
          );
          return { data: { ...result, page, pageSize: 100 } };
        }
        if (path === "/api/roles" && method === "POST" || /^\/api\/roles\/[a-zA-Z0-9_-]+$/.test(path)) {
          this.require(ctx, "roles.manage");
          const id = path.split("/")[3] ?? (0, import_node_crypto2.randomUUID)();
          const previous = await tx.get("roles", id);
          if (method !== "POST")
            ensure(previous, 404, "NOT_FOUND", "\u89D2\u8272\u4E0D\u5B58\u5728");
          if (previous)
            ensure(
              !previous.super && (ctx.super || previous.permissionIds.every(
                (p) => ctx.permissions.includes(p)
              )),
              403,
              "SCOPE_EXCEEDED",
              "\u6B64\u89D2\u8272\u8D85\u51FA\u53EF\u7BA1\u7406\u8303\u56F4"
            );
          if (method === "DELETE") {
            ensure(
              previous && !previous.builtin && previous.memberCount === 0,
              409,
              "ROLE_IN_USE",
              "\u521D\u59CB\u89D2\u8272\u6216\u4ECD\u88AB\u6210\u5458\u4F7F\u7528\u7684\u89D2\u8272\u4E0D\u53EF\u5220\u9664"
            );
            await tx.remove("roles", id);
            await this.audit(tx, user.uid, "roles.delete", id);
            return { data: { ok: true } };
          }
          ensure(
            method === "POST" || method === "PUT",
            405,
            "METHOD_NOT_ALLOWED",
            "\u65B9\u6CD5\u4E0D\u652F\u6301"
          );
          ensure(
            !(method === "POST" && path !== "/api/roles"),
            405,
            "METHOD_NOT_ALLOWED",
            "\u65B9\u6CD5\u4E0D\u652F\u6301"
          );
          const data = roleSchema.parse(input);
          ensure(
            data.name !== "\u8D85\u7EA7\u7BA1\u7406\u5458",
            400,
            "RESERVED_ROLE_NAME",
            "\u8D85\u7EA7\u7BA1\u7406\u5458\u4E3A\u4FDD\u7559\u89D2\u8272\u540D\u79F0"
          );
          for (const permission of data.permissionIds) {
            ensure(
              await tx.get("permissions", permission),
              400,
              "INVALID_PERMISSION",
              "\u6743\u9650\u4E0D\u5B58\u5728"
            );
            ensure(
              ctx.super || ctx.permissions.includes(permission),
              403,
              "SCOPE_EXCEEDED",
              "\u4E0D\u80FD\u6388\u4E88\u8D85\u51FA\u81EA\u8EAB\u7684\u6743\u9650"
            );
          }
          const role = {
            ...data,
            id,
            builtin: previous?.builtin ?? false,
            super: false,
            memberCount: previous?.memberCount ?? 0,
            createdAt: previous?.createdAt ?? this.now()
          };
          await tx.set("roles", id, role);
          await this.audit(
            tx,
            user.uid,
            previous ? "roles.edit" : "roles.create",
            id,
            ["name", "description", "permissionIds"]
          );
          return { data: role };
        }
        const jobMatch = path.match(
          /^\/api\/imports\/([a-f0-9]{64})(?:\/(process))?$/
        );
        if (jobMatch) {
          this.require(ctx, "members.import");
          const job = await tx.get("import_jobs", jobMatch[1]);
          ensure(job, 404, "NOT_FOUND", "\u5BFC\u5165\u4EFB\u52A1\u4E0D\u5B58\u5728");
          ensure(
            job.owner === user.uid || ctx.super,
            403,
            "FORBIDDEN",
            "\u4E0D\u80FD\u8BFB\u53D6\u4ED6\u4EBA\u7684\u5BFC\u5165\u4EFB\u52A1"
          );
          if (method === "GET" && !jobMatch[2]) return { data: job };
          ensure(
            method === "POST" && jobMatch[2] === "process",
            405,
            "METHOD_NOT_ALLOWED",
            "\u65B9\u6CD5\u4E0D\u652F\u6301"
          );
          const body = import_zod2.z.object({ offset: import_zod2.z.number().int().min(0) }).strict().parse(input);
          if (body.offset !== job.offset || job.status === "completed")
            return { data: job };
          const end = Math.min(job.offset + 20, job.rows.length);
          for (let i = job.offset; i < end; i++) {
            const row = job.rows[i];
            if (!row.error && row.member) {
              if (await tx.get("student_ids", studentIdKey(row.member.studentId)))
                row.error = "\u5B66\u53F7\u5DF2\u5B58\u5728\u6216\u88AB\u5176\u4ED6\u4EFB\u52A1\u521B\u5EFA";
              else
                row.uid = (await this.createMember(tx, row.member, user.uid)).uid;
            }
            if (row.uid) job.created++;
            else job.skipped++;
          }
          job.offset = end;
          job.status = end === job.rows.length ? "completed" : "processing";
          job.updatedAt = this.now();
          await tx.set("import_jobs", job.id, job);
          await this.audit(tx, user.uid, "members.import", job.id, [
            `offset:${body.offset}`,
            `created:${job.created}`,
            `skipped:${job.skipped}`
          ]);
          return { data: job };
        }
        if (path === "/api/audit" && method === "GET") {
          this.require(ctx, "audit.read");
          const page = import_zod2.z.coerce.number().int().min(1).max(1e4).parse(query.page ?? 1);
          const result = await this.store.list(
            "audit_logs",
            {},
            { offset: (page - 1) * 50, limit: 50 }
          );
          return { data: { ...result, page, pageSize: 50 } };
        }
        throw new ApiError(404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
      },
      ["/api/auth/me", "/api/auth/logout", "/api/auth/password"].includes(path)
    );
  }
};

// src/offline-bootstrap.ts
async function generateBootstrapSql(input, password) {
  const records = /* @__PURE__ */ new Map();
  const store = {
    read: async () => null,
    list: async () => {
      throw new Error("NOT_SUPPORTED");
    },
    run: async (fn) => fn({
      get: async (c, id) => records.get(c + "/" + id)?.data ?? null,
      set: async (c, id, data) => {
        records.set(c + "/" + id, { collection: c, id, data });
      },
      remove: async () => {
        throw new Error("NOT_SUPPORTED");
      }
    })
  };
  await new MemberService(store).bootstrap(input, password);
  const literal = (value) => "'" + value.replace(/'/g, "''") + "'";
  let sql = "BEGIN;\nSET LOCAL standard_conforming_strings=on;\nSELECT pg_advisory_xact_lock(1991,1);\nDO $$ BEGIN IF EXISTS(SELECT 1 FROM electronicclub.system WHERE id='control') THEN RAISE EXCEPTION 'ALREADY_INITIALIZED'; END IF; END $$;\n";
  for (const { collection, id, data } of records.values())
    sql += `INSERT INTO electronicclub.${collection}(id,data) VALUES(${literal(id)},${literal(JSON.stringify(data))}::jsonb);
`;
  for (const { collection, id, data } of records.values())
    if (collection === "users")
      for (const role of data.roleIds)
        sql += `INSERT INTO electronicclub.user_roles(user_id,role_id) VALUES(${literal(id)},${literal(role)});
`;
  return sql + "COMMIT;\n";
}
async function main() {
  const output = process.argv.find((arg) => arg.startsWith("--output="))?.slice(9);
  if (!output || !(0, import_node_path.isAbsolute)(output) || (0, import_node_path.resolve)(output).startsWith((0, import_node_path.resolve)(process.cwd()) + import_node_path.sep) || !process.env.BOOTSTRAP_PASSWORD || !process.env.BOOTSTRAP_STUDENT_ID || !process.env.BOOTSTRAP_NAME)
    throw new Error("PRIVATE_CONFIGURATION_REQUIRED");
  const sql = await generateBootstrapSql(
    {
      studentId: process.env.BOOTSTRAP_STUDENT_ID,
      name: process.env.BOOTSTRAP_NAME,
      nickname: process.env.BOOTSTRAP_NICKNAME || void 0
    },
    process.env.BOOTSTRAP_PASSWORD
  );
  await (0, import_promises.writeFile)(output, sql, { mode: 384, flag: "wx" });
  console.log(
    "Private initialization SQL created. Contains sensitive hashes; do not upload to GitHub or the public function ZIP."
  );
}
if (process.argv[1]?.endsWith("offline-bootstrap.ts") || process.argv[1]?.endsWith("offline-bootstrap.js"))
  main().catch(() => {
    console.error("Offline initialization plan failed; no credentials logged.");
    process.exitCode = 1;
  });
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  generateBootstrapSql
});
