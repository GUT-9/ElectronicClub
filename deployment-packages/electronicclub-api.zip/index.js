"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var index_exports = {};
__export(index_exports, {
  createHandler: () => createHandler,
  main: () => main
});
module.exports = __toCommonJS(index_exports);

// src/members/login-context.ts
var import_node_net = require("node:net");
var import_node_crypto = require("node:crypto");

// ../../packages/shared/src/proxy-secret.ts
function normalizeProxySecret(value) {
  if (typeof value !== "string") return null;
  let secret = value.trim().replace(/^ECLUB_PROXY_SECRET\s*=\s*/, "").trim();
  const quote = secret[0];
  if ((quote === '"' || quote === "'") && secret[secret.length - 1] === quote)
    secret = secret.slice(1, -1);
  secret = secret.replace(/\s/g, "");
  return /^[0-9]{4}$/.test(secret) || secret.length === 64 && /^[a-f0-9]+$/i.test(secret) ? secret : null;
}

// ../../packages/shared/src/student-id.ts
var STUDENT_ID_MESSAGE = "\u5B66\u53F7\u987B\u4E3A4\u201324\u4F4D\u82F1\u6587\u5B57\u6BCD\u6216\u6570\u5B57\uFF0C\u4E0D\u5141\u8BB8\u7A7A\u683C\u6216\u7279\u6B8A\u5B57\u7B26";
function isValidStudentId(value) {
  return typeof value === "string" && value.length >= 4 && value.length <= 24 && !/[^A-Za-z0-9]/.test(value);
}
function normalizeStudentId(value) {
  if (!isValidStudentId(value)) throw new Error(STUDENT_ID_MESSAGE);
  return value.toUpperCase();
}

// ../../packages/shared/src/stage3.ts
var MAX_EVENT_MANAGERS = 100;
var DEFAULT_CHECKIN_TTL_SECONDS = 30 * 60;
var MAX_CHECKIN_TTL_SECONDS = 24 * 60 * 60;

// ../../packages/shared/src/forum.ts
var FORUM_PERMISSIONS = [
  "forum.boards.manage",
  "forum.posts.review",
  "forum.posts.pin",
  "forum.posts.feature",
  "forum.posts.lock",
  "forum.posts.delete",
  "forum.comments.moderate",
  "forum.reports.manage",
  "forum.users.restrict"
];
var DEFAULT_FORUM_BOARDS = [
  "\u7EFC\u5408\u4EA4\u6D41",
  "\u5355\u7247\u673A\u4E0E\u5D4C\u5165\u5F0F",
  "\u7535\u8DEF\u8BBE\u8BA1\u4E0E PCB",
  "\u710A\u63A5\u4E0E\u7535\u5B50\u5236\u4F5C",
  "\u7535\u8D5B\u4EA4\u6D41",
  "\u9879\u76EE\u5206\u4EAB",
  "\u7F16\u7A0B\u4E0E\u8F6F\u4EF6\u5F00\u53D1"
].map((name, index) => ({
  id: `board-${index + 1}`,
  name,
  description: name === "\u7535\u8D5B\u4EA4\u6D41" ? "\u5168\u56FD\u5927\u5B66\u751F\u7535\u5B50\u8BBE\u8BA1\u7ADE\u8D5B\u5B66\u4E60\u4E0E\u4EA4\u6D41" : "\u5206\u4EAB\u5B9E\u8DF5\u7ECF\u9A8C\uFF0C\u4E00\u8D77\u89E3\u51B3\u95EE\u9898",
  position: index + 1,
  status: "active",
  requireReview: false
}));

// ../../packages/shared/src/media.ts
var MAX_SOURCE_IMAGE_BYTES = 3 * 1024 * 1024;
var MAX_MEDIA_IMAGE_BYTES = 50 * 1024;
var MEDIA_CHUNK_BYTES = 24 * 1024;
var MAX_BODY_IMAGES = 12;
var mediaIdPattern = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
function mediaReference(value) {
  return new RegExp(`^media:(${mediaIdPattern})$`).exec(value)?.[1] ?? null;
}
function bodyMedia(content) {
  return [
    ...new Set(
      Array.from(
        content.matchAll(
          new RegExp(
            `^!\\[[^\\]\\n]{0,160}\\]\\(media:(${mediaIdPattern})\\)\\s*$`,
            "gm"
          )
        ),
        (m) => m[1]
      )
    )
  ];
}
function permissionGroup(id) {
  if (id.startsWith("members."))
    return [
      "members.password",
      "members.status",
      "members.delete",
      "members.purge"
    ].includes(id) ? "\u8D26\u53F7\u4E0E\u5B89\u5168" : "\u6210\u5458\u8D44\u6599";
  if (id === "security.logins.read") return "\u8D26\u53F7\u4E0E\u5B89\u5168";
  if (id.startsWith("roles.")) return "\u89D2\u8272\u4E0E\u6388\u6743";
  if (id.startsWith("events.registrations.")) return "\u62A5\u540D\u7BA1\u7406";
  if (id.startsWith("events.checkin.")) return "\u6D3B\u52A8\u7B7E\u5230";
  if (id.startsWith("events.")) return "\u6D3B\u52A8\u53D1\u5E03";
  if (id.startsWith("articles."))
    return id === "articles.manage" ? "\u9884\u7559\u529F\u80FD" : "\u65B0\u95FB\u4E0E\u516C\u544A";
  if (id === "announcements.popup.manage") return "\u5168\u7AD9\u5F39\u7A97";
  if (id === "forum.boards.manage") return "\u793E\u533A\u7248\u5757";
  if (id.startsWith("forum.posts.")) return "\u793E\u533A\u5E16\u5B50";
  if (id === "forum.comments.moderate") return "\u793E\u533A\u8BC4\u8BBA";
  if (id.startsWith("forum.")) return "\u793E\u533A\u4E3E\u62A5\u4E0E\u79E9\u5E8F";
  if (id === "resources.manage") return "\u793E\u56E2\u8D44\u6599";
  if (id === "audit.read") return "\u64CD\u4F5C\u5BA1\u8BA1";
  return "\u9884\u7559\u529F\u80FD";
}

// ../../packages/shared/src/resources.ts
var RESOURCE_TYPES = {
  pdf: "application/pdf",
  doc: "application/msword",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xls: "application/vnd.ms-excel",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ppt: "application/vnd.ms-powerpoint",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  zip: "application/zip",
  "7z": "application/x-7z-compressed",
  txt: "text/plain",
  csv: "text/csv"
};
var RESOURCE_ACCEPT = Object.keys(RESOURCE_TYPES).map((k) => "." + k).join(",");

// src/members/login-context.ts
function ip(value) {
  if (typeof value !== "string") return null;
  const candidate = value.trim();
  return candidate.length <= 64 && (0, import_node_net.isIP)(candidate) ? candidate : null;
}
function signedProxyIp(headers, now = Date.now()) {
  const key2 = normalizeProxySecret(process.env.ECLUB_PROXY_SECRET), address = ip(headers["x-eclub-client-ip"]), timestamp = headers["x-eclub-proxy-time"], signature = headers["x-eclub-proxy-signature"];
  if (!key2 || !address || !timestamp || !/^\d{13}$/.test(timestamp) || Math.abs(now - Number(timestamp)) > 6e4 || !signature || !/^[a-f0-9]{64}$/i.test(signature))
    return null;
  const expected = (0, import_node_crypto.createHmac)("sha256", key2).update(
    `eclub-proxy-ip-v1
${timestamp}
${address}
${headers["user-agent"] ?? ""}`
  ).digest();
  return (0, import_node_crypto.timingSafeEqual)(expected, Buffer.from(signature, "hex")) ? address : null;
}
function loginContext(context, headers) {
  const signed = signedProxyIp(headers);
  let address = signed || ip(context?.sourceIp) || ip(context?.http?.sourceIp) || ip(context?.identity?.sourceIp);
  let ipSource = signed ? "trusted-header" : address ? "gateway" : "unavailable";
  const trusted = process.env.LOGIN_TRUSTED_IP_HEADER;
  if (!address && ["x-real-ip", "x-forwarded-for"].includes(trusted ?? "")) {
    const value = headers[trusted];
    address = ip(trusted === "x-forwarded-for" ? value?.split(",")[0] : value);
    if (address) ipSource = "trusted-header";
  }
  const userAgent = (headers["user-agent"] ?? "").slice(0, 512).split("").map((c) => {
    const n = c.charCodeAt(0);
    return n < 32 || n >= 127 && n <= 159 ? " " : c;
  }).join("").trim();
  const version = (pattern) => pattern.exec(userAgent)?.[1]?.replaceAll("_", ".") ?? "";
  let browser = "\u672A\u8BC6\u522B", os = "\u672A\u8BC6\u522B", device = "\u5176\u4ED6\u8BBE\u5907";
  const browsers = [
    ["Edge", /(?:Edg|EdgA|EdgiOS)\/([\d.]{1,24})/],
    ["Opera", /(?:OPR|Opera)\/([\d.]{1,24})/],
    ["Firefox", /(?:Firefox|FxiOS)\/([\d.]{1,24})/],
    ["Chrome", /(?:Chrome|CriOS)\/([\d.]{1,24})/],
    ["Safari", /Version\/([\d.]{1,24}).*Safari\//]
  ];
  for (const [name, pattern] of browsers) {
    const v = version(pattern);
    if (v) {
      browser = name + " " + v;
      break;
    }
  }
  if (/Android/i.test(userAgent)) {
    os = "Android " + version(/Android ([\d.]{1,16})/);
    device = /Mobile/i.test(userAgent) ? "\u624B\u673A" : "\u5E73\u677F";
  } else if (/iPhone|iPad|iPod/i.test(userAgent)) {
    os = "iOS " + version(/(?:CPU (?:iPhone )?OS|iPhone OS) ([\d_]{1,16})/);
    device = /iPad/.test(userAgent) ? "\u5E73\u677F" : "\u624B\u673A";
  } else if (/Windows NT/i.test(userAgent)) {
    const v = version(/Windows NT ([\d.]{1,16})/);
    os = v === "10.0" ? "Windows 10/11" : "Windows " + v;
    device = "\u7535\u8111";
  } else if (/Macintosh|Mac OS X/i.test(userAgent)) {
    os = "macOS " + version(/Mac OS X ([\d_]{1,16})/);
    device = /Mobile/.test(userAgent) ? "\u5E73\u677F" : "\u7535\u8111";
  } else if (/Linux/i.test(userAgent)) {
    os = "Linux";
    device = "\u7535\u8111";
  }
  return {
    ip: address,
    ipSource,
    userAgent,
    device: device.trim(),
    os: os.trim(),
    browser
  };
}
function safeLoginContext(value) {
  if (typeof value === "string") return loginContext({ sourceIp: value }, {});
  const parsed = loginContext(
    value.ipSource === "gateway" ? { sourceIp: value.ip ?? void 0 } : void 0,
    { "user-agent": value.userAgent }
  );
  const address = ip(value.ip);
  return {
    ...parsed,
    ip: address,
    ipSource: address ? value.ipSource : "unavailable"
  };
}

// src/members/stats-query.ts
var MEMBER_STATS_SQL = `SELECT jsonb_build_object('activeMembers',count(*),'loggedInMembers',count(*) FILTER(WHERE has_login),'activatedMembers',count(*) FILTER(WHERE has_login AND has_password_change AND NOT must_change),'pendingMembers',count(*) FILTER(WHERE NOT(has_login AND has_password_change AND NOT must_change))) AS result FROM(SELECT u.id,coalesce((u.data->>'mustChangePassword')::boolean,true) AS must_change,EXISTS(SELECT 1 FROM electronicclub.audit_logs a WHERE a.data->>'actor'=u.id AND a.data->>'action'='auth.login') AS has_login,EXISTS(SELECT 1 FROM electronicclub.audit_logs a WHERE a.data->>'actor'=u.id AND a.data->>'action'='auth.password_change') AS has_password_change FROM electronicclub.users u WHERE u.data->>'status'='active' AND u.data->>'anonymizedAt' IS NULL) m`;

// src/public-site-query.ts
var PUBLIC_EXPORT_SQL = `WITH
 e AS (SELECT id,data FROM electronicclub.events WHERE data->>'status'='published'),
 a AS (SELECT id,data FROM electronicclub.articles WHERE data->>'status'='published'),
 b AS (SELECT id,data FROM electronicclub.forum_boards WHERE data->>'status' IN ('active','disabled')),
 p AS (SELECT v.id,v.data FROM electronicclub.forum_posts v JOIN b ON b.id=v.data->>'boardId' WHERE v.data->>'status'='published'),
 c AS (SELECT v.id,v.data FROM electronicclub.forum_comments v JOIN p ON p.id=v.data->>'postId' WHERE v.data->>'status' IN ('published','deleted')),
 pop AS (SELECT id,data FROM electronicclub.popup_announcements WHERE data->>'enabled'='true' AND data->>'state' NOT IN ('retired','disabled') AND
   ((data->>'targetType'='event' AND data->>'targetId' IN (SELECT id FROM e)) OR (data->>'targetType'='article' AND data->>'targetId' IN (SELECT id FROM a)))),
 parents AS (SELECT 'events' kind,id FROM e UNION ALL SELECT 'articles',id FROM a UNION ALL SELECT 'forum_posts',id FROM p),
 m AS (SELECT id FROM electronicclub.media_images WHERE data->>'status'='ready' AND EXISTS(SELECT 1 FROM jsonb_array_elements(data->'bindings') v JOIN parents ON parents.kind=v->>'kind' AND parents.id=v->>'id'))
SELECT jsonb_build_object(
 'events',coalesce((SELECT jsonb_agg(data||jsonb_build_object('id',id)) FROM e),'[]'),
 'articles',coalesce((SELECT jsonb_agg(data||jsonb_build_object('id',id)) FROM a),'[]'),
 'boards',coalesce((SELECT jsonb_agg(data||jsonb_build_object('id',id)) FROM b),'[]'),
 'posts',coalesce((SELECT jsonb_agg(data||jsonb_build_object('id',id)) FROM p),'[]'),
 'comments',coalesce((SELECT jsonb_agg(c.data||jsonb_build_object('id',c.id,'parent',CASE WHEN parent.id IS NULL THEN NULL ELSE jsonb_build_object('id',parent.id,'floor',parent.data->'floor','nickname',CASE WHEN parent.data->>'status'='published' AND u.data->>'status'<>'deleted' THEN u.data->>'nickname' ELSE '\u5DF2\u5220\u9664\u6216\u9690\u85CF' END) END)) FROM c LEFT JOIN electronicclub.forum_comments parent ON parent.id=c.data->>'parentId' LEFT JOIN electronicclub.users u ON u.id=parent.data->>'authorUid'),'[]'),
 'popups',coalesce((SELECT jsonb_agg(data||jsonb_build_object('id',id)) FROM pop),'[]'),
 'resources',coalesce((SELECT jsonb_agg(data||jsonb_build_object('id',id)) FROM electronicclub.club_resources WHERE data->>'status'='published'),'[]'),
 'authors',coalesce((SELECT jsonb_agg(jsonb_build_object('uid',id,'nickname',CASE WHEN data->>'status'='deleted' THEN '\u5DF2\u6CE8\u9500\u6210\u5458' ELSE data->>'nickname' END,'avatar',CASE WHEN data->>'status'='active' THEN data->>'avatar' ELSE '' END)) FROM electronicclub.users WHERE id IN (SELECT data->>'authorUid' FROM p UNION SELECT data->>'authorUid' FROM c)),'[]'),
 'mediaIds',coalesce((SELECT jsonb_agg(id) FROM m),'[]'),
 'forumImageIds',coalesce((SELECT jsonb_agg(v.id) FROM electronicclub.forum_images v JOIN p ON p.id=v.data->>'postId' WHERE p.data->'imageIds' @> jsonb_build_array(v.id)),'[]'),
 'copiedAssets',coalesce((SELECT jsonb_agg(data||jsonb_build_object('id',id)) FROM electronicclub.system WHERE id LIKE 'public-site:asset:%'),'[]'),
 'timedMedia',coalesce((SELECT jsonb_agg(jsonb_build_object('id',m.id,'popupIds',(SELECT jsonb_agg(pop.id) FROM pop WHERE m.data->'bindings' @> jsonb_build_array(jsonb_build_object('kind','popup_announcements','id',pop.id))))) FROM electronicclub.media_images m WHERE m.data->>'status'='ready' AND EXISTS(SELECT 1 FROM pop WHERE m.data->'bindings' @> jsonb_build_array(jsonb_build_object('kind','popup_announcements','id',pop.id)))),'[]')
) AS result`;

// src/database-meter.ts
var lastWindow = -1;
function noteDatabaseUse(operation, now = Date.now()) {
  const window = Math.floor(now / 3e5);
  if (window === lastWindow) return;
  lastWindow = window;
  console.info(JSON.stringify({
    category: "database_window",
    window,
    startsAt: new Date(window * 3e5).toISOString(),
    operation
  }));
}

// src/stage3/roster-query.ts
function validateRosterQuery(filter, options) {
  if (!/^[a-f0-9-]{36}$/i.test(String(filter.eventId ?? "")) || Object.keys(filter).some(
    (k) => ![
      "eventId",
      "search",
      "college",
      "className",
      "status",
      "checkedIn"
    ].includes(k)
  ) || Object.values(filter).some(
    (v) => typeof v !== "string" || v.length > 100
  ) || !["", "pending", "approved", "rejected", "cancelled", "manual"].includes(
    String(filter.status ?? "")
  ) || !["", "yes", "no"].includes(String(filter.checkedIn ?? "")) || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 100)
    throw new Error("INVALID_ROSTER_QUERY");
}
var EVENT_ROSTER_SQL = `WITH filtered AS (SELECT id,data FROM electronicclub.registrations WHERE event_id=$1::jsonb->>'eventId'
AND (coalesce($1::jsonb->>'status','')='' OR data->>'status'=$1::jsonb->>'status')
AND (coalesce($1::jsonb->>'college','')='' OR data#>>'{snapshot,college}'=$1::jsonb->>'college')
AND (coalesce($1::jsonb->>'className','')='' OR data#>>'{snapshot,className}'=$1::jsonb->>'className')
AND (coalesce($1::jsonb->>'checkedIn','')='' OR CASE WHEN $1::jsonb->>'checkedIn'='yes' THEN coalesce(data->>'checkedInAt','')<>'' ELSE coalesce(data->>'checkedInAt','')='' END)
AND strpos(upper(coalesce(data#>>'{snapshot,studentId}','')||' '||coalesce(data#>>'{snapshot,name}','')),upper(coalesce($1::jsonb->>'search','')))>0),
paged AS (SELECT id,data FROM filtered ORDER BY data->>'registeredAt' DESC,id LIMIT $2 OFFSET $3)
SELECT jsonb_build_object('total',(SELECT count(*) FROM filtered),'items',coalesce((SELECT jsonb_agg(data ORDER BY data->>'registeredAt' DESC,id) FROM paged),'[]'::jsonb),
'summary',jsonb_build_object('checkedIn',(SELECT count(*) FROM filtered WHERE coalesce(data->>'checkedInAt','')<>''),'notCheckedIn',(SELECT count(*) FROM filtered WHERE coalesce(data->>'checkedInAt','')=''),'pending',(SELECT count(*) FROM filtered WHERE data->>'status'='pending'))) AS result`;

// src/members/model.ts
var import_zod = require("zod");
var ApiError = class extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
function ensure(value, status, code, message) {
  if (!value) throw new ApiError(status, code, message);
}
var text = import_zod.z.string().trim().max(100);
var studentIdSchema = import_zod.z.string().refine(isValidStudentId, STUDENT_ID_MESSAGE).transform(normalizeStudentId);
var memberSchema = import_zod.z.object({
  studentId: studentIdSchema,
  name: import_zod.z.string().trim().min(1).max(60),
  gender: import_zod.z.enum(["\u7537", "\u5973", "\u5176\u4ED6", "\u672A\u586B\u5199"]).default("\u672A\u586B\u5199"),
  college: text.default(""),
  major: text.default(""),
  className: text.default(""),
  grade: text.default(""),
  nickname: import_zod.z.string().trim().min(1).max(60).optional(),
  phone: import_zod.z.string().regex(/^[\d+ ()-]{0,30}$/).default(""),
  email: import_zod.z.union([import_zod.z.literal(""), import_zod.z.string().email().max(200)]).default(""),
  avatar: import_zod.z.union([
    import_zod.z.literal(""),
    import_zod.z.string().url().max(500).refine((x) => x.startsWith("https://"), "\u5934\u50CF\u4EC5\u652F\u6301HTTPS\u5730\u5740")
  ]).default(""),
  position: text.default("")
}).strict();
var patchFields = import_zod.z.object({
  studentId: studentIdSchema,
  name: import_zod.z.string().trim().min(1).max(60),
  nickname: import_zod.z.string().trim().min(1).max(60),
  gender: import_zod.z.enum(["\u7537", "\u5973", "\u5176\u4ED6", "\u672A\u586B\u5199"]),
  college: text,
  major: text,
  className: text,
  grade: text,
  phone: import_zod.z.string().regex(/^[\d+ ()-]{0,30}$/),
  email: import_zod.z.union([import_zod.z.literal(""), import_zod.z.string().email().max(200)]),
  avatar: import_zod.z.union([
    import_zod.z.literal(""),
    import_zod.z.string().url().max(500).refine((x) => x.startsWith("https://"))
  ]),
  position: text
});
var profileSchema = patchFields.pick({
  nickname: true,
  gender: true,
  phone: true,
  email: true,
  avatar: true
}).partial().strict();
var editSchema = patchFields.partial().strict();
var passwordSchema = import_zod.z.string().min(8).max(128).refine(
  (x) => /[a-zA-Z]/.test(x) && /\d/.test(x),
  "\u5BC6\u7801\u81F3\u5C118\u4F4D\u4E14\u5305\u542B\u5B57\u6BCD\u548C\u6570\u5B57"
);
var permissionDefinitions = [
  ["members.read", "\u6210\u5458\u67E5\u8BE2", "\u6210\u5458"],
  ["members.create", "\u6210\u5458\u521B\u5EFA", "\u6210\u5458"],
  ["members.edit", "\u8EAB\u4EFD\u8D44\u6599\u7F16\u8F91", "\u6210\u5458"],
  ["members.import", "Excel\u5BFC\u5165", "\u6210\u5458"],
  ["members.export", "\u6210\u5458\u5BFC\u51FA", "\u6210\u5458"],
  ["members.delete", "\u8F6F\u5220\u9664\u4E0E\u6062\u590D", "\u6210\u5458"],
  ["members.purge", "\u5F7B\u5E95\u5220\u9664\u6210\u5458\uFF08\u4E0D\u53EF\u6062\u590D\uFF09", "\u6210\u5458"],
  ["members.password", "\u5BC6\u7801\u91CD\u7F6E", "\u6210\u5458"],
  ["members.status", "\u7981\u7528\u4E0E\u6062\u590D\u8D26\u53F7", "\u6210\u5458"],
  ["roles.read", "\u89D2\u8272\u4E0E\u6743\u9650\u67E5\u8BE2", "\u6743\u9650"],
  ["roles.assign", "\u5206\u914D\u6210\u5458\u89D2\u8272", "\u6743\u9650"],
  ["roles.manage", "\u521B\u5EFA\u53CA\u7BA1\u7406\u89D2\u8272", "\u6743\u9650"],
  ["security.logins.read", "\u767B\u5F55\u8BB0\u5F55\u67E5\u8BE2", "\u8D26\u53F7\u4E0E\u5B89\u5168"],
  ["resources.manage", "\u8D44\u6599\u4E0A\u4F20\u4E0E\u7BA1\u7406", "\u793E\u56E2\u8D44\u6599"],
  ["audit.read", "\u5BA1\u8BA1\u65E5\u5FD7\u67E5\u8BE2", "\u7CFB\u7EDF"],
  ["events.create", "\u521B\u5EFA\u6D3B\u52A8", "\u6D3B\u52A8"],
  ["events.edit", "\u7F16\u8F91\u5168\u90E8\u6D3B\u52A8/\u5206\u914D\u8D1F\u8D23\u4EBA", "\u6D3B\u52A8"],
  ["events.delete", "\u5220\u9664\u6D3B\u52A8", "\u6D3B\u52A8"],
  ["events.registrations.read", "\u67E5\u8BE2\u62A5\u540D\u540D\u5355", "\u6D3B\u52A8"],
  ["events.registrations.review", "\u5BA1\u6838\u62A5\u540D", "\u6D3B\u52A8"],
  ["events.registrations.export", "\u5BFC\u51FA\u62A5\u540D\u540D\u5355", "\u6D3B\u52A8"],
  ["events.checkin.manage", "\u7BA1\u7406\u7B7E\u5230", "\u6D3B\u52A8"],
  ["articles.create", "\u521B\u5EFA\u6587\u7AE0", "\u5185\u5BB9"],
  ["articles.edit", "\u7F16\u8F91\u6587\u7AE0", "\u5185\u5BB9"],
  ["articles.publish", "\u53D1\u5E03/\u64A4\u56DE\u6587\u7AE0", "\u5185\u5BB9"],
  ["articles.delete", "\u5220\u9664\u6587\u7AE0", "\u5185\u5BB9"],
  ["announcements.popup.manage", "\u5168\u7AD9\u5F39\u7A97\u7BA1\u7406", "\u5185\u5BB9"],
  ["forum.boards.manage", "\u7248\u5757\u7BA1\u7406", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.review", "\u5BA1\u6838\u5E16\u5B50", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.pin", "\u5E16\u5B50\u7F6E\u9876", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.feature", "\u5E16\u5B50\u52A0\u7CBE", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.lock", "\u9501\u5E16\u4E0E\u5173\u95ED\u8BC4\u8BBA", "\u7535\u5B50\u793E\u533A"],
  ["forum.posts.delete", "\u5220\u9664\u8FDD\u89C4\u5E16\u5B50", "\u7535\u5B50\u793E\u533A"],
  ["forum.comments.moderate", "\u8BC4\u8BBA\u5BA1\u6838", "\u7535\u5B50\u793E\u533A"],
  ["forum.reports.manage", "\u4E3E\u62A5\u5904\u7406", "\u7535\u5B50\u793E\u533A"],
  ["forum.users.restrict", "\u9650\u5236\u793E\u533A\u53D1\u8A00", "\u7535\u5B50\u793E\u533A"],
  ["activities.create", "\u521B\u5EFA\u6D3B\u52A8", "\u540E\u7EED\u4E1A\u52A1"],
  ["activities.manage", "\u7BA1\u7406\u6D3B\u52A8", "\u540E\u7EED\u4E1A\u52A1"],
  ["activities.roster.read", "\u67E5\u770B\u62A5\u540D\u540D\u5355", "\u540E\u7EED\u4E1A\u52A1"],
  ["activities.roster.export", "\u5BFC\u51FA\u62A5\u540D\u540D\u5355", "\u540E\u7EED\u4E1A\u52A1"],
  ["articles.manage", "\u6587\u7AE0\u516C\u544A\u7BA1\u7406", "\u540E\u7EED\u4E1A\u52A1"],
  ["community.moderate", "\u5E16\u5B50\u8BC4\u8BBA\u5BA1\u6838", "\u540E\u7EED\u4E1A\u52A1"],
  ["settings.manage", "\u7CFB\u7EDF\u8BBE\u7F6E", "\u540E\u7EED\u4E1A\u52A1"],
  ["popups.manage", "\u5168\u7AD9\u5F39\u7A97", "\u540E\u7EED\u4E1A\u52A1"]
].map(([id, name, group]) => ({
  id,
  name,
  group: permissionGroup(id),
  implemented: group !== "\u540E\u7EED\u4E1A\u52A1"
}));
var roleSchema = import_zod.z.object({
  name: import_zod.z.string().trim().min(1).max(60),
  description: import_zod.z.string().trim().max(300),
  permissionIds: import_zod.z.array(import_zod.z.string()).max(64).transform((x) => [...new Set(x)])
}).strict();
var listSchema = import_zod.z.object({
  page: import_zod.z.coerce.number().int().min(1).max(1e4).default(1),
  pageSize: import_zod.z.coerce.number().int().min(1).max(100).default(20),
  search: import_zod.z.string().max(100).default(""),
  college: text.default(""),
  className: text.default(""),
  roleId: import_zod.z.string().max(64).default(""),
  status: import_zod.z.enum(["active", "disabled", "deleted", "all"]).default("active")
}).strict();

// src/members/purge.ts
function purgeDatabaseError(code) {
  if (code === "P1401")
    return new ApiError(
      409,
      "MEMBER_HAS_HISTORY",
      "\u6210\u5458\u5B58\u5728\u5E16\u5B50\u3001\u6D3B\u52A8\u3001\u8D44\u6599\u6216\u5176\u4ED6\u4E1A\u52A1\u5173\u8054\uFF0C\u4E0D\u80FD\u5F7B\u5E95\u5220\u9664\uFF0C\u8BF7\u4F7F\u7528\u533F\u540D\u5316"
    );
  if (code === "P1402")
    return new ApiError(
      409,
      "PURGE_NOT_ALLOWED",
      "\u4EC5\u53EF\u5F7B\u5E95\u5220\u9664\u5DF2\u8F6F\u5220\u9664\u7684\u975E\u8D85\u7EA7\u7BA1\u7406\u5458\u8D26\u53F7"
    );
  if (code === "P1403")
    return new ApiError(
      409,
      "PRIVACY_CLEANUP_PENDING",
      "\u8BE5\u6210\u5458\u7684\u9690\u79C1\u6E05\u7406\u5C1A\u672A\u5B8C\u6210\uFF0C\u8BF7\u5148\u5B8C\u6210\u6E05\u7406\u4EFB\u52A1"
    );
}

// src/resources/query.ts
function validateResourceQuery(filter, options) {
  if (Object.keys(filter).some(
    (k) => ![
      "public",
      "status",
      "search",
      "category",
      "cleanupBefore",
      "uploadBefore"
    ].includes(k)
  ) || Object.values(filter).some(
    (v) => typeof v !== "string" && typeof v !== "boolean"
  ) || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50 || String(filter.search ?? "").length > 80 || String(filter.category ?? "").length > 40 || filter.status && ![
    "uploading",
    "draft",
    "published",
    "deleting",
    "deleted",
    "all"
  ].includes(String(filter.status)))
    throw new Error("INVALID_RESOURCE_QUERY");
}
var RESOURCE_SQL = `WITH filtered AS (SELECT id,data FROM electronicclub.club_resources WHERE (NOT coalesce(($1::jsonb->>'public')::boolean,false) OR data->>'status'='published') AND (NOT $1::jsonb ? 'status' OR $1::jsonb->>'status'='all' OR data->>'status'=$1::jsonb->>'status') AND ($1::jsonb ? 'status' OR data->>'status'<>'deleted') AND (coalesce($1::jsonb->>'category','')='' OR data->>'category'=$1::jsonb->>'category') AND strpos(lower(coalesce(data->>'title','')||' '||coalesce(data->>'description','')||' '||coalesce(data->>'originalName','')),lower(coalesce($1::jsonb->>'search','')))>0 AND (NOT $1::jsonb ? 'cleanupBefore' OR ((data->>'status'='deleting' AND data->>'expiresAt'<$1::jsonb->>'cleanupBefore') OR (data->>'status'='uploading' AND data->>'createdAt'<coalesce($1::jsonb->>'uploadBefore',$1::jsonb->>'cleanupBefore'))))),paged AS (SELECT id,data FROM filtered ORDER BY data->>'createdAt' DESC,id LIMIT $2 OFFSET $3) SELECT jsonb_build_object('total',(SELECT count(*) FROM filtered),'items',coalesce((SELECT jsonb_agg(data ORDER BY data->>'createdAt' DESC,id) FROM paged),'[]'::jsonb)) AS result`;

// src/members/login-query.ts
function validateLoginQuery(filter, options) {
  if (Object.keys(filter).some(
    (k) => !["search", "outcome", "from", "to"].includes(k)
  ) || Object.values(filter).some((v) => typeof v !== "string") || String(filter.search ?? "").length > 80 || !["all", "success", "failure", "blocked"].includes(
    String(filter.outcome ?? "all")
  ) || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50)
    throw new Error("INVALID_LOGIN_QUERY");
  for (const key2 of ["from", "to"])
    if (filter[key2] && !Number.isFinite(Date.parse(String(filter[key2]))))
      throw new Error("INVALID_LOGIN_DATE");
}
var actor = `coalesce(nullif(a.data#>>'{login,memberUid}',''),CASE WHEN a.data->>'action'='auth.login' THEN a.data->>'actor' END)`;
var concealed = `(u.data->>'anonymizedAt' IS NOT NULL)`;
var LOGIN_HISTORY_SQL = `WITH records AS (SELECT a.id,a.data->>'createdAt' AS at,
 jsonb_build_object('id',a.id,'createdAt',a.data->>'createdAt','memberUid',${actor},'name',coalesce(u.data->>'name',''),'studentId',coalesce(u.data->>'studentId',''),
 'outcome',CASE a.data->>'action' WHEN 'auth.login' THEN 'success' WHEN 'auth.login_blocked' THEN 'blocked' ELSE 'failure' END,
 'reason',coalesce(a.data#>>'{login,reason}',''),'ip',CASE WHEN ${concealed} THEN NULL ELSE a.data#>>'{login,ip}' END,
 'ipSource',CASE WHEN ${concealed} THEN 'unavailable' ELSE coalesce(a.data#>>'{login,ipSource}','legacy') END,
 'device',CASE WHEN ${concealed} THEN '' ELSE coalesce(a.data#>>'{login,device}','') END,'os',CASE WHEN ${concealed} THEN '' ELSE coalesce(a.data#>>'{login,os}','') END,
 'browser',CASE WHEN ${concealed} THEN '' ELSE coalesce(a.data#>>'{login,browser}','') END,'userAgent',CASE WHEN ${concealed} THEN '' ELSE coalesce(a.data#>>'{login,userAgent}','') END,
 'legacy',NOT(a.data ? 'login'),'anonymized',coalesce(${concealed},false)) AS record
 FROM electronicclub.audit_logs a LEFT JOIN electronicclub.users u ON u.id=${actor}
 WHERE a.data->>'action' IN ('auth.login','auth.login_failed','auth.login_blocked')
 AND (NOT $1::jsonb ? 'from' OR a.data->>'createdAt'>=$1::jsonb->>'from') AND (NOT $1::jsonb ? 'to' OR a.data->>'createdAt'<$1::jsonb->>'to')),
 filtered AS (SELECT * FROM records WHERE (coalesce($1::jsonb->>'outcome','all')='all' OR record->>'outcome'=$1::jsonb->>'outcome') AND strpos(lower(coalesce(record->>'name','')||' '||coalesce(record->>'studentId','')||' '||coalesce(record->>'ip','')),lower(coalesce($1::jsonb->>'search','')))>0),
 paged AS (SELECT * FROM filtered ORDER BY at DESC,id LIMIT $2 OFFSET $3)
 SELECT jsonb_build_object('total',(SELECT count(*) FROM filtered),'items',coalesce((SELECT jsonb_agg(record ORDER BY at DESC,id) FROM paged),'[]'::jsonb)) AS result`;

// src/media/query.ts
function validateExpired(filter, options) {
  if (Object.keys(filter).length !== 1 || typeof filter.before !== "string" || !Number.isFinite(Date.parse(filter.before)) || options.offset !== 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50)
    throw new Error("INVALID_MEDIA_CLEANUP_QUERY");
}
var EXPIRED_MEDIA_SQL = `WITH selected AS (SELECT id,data FROM electronicclub.media_images WHERE data->'bindings'='[]'::jsonb AND data->>'createdAt'<$1 ORDER BY data->>'createdAt',id LIMIT $2) SELECT jsonb_build_object('total',(SELECT count(*) FROM selected),'items',coalesce((SELECT jsonb_agg(data ORDER BY data->>'createdAt',id) FROM selected),'[]'::jsonb)) AS result`;

// src/members/access-query.ts
function validateAccessQuery(filter, options) {
  const keys2 = ["roleId", "permissionId", "search", "status"];
  if (Object.keys(filter).some((k) => !keys2.includes(k)) || Object.values(filter).some((v) => typeof v !== "string") || Number(!!filter.roleId) + Number(!!filter.permissionId) !== 1 || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50 || !["active", "disabled", "deleted", "all"].includes(
    String(filter.status ?? "active")
  ) || String(filter.search ?? "").length > 80)
    throw new Error("INVALID_ACCESS_QUERY");
}
var matches = `(($1::jsonb ? 'roleId' AND r.id=$1::jsonb->>'roleId') OR ($1::jsonb ? 'permissionId' AND (r.data->>'super'='true' OR r.data->'permissionIds' @> jsonb_build_array($1::jsonb->>'permissionId'))))`;
var roleSummary = `jsonb_build_object('id',r.id,'name',r.data->>'name','super',coalesce((r.data->>'super')::boolean,false))`;
var ACCESS_SQL = `WITH filtered AS (SELECT u.id,u.data FROM electronicclub.users u WHERE u.data->>'status' IN ('active','disabled','deleted') AND (coalesce($1::jsonb->>'status','active')='all' OR u.data->>'status'=coalesce($1::jsonb->>'status','active')) AND (NOT $1::jsonb ? 'search' OR strpos(upper(coalesce(u.data->>'studentId','')||' '||coalesce(u.data->>'name','')||' '||coalesce(u.data->>'nickname','')),upper($1::jsonb->>'search'))>0) AND EXISTS(SELECT 1 FROM electronicclub.user_roles ur JOIN electronicclub.roles r ON r.id=ur.role_id WHERE ur.user_id=u.id AND ${matches})),paged AS (SELECT id,data FROM filtered ORDER BY data->>'studentId',id LIMIT $2 OFFSET $3) SELECT jsonb_build_object('total',(SELECT count(*) FROM filtered),'items',coalesce((SELECT jsonb_agg(jsonb_build_object('uid',p.id,'studentId',p.data->>'studentId','name',p.data->>'name','nickname',p.data->>'nickname','status',p.data->>'status','roleIds',p.data->'roleIds','roles',coalesce((SELECT jsonb_agg(${roleSummary} ORDER BY r.data->>'name',r.id) FROM electronicclub.user_roles ur JOIN electronicclub.roles r ON r.id=ur.role_id WHERE ur.user_id=p.id),'[]'::jsonb),'sources',coalesce((SELECT jsonb_agg(${roleSummary} ORDER BY r.data->>'name',r.id) FROM electronicclub.user_roles ur JOIN electronicclub.roles r ON r.id=ur.role_id WHERE ur.user_id=p.id AND ${matches}),'[]'::jsonb)) ORDER BY p.data->>'studentId',p.id) FROM paged p),'[]'::jsonb)) AS result`;

// src/forum/query.ts
var FORUM_TABLES = [
  "forum_boards",
  "forum_posts",
  "forum_comments",
  "forum_likes",
  "forum_favorites",
  "forum_reports",
  "forum_user_restrictions",
  "forum_notifications",
  "forum_images"
];
var queryTables = [...FORUM_TABLES, "audit_logs"];
var keys = [
  "_createdBefore",
  "_beforeFloor",
  "_forumAudit",
  "status",
  "boardId",
  "postId",
  "authorUid",
  "recipientUid",
  "reporterUid",
  "ownerUid",
  "uid",
  "read",
  "_search",
  "_sort",
  "_public",
  "_favoriteUid",
  "_featured",
  "_notDeleted"
];
function validateForumQuery(collection, filter, options) {
  if (!queryTables.includes(collection) || Object.keys(filter).some((k) => !keys.includes(k)) || Object.values(filter).some(
    (v) => !["string", "boolean"].includes(typeof v)
  ) || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50)
    throw new Error("INVALID_FORUM_QUERY");
  if (collection === "audit_logs" && filter._forumAudit !== true)
    throw new Error("INVALID_FORUM_AUDIT");
  if (filter._beforeFloor && !/^\d{1,9}$/.test(String(filter._beforeFloor)))
    throw new Error("INVALID_FLOOR");
  if (filter._sort && !["latest", "reply", "hot", "oldest", "featured"].includes(
    String(filter._sort)
  ))
    throw new Error("INVALID_FORUM_SORT");
}
function forumSelect(collection) {
  if (!queryTables.includes(collection)) throw new Error("INVALID_FORUM_TABLE");
  const publicCheck = collection === "forum_boards" ? `r.data->>'status' IN ('active','disabled')` : collection === "forum_posts" ? `r.data->>'status'='published' AND EXISTS(SELECT 1 FROM electronicclub.forum_boards b WHERE b.id=r.data->>'boardId' AND b.data->>'status' IN ('active','disabled'))` : collection === "forum_comments" ? `r.data->>'status' IN ('published','deleted') AND EXISTS(SELECT 1 FROM electronicclub.forum_posts p JOIN electronicclub.forum_boards b ON b.id=p.data->>'boardId' WHERE p.id=r.data->>'postId' AND p.data->>'status'='published' AND b.data->>'status' IN ('active','disabled'))` : "false";
  const filters = [
    "status",
    "boardId",
    "postId",
    "authorUid",
    "recipientUid",
    "reporterUid",
    "ownerUid",
    "uid",
    "read"
  ].map(
    (k) => `(NOT $1::jsonb ? '${k}' OR r.data->>'${k}'=$1::jsonb->>'${k}')`
  ).join(" AND ");
  const favorites = collection === "forum_posts" ? `EXISTS(SELECT 1 FROM electronicclub.forum_favorites f WHERE f.data->>'postId'=r.id AND f.data->>'uid'=$1::jsonb->>'_favoriteUid')` : "false";
  const order = collection === "forum_boards" ? `(data->>'position')::integer,id` : collection === "forum_comments" ? `(data->>'floor')::integer,id` : collection === "forum_posts" ? `coalesce((data->>'pinned')::boolean,false) DESC,CASE WHEN $1::jsonb->>'_sort'='hot' THEN coalesce((data->>'likeCount')::integer,0)*3+coalesce((data->>'commentCount')::integer,0)*2 END DESC NULLS LAST,CASE WHEN $1::jsonb->>'_sort'='reply' THEN data->>'lastReplyAt' ELSE data->>'createdAt' END DESC,id` : `data->>'createdAt' DESC,id`;
  const projection = collection === "forum_images" ? "r.data - 'dataUrl' AS data" : "r.data";
  return `WITH filtered AS (SELECT r.id,${projection} FROM electronicclub.${collection} r WHERE ${collection === "audit_logs" ? "r.data->>'action' LIKE 'forum.%' AND" : ""} ${filters} AND (NOT $1::jsonb ? '_notDeleted' OR r.data->>'status'<>'deleted') AND (NOT $1::jsonb ? '_public' OR (${publicCheck})) AND (NOT $1::jsonb ? '_favoriteUid' OR (${favorites})) AND (NOT $1::jsonb ? '_featured' OR r.data->>'featured'='true') AND (NOT $1::jsonb ? '_createdBefore' OR (r.data->>'createdAt')::timestamptz<($1::jsonb->>'_createdBefore')::timestamptz) AND (NOT $1::jsonb ? '_beforeFloor' OR (r.data->>'floor')::integer<($1::jsonb->>'_beforeFloor')::integer) AND (NOT $1::jsonb ? '_search' OR strpos(lower(coalesce(r.data->>'title','')||' '||coalesce(r.data->>'body','')||' '||coalesce(r.data->>'name','')),lower($1::jsonb->>'_search'))>0)),paged AS (SELECT id,data,row_number() OVER(ORDER BY ${order}) AS n FROM filtered ORDER BY ${order} LIMIT $2 OFFSET $3) SELECT jsonb_build_object('total',(SELECT count(*) FROM filtered),'items',coalesce((SELECT jsonb_agg(data||jsonb_build_object('id',id) ORDER BY n) FROM paged),'[]'::jsonb)) AS result`;
}

// src/members/pg-store.ts
var import_pg = require("pg");
var tables = /* @__PURE__ */ new Set([
  ...FORUM_TABLES,
  "club_resources",
  "media_images",
  "media_chunks",
  "events",
  "event_managers",
  "registrations",
  "checkins",
  "articles",
  "popup_announcements",
  "popup_state",
  "users",
  "roles",
  "permissions",
  "credentials",
  "sessions",
  "student_ids",
  "audit_logs",
  "import_jobs",
  "login_limits",
  "system",
  "privacy_jobs"
]);
function table(name) {
  if (!tables.has(name)) throw new Error("INVALID_TABLE");
  return `electronicclub.${name}`;
}
var DatabaseFailure = class extends Error {
  constructor(stage, safeCode2, diagnostic) {
    super("Database unavailable");
    this.stage = stage;
    this.safeCode = safeCode2;
    this.diagnostic = diagnostic;
  }
};
function createPool() {
  if (!process.env.DATABASE_URL)
    throw new DatabaseFailure("configuration", "DATABASE_NOT_CONFIGURED");
  if (process.env.PG_TLS !== "disable" && !process.env.PG_CA_CERT)
    throw new DatabaseFailure("configuration", "TLS_CA_REQUIRED");
  let endpoint;
  try {
    endpoint = new URL(process.env.DATABASE_URL);
  } catch {
    throw new DatabaseFailure("configuration", "INVALID_DATABASE_URL");
  }
  if (!["postgres:", "postgresql:"].includes(endpoint.protocol) || [...endpoint.searchParams.keys()].some(
    (key2) => key2.toLowerCase().startsWith("ssl")
  ))
    throw new DatabaseFailure("configuration", "UNSAFE_DATABASE_URL");
  if (process.env.PG_TLS === "disable" && !["127.0.0.1", "localhost", "[::1]"].includes(endpoint.hostname))
    throw new DatabaseFailure("configuration", "REMOTE_TLS_REQUIRED");
  return new import_pg.Pool({
    connectionString: process.env.DATABASE_URL,
    max: 4,
    connectionTimeoutMillis: 5e3,
    idleTimeoutMillis: 3e4,
    statement_timeout: 15e3,
    ssl: process.env.PG_TLS === "disable" ? false : { rejectUnauthorized: true, ca: process.env.PG_CA_CERT }
  });
}
var PgStore = class {
  constructor(pool = createPool()) {
    this.pool = pool;
    pool.on(
      "error",
      () => console.error(
        JSON.stringify({
          category: "database",
          stage: "idle_connection",
          code: "DB_CONNECTION_FAILED"
        })
      )
    );
  }
  roleVerified = false;
  async verifyRole() {
    noteDatabaseUse("postgres-tcp");
    if (this.roleVerified) return;
    const result = await this.pool.query(
      "SELECT rolsuper,rolcreatedb,rolcreaterole,rolreplication FROM pg_roles WHERE rolname=current_user"
    ).catch(() => {
      throw new DatabaseFailure("authorization", "DB_ROLE_CHECK_FAILED");
    });
    if (!result.rows[0] || Object.values(result.rows[0]).some(Boolean))
      throw new DatabaseFailure("authorization", "PRIVILEGED_DB_ROLE");
    this.roleVerified = true;
  }
  async run(fn) {
    await this.verifyRole();
    const client = await this.pool.connect().catch(() => {
      throw new DatabaseFailure("connect", "DB_CONNECT_FAILED");
    });
    let stage = "begin";
    try {
      await client.query("BEGIN");
      await client.query("SET LOCAL idle_in_transaction_session_timeout='30s'");
      await client.query("SELECT pg_advisory_xact_lock(1991,1)");
      stage = "transaction";
      const snapshots = /* @__PURE__ */ new Map();
      const tx = {
        get: async (c, id) => {
          const name = table(c);
          const key2 = c + "/" + id;
          if (!snapshots.has(key2))
            snapshots.set(
              key2,
              client.query(`SELECT data FROM ${name} WHERE id=$1`, [id]).then((result2) => result2.rows[0]?.data ?? null)
            );
          return structuredClone(await snapshots.get(key2));
        },
        set: async (c, id, value) => {
          await client.query(
            `INSERT INTO ${table(c)}(id,data) VALUES($1,$2) ON CONFLICT(id) DO UPDATE SET data=excluded.data`,
            [id, JSON.stringify(value)]
          );
          if (c === "users") {
            await client.query(
              "DELETE FROM electronicclub.user_roles WHERE user_id=$1",
              [id]
            );
            for (const role of value.roleIds ?? [])
              await client.query(
                "INSERT INTO electronicclub.user_roles VALUES($1,$2)",
                [id, role]
              );
          }
          snapshots.clear();
          snapshots.set(c + "/" + id, Promise.resolve(structuredClone(value)));
        },
        remove: async (c, id) => {
          await client.query(`DELETE FROM ${table(c)} WHERE id=$1`, [id]);
          snapshots.clear();
        }
      };
      const result = await fn(tx);
      stage = "commit";
      await client.query("COMMIT");
      return result;
    } catch (error) {
      try {
        await client.query("ROLLBACK");
      } catch {
      }
      const code = String(error.code ?? "");
      const purgeError = purgeDatabaseError(code);
      if (purgeError) throw purgeError;
      if (/^[0-9A-Z]{5}$/.test(code)) throw new DatabaseFailure(stage, code);
      throw error;
    } finally {
      client.release();
    }
  }
  async read(c, id) {
    try {
      await this.verifyRole();
      return (await this.pool.query(`SELECT data FROM ${table(c)} WHERE id=$1`, [
        id
      ])).rows[0]?.data ?? null;
    } catch {
      throw new DatabaseFailure("read", "DB_READ_FAILED");
    }
  }
  async list(c, filter, options) {
    await this.verifyRole();
    if (c === "public_site_export") {
      if (Object.keys(filter).length || options.offset !== 0 || options.limit !== 1) throw Error("INVALID_PUBLIC_EXPORT_QUERY");
      return { items: [(await this.pool.query(PUBLIC_EXPORT_SQL)).rows[0].result], total: 1 };
    }
    if (c === "event_roster") {
      validateRosterQuery(filter, options);
      return (await this.pool.query(EVENT_ROSTER_SQL, [filter, options.limit, options.offset])).rows[0].result;
    }
    if (c === "member_stats") {
      if (Object.keys(filter).length || options.offset !== 0 || options.limit !== 1) throw new Error("INVALID_STATS_QUERY");
      return { items: [(await this.pool.query(MEMBER_STATS_SQL)).rows[0].result], total: 1 };
    }
    if (c === "club_resources") {
      validateResourceQuery(filter, options);
      return (await this.pool.query(RESOURCE_SQL, [filter, options.limit, options.offset])).rows[0].result;
    }
    if (c === "login_history") {
      validateLoginQuery(filter, options);
      return (await this.pool.query(LOGIN_HISTORY_SQL, [filter, options.limit, options.offset])).rows[0].result;
    }
    if (c === "media_expired") {
      validateExpired(filter, options);
      return (await this.pool.query(EXPIRED_MEDIA_SQL, [filter.before, options.limit])).rows[0].result;
    }
    if (c === "access_members") {
      validateAccessQuery(filter, options);
      return (await this.pool.query(ACCESS_SQL, [filter, options.limit, options.offset])).rows[0].result;
    }
    if (c.startsWith("forum_") || filter._forumAudit === true) {
      validateForumQuery(c, filter, options);
      const result = await this.pool.query(forumSelect(c), [filter, options.limit, options.offset]);
      return result.rows[0].result;
    }
    const args = [], clauses = [];
    const param = (value) => {
      args.push(value);
      return `$${args.length}`;
    };
    for (const [key2, value] of Object.entries(filter)) {
      if (key2 === "_search")
        clauses.push(
          `(strpos(upper(data->>'studentId'),upper(${param(value)}))>0 OR strpos(upper(data->>'name'),upper($${args.length}))>0 OR strpos(upper(data->>'nickname'),upper($${args.length}))>0)`
        );
      else if (key2 === "_notDeleted") clauses.push("data->>'status'<>'deleted'");
      else if (key2 === "roleIds")
        clauses.push(
          `data->'roleIds' @> ${param(JSON.stringify([value]))}::jsonb`
        );
      else {
        if (!["status", "college", "className", "owner", "uid"].includes(key2))
          throw new Error("INVALID_FILTER");
        clauses.push(`data->>'${key2}'=${param(value)}`);
      }
    }
    const where = clauses.length ? " WHERE " + clauses.join(" AND ") : "";
    try {
      const count = await this.pool.query(
        `SELECT count(*) AS total FROM ${table(c)}${where}`,
        args
      );
      const rows = await this.pool.query(
        `SELECT data FROM ${table(c)}${where} ORDER BY data->>'createdAt' DESC,id ASC LIMIT $${args.length + 1} OFFSET $${args.length + 2}`,
        [...args, options.limit, options.offset]
      );
      return {
        items: rows.rows.map((row) => row.data),
        total: Number(count.rows[0].total)
      };
    } catch {
      throw new DatabaseFailure("query", "DB_QUERY_FAILED");
    }
  }
};

// src/members/cookie.ts
function sessionCookieConfig() {
  const secure = process.env.COOKIE_SECURE !== "false";
  const value = (process.env.COOKIE_SAMESITE ?? "lax").toLowerCase();
  if (!["lax", "strict", "none"].includes(value))
    throw new DatabaseFailure("configuration", "INVALID_COOKIE_SAMESITE");
  if (value === "none") {
    const origin = process.env.ALLOWED_ORIGIN;
    let valid = false;
    try {
      const url = new URL(origin);
      valid = url.protocol === "https:" && url.origin === origin;
    } catch {
    }
    if (!secure || !valid)
      throw new DatabaseFailure(
        "configuration",
        "CROSS_SITE_COOKIE_REQUIRES_HTTPS"
      );
  }
  return {
    name: secure ? "__Host-ec-session" : "ec-session",
    secure,
    sameSite: value === "none" ? "None" : value === "strict" ? "Strict" : "Lax"
  };
}
function sessionCookie(token, clear = false) {
  const config = sessionCookieConfig();
  return `${config.name}=${token}; Path=/; HttpOnly; SameSite=${config.sameSite}; Max-Age=${clear ? 0 : 28800}${config.secure ? "; Secure" : ""}`;
}

// src/index.ts
var import_node_crypto13 = require("node:crypto");

// src/http-body.ts
var BACKEND_BODY_REVISION = "gateway-body-v5";
var HttpBodyError = class extends ApiError {
  constructor(status, code, message, diagnostic) {
    super(status, code, message);
    this.diagnostic = diagnostic;
  }
};
function shape(bytes) {
  if (!bytes.length) return "empty";
  const prefix = bytes.subarray(0, 128).toString("utf8").trimStart();
  if (prefix.includes("\0")) return "nul-bytes";
  if (prefix.startsWith("{") || prefix.startsWith("[")) return "json-container";
  if (/^"/.test(prefix)) return "json-string";
  if (/^\d{1,3}(?:,\d{1,3}){3}/.test(prefix)) return "comma-bytes";
  if (/^%(?:7b|5b)/i.test(prefix)) return "percent-encoded";
  if (/^[A-Za-z0-9+/_-]+={0,2}$/.test(prefix)) return "base64-like";
  return "other";
}
function parseHttpBody(event, maxBytes = 31e5) {
  const body = event.body, flag = event.isBase64Encoded;
  const diagnostic = {
    stage: "flag",
    bodyType: body == null ? "missing" : typeof body,
    flagType: flag == null ? "missing" : typeof flag,
    flagValue: "invalid",
    wireBytes: null,
    decodedBytes: null,
    wireShape: "unread",
    decodedShape: "unread"
  };
  function fail2(stage, status, code, message) {
    throw new HttpBodyError(status, code, message, { ...diagnostic, stage });
  }
  let encoded = false;
  if (flag == null || flag === "") diagnostic.flagValue = "missing";
  else if (typeof flag === "boolean") {
    encoded = flag;
    diagnostic.flagValue = flag ? "true" : "false";
  } else if (typeof flag === "string" && /^(true|false)$/i.test(flag.trim())) {
    encoded = flag.trim().toLowerCase() === "true";
    diagnostic.flagValue = encoded ? "true" : "false";
  } else fail2("flag", 400, "INVALID_BODY_ENCODING", "\u7F51\u5173\u6B63\u6587\u7F16\u7801\u6807\u8BB0\u683C\u5F0F\u9519\u8BEF");
  let wire;
  const wireLimit = encoded ? Math.ceil(maxBytes / 3) * 4 + 16 : maxBytes;
  const tooLarge = () => fail2(
    "limit",
    413,
    "BODY_TOO_LARGE",
    maxBytes === 65536 ? "\u5185\u5BB9\u8BF7\u6C42\u8D85\u8FC764KB\uFF0C\u8BF7\u5206\u7247\u4E0A\u4F20\u56FE\u7247\u6216\u7F29\u77ED\u6B63\u6587" : "\u8BF7\u6C42\u4F53\u8FC7\u5927"
  );
  const fromText = (text5) => {
    diagnostic.wireBytes = Buffer.byteLength(text5);
    diagnostic.wireShape = shape(Buffer.from(text5.slice(0, 128)));
    if (diagnostic.wireBytes > wireLimit) tooLarge();
    return Buffer.from(text5, "utf8");
  };
  if (body == null) wire = Buffer.alloc(0);
  else if (typeof body === "string") wire = fromText(body);
  else if (Buffer.isBuffer(body)) {
    diagnostic.bodyType = "buffer";
    wire = body;
  } else if (body instanceof ArrayBuffer) {
    diagnostic.bodyType = "array-buffer";
    wire = Buffer.from(body);
  } else if (ArrayBuffer.isView(body)) {
    diagnostic.bodyType = "array-buffer-view";
    wire = Buffer.from(body.buffer, body.byteOffset, body.byteLength);
  } else if (!encoded && typeof body === "object" && (Array.isArray(body) || Object.getPrototypeOf(body) === Object.prototype || Object.getPrototypeOf(body) === null)) {
    diagnostic.bodyType = "json-object";
    let text5;
    try {
      text5 = JSON.stringify(body);
    } catch {
      return fail2("type", 400, "INVALID_BODY_TYPE", "\u7F51\u5173\u6B63\u6587\u7C7B\u578B\u4E0D\u53D7\u652F\u6301");
    }
    wire = fromText(text5);
  } else return fail2("type", 400, "INVALID_BODY_TYPE", "\u7F51\u5173\u6B63\u6587\u7C7B\u578B\u4E0D\u53D7\u652F\u6301");
  diagnostic.wireBytes = wire.length;
  diagnostic.wireShape = shape(wire);
  if (wire.length > wireLimit) tooLarge();
  let decoded = wire;
  if (encoded) {
    const compact = wire.toString("utf8").replace(/\s/g, "");
    if (!/^[A-Za-z0-9+/_-]*={0,2}$/.test(compact) || compact.length % 4 === 1)
      return fail2(
        "base64",
        400,
        "INVALID_BODY_ENCODING",
        "\u7F51\u5173Base64\u6B63\u6587\u683C\u5F0F\u9519\u8BEF"
      );
    decoded = Buffer.from(compact, "base64");
    const canonical = decoded.toString("base64").replace(/=+$/, "");
    if (canonical !== compact.replace(/=+$/, "").replace(/-/g, "+").replace(/_/g, "/"))
      return fail2(
        "base64",
        400,
        "INVALID_BODY_ENCODING",
        "\u7F51\u5173Base64\u6B63\u6587\u683C\u5F0F\u9519\u8BEF"
      );
  }
  diagnostic.decodedBytes = decoded.length;
  diagnostic.decodedShape = shape(decoded);
  if (decoded.length > maxBytes) tooLarge();
  if (!decoded.length) return {};
  let text4;
  try {
    text4 = new TextDecoder("utf-8", { fatal: true }).decode(
      new Uint8Array(decoded)
    );
  } catch {
    return fail2("utf8", 400, "INVALID_JSON", "JSON\u6B63\u6587\u4E0D\u662F\u6709\u6548\u7684UTF-8\u6587\u672C");
  }
  try {
    return JSON.parse(text4);
  } catch {
    return fail2("json", 400, "INVALID_JSON", "JSON\u683C\u5F0F\u9519\u8BEF");
  }
}

// src/index.ts
var import_zod11 = require("zod");

// src/resources/service.ts
var import_node_crypto3 = require("node:crypto");
var import_zod3 = require("zod");

// src/resources/model.ts
var import_zod2 = require("zod");
var metadataInput = import_zod2.z.object({
  title: import_zod2.z.string().trim().min(1).max(120),
  description: import_zod2.z.string().trim().max(2e3).default(""),
  category: import_zod2.z.string().trim().min(1).max(40).default("\u5176\u4ED6")
}).strict();
var uploadInput = metadataInput.extend({
  originalName: import_zod2.z.string().trim().min(1).max(180).refine(
    (v) => !/[\\/]/.test(v) && Array.from(v).every(
      (c) => c.charCodeAt(0) >= 32 && c.charCodeAt(0) !== 127
    ),
    "\u6587\u4EF6\u540D\u4E0D\u80FD\u5305\u542B\u8DEF\u5F84\u6216\u63A7\u5236\u5B57\u7B26"
  ),
  size: import_zod2.z.number().int().min(1).max(100 * 1024 * 1024)
});
function fileType(name) {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  ensure(
    Object.hasOwn(RESOURCE_TYPES, ext),
    400,
    "RESOURCE_TYPE",
    "\u4EC5\u652F\u6301 PDF\u3001Office\u3001ZIP/7z\u3001TXT/CSV \u8D44\u6599\u6587\u4EF6"
  );
  return { ext, mime: RESOURCE_TYPES[ext] };
}
function resourceView(r) {
  const {
    id,
    title,
    description,
    category,
    originalName,
    size,
    mime,
    status,
    createdAt,
    updatedAt,
    publishedAt
  } = r;
  return {
    id,
    title,
    description,
    category,
    originalName,
    size,
    mime,
    status,
    createdAt,
    updatedAt,
    publishedAt
  };
}

// src/resources/qiniu.ts
var import_node_crypto2 = require("node:crypto");
var import_node_net2 = require("node:net");
var safe64 = (value) => Buffer.from(value).toString("base64").replaceAll("+", "-").replaceAll("/", "_");
var sign = (value, secret) => safe64((0, import_node_crypto2.createHmac)("sha1", secret).update(value).digest());
var QiniuProvider = class {
  constructor(send = fetch) {
    this.send = send;
  }
  status() {
    let valid = true;
    const bucket = process.env.QINIU_BUCKET ?? "", domain = process.env.QINIU_DOWNLOAD_DOMAIN ?? "";
    try {
      const u = new URL(domain);
      valid = u.protocol === "https:" && !u.username && !u.password && !u.port && u.pathname === "/" && !u.search && !u.hash && !(0, import_node_net2.isIP)(u.hostname) && u.hostname !== "localhost";
    } catch {
      valid = false;
    }
    const maxBytes = Number(process.env.QINIU_RESOURCE_MAX_BYTES ?? 52428800), budget = Number(process.env.QINIU_RESOURCE_BUDGET_BYTES ?? 134217728);
    return {
      configured: valid && !!process.env.QINIU_ACCESS_KEY && !!process.env.QINIU_SECRET_KEY && /^[a-zA-Z0-9][a-zA-Z0-9-]{1,62}$/.test(bucket) && Number.isSafeInteger(maxBytes) && maxBytes > 0 && maxBytes <= 104857600 && Number.isSafeInteger(budget) && budget >= maxBytes && budget <= 10737418240,
      bucket,
      domain: domain.replace(/\/$/, ""),
      maxBytes,
      budget
    };
  }
  config() {
    const status = this.status();
    ensure(
      status.configured,
      503,
      "RESOURCE_STORAGE_NOT_CONFIGURED",
      "\u8D44\u6599\u5B58\u50A8\u5C1A\u672A\u914D\u7F6E\uFF0C\u8BF7\u5728\u4E91\u51FD\u6570\u914D\u7F6E\u4E03\u725B\u7A7A\u95F4\u3001\u5BC6\u94A5\u548C HTTPS \u4E0B\u8F7D\u57DF\u540D"
    );
    return {
      ...status,
      ak: process.env.QINIU_ACCESS_KEY,
      sk: process.env.QINIU_SECRET_KEY
    };
  }
  check(record2) {
    const config = this.config();
    ensure(
      record2.bucket === config.bucket,
      409,
      "RESOURCE_BUCKET_CHANGED",
      "\u8D44\u6599\u6240\u5C5E\u7A7A\u95F4\u4E0E\u5F53\u524D\u914D\u7F6E\u4E0D\u540C\uFF0C\u8BF7\u5148\u6062\u590D\u6B63\u786E\u7684\u5B58\u50A8\u914D\u7F6E"
    );
    ensure(
      /^electronicclub\/resources\/v1\/[a-f0-9-]{36}\.[a-z0-9]+$/.test(
        record2.key
      ),
      400,
      "RESOURCE_KEY",
      "\u8D44\u6599\u5BF9\u8C61\u6807\u8BC6\u65E0\u6548"
    );
    return config;
  }
  ticket(record2, now) {
    const c = this.check(record2), url = process.env.QINIU_UPLOAD_URL ?? "https://upload.qiniup.com";
    ensure(
      /^https:\/\/(?:upload|up)(?:-[a-z0-9-]+)?\.(?:qiniup\.com|qbox\.me)$/.test(
        url
      ),
      503,
      "RESOURCE_UPLOAD_HOST",
      "\u4E03\u725B\u4E0A\u4F20\u5730\u5740\u914D\u7F6E\u65E0\u6548"
    );
    const policy = {
      scope: `${c.bucket}:${record2.key}`,
      deadline: Math.floor(now / 1e3) + 600,
      insertOnly: 1,
      fsizeMin: record2.size,
      fsizeLimit: record2.size,
      detectMime: 1,
      mimeLimit: [
        .../* @__PURE__ */ new Set([
          ...Object.values(RESOURCE_TYPES),
          "application/octet-stream",
          "application/x-zip-compressed",
          "application/x-ole-storage",
          "application/vnd.ms-office"
        ])
      ].join(";")
    };
    const encoded = safe64(JSON.stringify(policy));
    return {
      uploadUrl: url,
      token: `${c.ak}:${sign(encoded, c.sk)}:${encoded}`,
      key: record2.key,
      expiresAt: new Date(now + 6e5).toISOString()
    };
  }
  async management(record2, operation) {
    const c = this.check(record2), path = `/${operation}/${safe64(c.bucket + ":" + record2.key)}`;
    let response;
    try {
      response = await this.send("https://rs.qiniu.com" + path, {
        method: "POST",
        headers: {
          Authorization: `QBox ${c.ak}:${sign(path + "\n", c.sk)}`,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "",
        redirect: "manual",
        signal: AbortSignal.timeout(15e3)
      });
    } catch {
      throw new ApiError(
        502,
        "QINIU_UNREACHABLE",
        "\u6682\u65F6\u65E0\u6CD5\u8FDE\u63A5\u4E03\u725B\u4E91\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5"
      );
    }
    if (response.status === 612 || response.status === 404) {
      if (operation === "delete") return null;
      throw new ApiError(
        409,
        "RESOURCE_UPLOAD_MISSING",
        "\u4E03\u725B\u5C1A\u672A\u67E5\u5230\u8BE5\u6587\u4EF6\uFF0C\u8BF7\u786E\u8BA4\u4E0A\u4F20\u6210\u529F\u540E\u91CD\u8BD5"
      );
    }
    ensure(
      response.ok,
      502,
      "QINIU_REQUEST_FAILED",
      "\u4E03\u725B\u4E91\u8BF7\u6C42\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u5BC6\u94A5\u6743\u9650\u3001\u7A7A\u95F4\u548C\u7F51\u7EDC\u914D\u7F6E"
    );
    if (operation === "delete") return null;
    try {
      return await response.json();
    } catch {
      throw new ApiError(502, "QINIU_INVALID_RESPONSE", "\u4E03\u725B\u6587\u4EF6\u6821\u9A8C\u54CD\u5E94\u65E0\u6548");
    }
  }
  download(record2) {
    const c = this.check(record2);
    return c.domain + "/" + record2.key.split("/").map(encodeURIComponent).join("/") + "?attname=" + encodeURIComponent(record2.originalName);
  }
  async verify(record2) {
    const info = await this.management(record2, "stat");
    ensure(
      info && info.fsize === record2.size && typeof info.hash === "string" && info.hash.length >= 20 && info.hash.length <= 100,
      409,
      "RESOURCE_SIZE_MISMATCH",
      "\u4E0A\u4F20\u6587\u4EF6\u5927\u5C0F\u6216\u6821\u9A8C\u4FE1\u606F\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u91CD\u65B0\u4E0A\u4F20"
    );
    ensure(
      !/html|javascript|svg|executable/i.test(info.mimeType ?? ""),
      400,
      "RESOURCE_TYPE",
      "\u6587\u4EF6\u771F\u5B9E\u7C7B\u578B\u4E0D\u7B26\u5408\u8D44\u6599\u5E93\u8981\u6C42"
    );
    const c = this.check(record2);
    const base = this.download(record2) + "&e=" + Math.floor(Date.now() / 1e3 + 120);
    const url = base + "&token=" + c.ak + ":" + sign(base, c.sk);
    let response;
    try {
      response = await this.send(url, {
        headers: { Range: "bytes=0-8191" },
        redirect: "manual",
        signal: AbortSignal.timeout(15e3)
      });
    } catch {
      throw new ApiError(
        502,
        "RESOURCE_READ_FAILED",
        "\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\u4E03\u725B\u6587\u4EF6\uFF0C\u8BF7\u68C0\u67E5\u4E0B\u8F7D\u57DF\u540D\u548C HTTPS \u914D\u7F6E"
      );
    }
    ensure(
      response.ok && response.body,
      502,
      "RESOURCE_READ_FAILED",
      "\u65E0\u6CD5\u6821\u9A8C\u6587\u4EF6\u5185\u5BB9\uFF0C\u8BF7\u68C0\u67E5\u4E0B\u8F7D\u57DF\u540D\u548C\u6E90\u7AD9\u8BBF\u95EE"
    );
    const reader = response.body.getReader(), chunks = [];
    let length = 0;
    try {
      while (length < 8192) {
        const part = await reader.read();
        if (part.done) break;
        const take = part.value.subarray(0, 8192 - length);
        chunks.push(take);
        length += take.length;
      }
    } finally {
      await reader.cancel().catch(() => {
      });
    }
    const bytes = Buffer.concat(chunks.map((b) => Buffer.from(b)));
    validateFileHeader(record2.originalName, bytes);
    return { hash: info.hash };
  }
  async remove(record2) {
    await this.management(record2, "delete");
  }
};
function validateFileHeader(name, bytes) {
  const { ext } = fileType(name);
  let valid = false;
  if (ext === "pdf") valid = bytes.subarray(0, 5).toString() === "%PDF-";
  else if (["doc", "xls", "ppt"].includes(ext))
    valid = bytes.subarray(0, 8).equals(Buffer.from([208, 207, 17, 224, 161, 177, 26, 225]));
  else if (["docx", "xlsx", "pptx", "zip"].includes(ext))
    valid = bytes[0] === 80 && bytes[1] === 75 && (bytes[2] === 3 && bytes[3] === 4 || ext === "zip" && bytes[2] === 5 && bytes[3] === 6);
  else if (ext === "7z")
    valid = bytes.subarray(0, 6).equals(Buffer.from([55, 122, 188, 175, 39, 28]));
  else {
    try {
      const text4 = new TextDecoder("utf-8", { fatal: true }).decode(bytes, {
        stream: true
      });
      valid = !bytes.includes(0) && !/^\s*(?:<!doctype\s+html|<html|<script)/i.test(text4);
    } catch {
      valid = false;
    }
  }
  ensure(
    valid,
    400,
    "RESOURCE_FILE_SIGNATURE",
    "\u6587\u4EF6\u5185\u5BB9\u4E0E\u6240\u9009\u683C\u5F0F\u4E0D\u7B26\uFF0C\u8BF7\u9009\u62E9\u771F\u5B9E\u6709\u6548\u7684\u8D44\u6599\u6587\u4EF6"
  );
}

// src/resources/service.ts
var stateKey = "resources:storage";
function requireManager(ctx) {
  ensure(
    ctx.super || ctx.permissions.includes("resources.manage"),
    403,
    "FORBIDDEN",
    "\u6CA1\u6709\u8D44\u6599\u7BA1\u7406\u6743\u9650"
  );
}
async function audit(tx, uid, action, target, now) {
  const id = (0, import_node_crypto3.randomUUID)();
  await tx.set("audit_logs", id, {
    id,
    actor: uid,
    action,
    target,
    fields: [],
    createdAt: now
  });
}
var ResourceService = class {
  constructor(store, secure, clock = () => Date.now(), provider = new QiniuProvider()) {
    this.store = store;
    this.secure = secure;
    this.clock = clock;
    this.provider = provider;
  }
  async execute(token, method, path, input, q) {
    const match = path.match(
      /^\/api\/resources(?:\/([a-f0-9-]{36}|uploads|config)(?:\/(complete|update|delete|download))?)?$/
    );
    ensure(match, 404, "NOT_FOUND", "\u8D44\u6599\u63A5\u53E3\u4E0D\u5B58\u5728");
    const [, id, action] = match;
    if (method === "GET" && !id) {
      const options = import_zod3.z.object({
        page: import_zod3.z.coerce.number().int().min(1).max(1e4).default(1),
        pageSize: import_zod3.z.coerce.number().int().min(1).max(50).default(20),
        search: import_zod3.z.string().trim().max(80).default(""),
        category: import_zod3.z.string().trim().max(40).default(""),
        status: import_zod3.z.enum([
          "all",
          "uploading",
          "draft",
          "published",
          "deleting",
          "deleted"
        ]).optional(),
        admin: import_zod3.z.enum(["true", "false"]).default("false")
      }).strict().parse(q);
      const list = async () => {
        const result = await this.store.list(
          "club_resources",
          {
            search: options.search,
            category: options.category,
            ...options.admin === "true" ? { status: options.status ?? "all" } : { public: true, status: "published" }
          },
          {
            offset: (options.page - 1) * options.pageSize,
            limit: options.pageSize
          }
        );
        return {
          data: {
            ...result,
            items: result.items.map(resourceView),
            page: options.page,
            pageSize: options.pageSize
          }
        };
      };
      if (options.admin === "true")
        return this.secure(token, async (_tx, ctx) => {
          requireManager(ctx);
          return list();
        });
      return list();
    }
    if (method === "GET" && id === "config")
      return this.secure(token, async (tx, ctx) => {
        requireManager(ctx);
        const state = await tx.get("system", stateKey);
        return {
          data: { ...this.provider.status(), reservedBytes: state?.bytes ?? 0 }
        };
      });
    if (method === "POST" && id === "uploads")
      return this.secure(token, async (tx, ctx) => {
        requireManager(ctx);
        const body = uploadInput.parse(input), type = fileType(body.originalName), status = this.provider.status();
        ensure(
          status.configured,
          503,
          "RESOURCE_STORAGE_NOT_CONFIGURED",
          "\u4E03\u725B\u8D44\u6599\u5B58\u50A8\u5C1A\u672A\u914D\u7F6E\uFF0C\u8BF7\u5148\u5B8C\u6210\u4E91\u51FD\u6570\u914D\u7F6E"
        );
        ensure(
          body.size <= status.maxBytes,
          400,
          "RESOURCE_TOO_LARGE",
          `\u8D44\u6599\u6587\u4EF6\u8D85\u8FC7\u5F53\u524D\u5927\u5C0F\u4E0A\u9650\uFF08${Math.floor(status.maxBytes / 1024 / 1024)}MB\uFF09`
        );
        const rateKey = "resources:upload-rate:" + ctx.member.uid;
        let rate = await tx.get(
          "system",
          rateKey
        );
        if (!rate || rate.at + 6e5 <= this.clock())
          rate = { at: this.clock(), count: 0 };
        ensure(
          rate.count < 10,
          429,
          "RESOURCE_RATE_LIMIT",
          "\u4E0A\u4F20\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5"
        );
        const current = await tx.get(
          "system",
          stateKey
        ) ?? { bytes: 0 };
        ensure(
          current.bytes + body.size <= status.budget,
          409,
          "RESOURCE_BUDGET",
          "\u8D44\u6599\u5E93\u5DF2\u8FBE\u5230\u9884\u8BBE\u5B58\u50A8\u9884\u7B97\uFF0C\u8BF7\u5148\u6E05\u7406\u8D44\u6599\u6216\u8C03\u6574\u9884\u7B97"
        );
        const now = new Date(this.clock()).toISOString(), rid = (0, import_node_crypto3.randomUUID)();
        const record2 = {
          ...body,
          id: rid,
          mime: type.mime,
          key: `electronicclub/resources/v1/${rid}.${type.ext}`,
          bucket: status.bucket,
          ownerUid: ctx.member.uid,
          hash: "",
          status: "uploading",
          createdAt: now,
          updatedAt: now,
          publishedAt: null,
          expiresAt: new Date(this.clock() + 6e5).toISOString()
        };
        const ticket = this.provider.ticket(record2, this.clock());
        await tx.set("club_resources", rid, record2);
        await tx.set("system", stateKey, { bytes: current.bytes + body.size });
        await tx.set("system", rateKey, { ...rate, count: rate.count + 1 });
        await audit(tx, ctx.member.uid, "resources.upload", rid, now);
        return { data: { id: rid, ...ticket } };
      });
    ensure(id && /^[a-f0-9-]{36}$/.test(id), 404, "NOT_FOUND", "\u8D44\u6599\u4E0D\u5B58\u5728");
    if (method === "GET" && action === "download") {
      const record2 = await this.store.read("club_resources", id);
      ensure(
        record2?.status === "published",
        404,
        "NOT_FOUND",
        "\u8D44\u6599\u5C1A\u672A\u53D1\u5E03\u6216\u5DF2\u4E0B\u67B6"
      );
      return {
        data: {
          url: this.provider.download(record2),
          filename: record2.originalName
        }
      };
    }
    if (method === "POST" && action === "complete") {
      const result = await this.secure(token, async (tx, ctx) => {
        requireManager(ctx);
        import_zod3.z.object({}).strict().parse(input);
        const r = await tx.get("club_resources", id);
        ensure(
          r && r.status === "uploading",
          409,
          "RESOURCE_STATE",
          "\u8D44\u6599\u4E0D\u5728\u5F85\u4E0A\u4F20\u72B6\u6001"
        );
        return { data: r };
      });
      const record2 = result.data, verified = await this.provider.verify(record2);
      return this.secure(token, async (tx, ctx) => {
        requireManager(ctx);
        const current = await tx.get("club_resources", id);
        ensure(
          current?.status === "uploading" && current.key === record2.key,
          409,
          "RESOURCE_STATE",
          "\u8D44\u6599\u72B6\u6001\u5DF2\u6539\u53D8\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u8BD5"
        );
        const next = {
          ...current,
          hash: verified.hash,
          status: "draft",
          updatedAt: new Date(this.clock()).toISOString()
        };
        await tx.set("club_resources", id, next);
        await audit(
          tx,
          ctx.member.uid,
          "resources.complete",
          id,
          next.updatedAt
        );
        return { data: resourceView(next) };
      });
    }
    if (method === "POST" && action === "update")
      return this.secure(token, async (tx, ctx) => {
        requireManager(ctx);
        const body = metadataInput.extend({ status: import_zod3.z.enum(["draft", "published"]) }).parse(input);
        const record2 = await tx.get("club_resources", id);
        ensure(
          record2 && ["draft", "published"].includes(record2.status),
          409,
          "RESOURCE_STATE",
          "\u6587\u4EF6\u5C1A\u672A\u6821\u9A8C\u5B8C\u6210\u6216\u5DF2\u5220\u9664"
        );
        const next = {
          ...record2,
          ...body,
          publishedAt: record2.publishedAt ?? (body.status === "published" ? new Date(this.clock()).toISOString() : null),
          updatedAt: new Date(this.clock()).toISOString()
        };
        await tx.set("club_resources", id, next);
        await audit(tx, ctx.member.uid, "resources.update", id, next.updatedAt);
        return { data: resourceView(next) };
      });
    if (method === "POST" && action === "delete") {
      const result = await this.secure(token, async (tx, ctx) => {
        requireManager(ctx);
        import_zod3.z.object({}).strict().parse(input);
        const r = await tx.get("club_resources", id);
        ensure(r, 404, "NOT_FOUND", "\u8D44\u6599\u4E0D\u5B58\u5728");
        if (r.status === "deleted") return { data: r };
        const next = {
          ...r,
          status: "deleting",
          updatedAt: new Date(this.clock()).toISOString()
        };
        await tx.set("club_resources", id, next);
        await audit(
          tx,
          ctx.member.uid,
          "resources.delete.request",
          id,
          next.updatedAt
        );
        return { data: next };
      });
      const record2 = result.data;
      if (record2.status === "deleted") return { data: { deleted: true } };
      if (Date.parse(record2.expiresAt) + 3e4 > this.clock())
        return {
          data: {
            pending: true,
            deleteAfter: new Date(
              Date.parse(record2.expiresAt) + 3e4
            ).toISOString()
          }
        };
      await this.provider.remove(record2);
      await finishDeletion(this.store, record2, this.clock());
      return { data: { deleted: true } };
    }
    throw new ApiError(404, "NOT_FOUND", "\u8D44\u6599\u63A5\u53E3\u4E0D\u5B58\u5728");
  }
};
async function finishDeletion(store, record2, now) {
  await store.run(async (tx) => {
    const current = await tx.get("club_resources", record2.id);
    if (!current || current.status === "deleted") return;
    ensure(
      current.status === "deleting",
      409,
      "RESOURCE_STATE",
      "\u8D44\u6599\u72B6\u6001\u5DF2\u6539\u53D8"
    );
    const state = await tx.get("system", stateKey) ?? {
      bytes: current.size
    };
    await tx.set("club_resources", current.id, {
      ...current,
      status: "deleted",
      updatedAt: new Date(now).toISOString()
    });
    await tx.set("system", stateKey, {
      bytes: Math.max(0, state.bytes - current.size)
    });
    await audit(
      tx,
      "private-resource-cleanup",
      "resources.delete.complete",
      current.id,
      new Date(now).toISOString()
    );
  });
}

// src/public-read-cache.ts
function publicReadKey(method, path, query) {
  if (method !== "GET") return null;
  const publication = /^\/api\/public\/(events|articles)(?:\/[a-f0-9-]{36})?$/.test(path);
  const resources = path === "/api/resources" && !query.admin && !query.status;
  if (!publication && !resources) return null;
  const entries = Object.entries(query).sort(([a], [b]) => a.localeCompare(b));
  if (entries.some(
    ([key3]) => !["page", "pageSize", "search", "category"].includes(key3)
  ))
    return null;
  const key2 = path + "?" + new URLSearchParams(entries).toString();
  return key2.length <= 1024 ? key2 : null;
}
var PublicReadCache = class {
  constructor(clock = () => Date.now(), maxEntries = 64, maxBytes = 4 * 1024 * 1024) {
    this.clock = clock;
    this.maxEntries = maxEntries;
    this.maxBytes = maxBytes;
  }
  entries = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  bytes = 0;
  generation = 0;
  clear() {
    this.generation++;
    this.entries.clear();
    this.pending.clear();
    this.bytes = 0;
  }
  async load(key2, ttl, work) {
    for (const [id, entry] of this.entries) {
      if (entry.expires <= this.clock()) {
        this.bytes -= entry.bytes;
        this.entries.delete(id);
      }
    }
    const cached = this.entries.get(key2);
    if (cached) return structuredClone(cached.value);
    const pending = this.pending.get(key2);
    if (pending) return structuredClone(await pending);
    if (this.pending.size >= this.maxEntries) return work();
    const generation = this.generation;
    const loading = Promise.resolve().then(work).then((value) => {
      const bytes = Buffer.byteLength(JSON.stringify(value));
      if (generation === this.generation && bytes <= this.maxBytes / 4) {
        while (this.entries.size >= this.maxEntries || this.bytes + bytes > this.maxBytes) {
          const id = this.entries.keys().next().value;
          if (id === void 0) break;
          this.bytes -= this.entries.get(id).bytes;
          this.entries.delete(id);
        }
        this.entries.set(key2, {
          value: structuredClone(value),
          expires: this.clock() + ttl,
          bytes
        });
        this.bytes += bytes;
      }
      return value;
    });
    this.pending.set(key2, loading);
    try {
      return structuredClone(await loading);
    } finally {
      if (this.pending.get(key2) === loading) this.pending.delete(key2);
    }
  }
};

// src/public-site-publisher.ts
var import_node_crypto6 = require("node:crypto");

// ../../packages/shared/src/public-site.ts
var PUBLIC_SITE_KEY = "electronicclub/public-site/v1/site.json";
var PUBLIC_SITE_MAX_BYTES = 8 * 1024 * 1024;
var PublicSiteError = class extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var fail = (status, code, message) => {
  throw new PublicSiteError(status, code, message);
};
function publicOrigin(value) {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.origin !== value || url.username || url.password || url.hostname === "localhost" || url.hostname.includes(":") || /^\d+(?:\.\d+){3}$/.test(url.hostname))
    throw new Error("INVALID_PUBLIC_ORIGIN");
  return url.origin;
}
function isPublicSitePath(path, q) {
  if (q.live === "true" || q.admin === "true" || q.status) return false;
  return /^\/api\/public\/(events|articles)(?:\/[a-f0-9-]{36})?$/.test(path) || path === "/api/public/popup" || path === "/api/resources" || /^\/api\/resources\/[a-f0-9-]{36}\/download$/.test(path) || /^\/api\/media\/[a-f0-9-]{36}$/.test(path) || /^\/api\/forum\/(?:boards(?:\/[a-zA-Z0-9-]{1,60})?|posts(?:\/[a-f0-9-]{36}(?:\/comments)?)?|images\/[a-f0-9-]{36})$/.test(path);
}
function page(items, q, max = 100) {
  const number = (name, fallback, limit) => {
    const value = q[name] === void 0 ? fallback : Number(q[name]);
    if (!Number.isSafeInteger(value) || value < 1 || value > limit)
      fail(400, "INVALID_INPUT", "\u5206\u9875\u53C2\u6570\u65E0\u6548");
    return value;
  };
  const current = number("page", 1, 1e4), size = number("pageSize", 20, max);
  return { items: items.slice((current - 1) * size, current * size), total: items.length, page: current, pageSize: size };
}
var missing = () => fail(404, "NOT_FOUND", "\u5185\u5BB9\u5C1A\u672A\u516C\u5F00\u6216\u4E0D\u5B58\u5728");
var text2 = (q, key2, max) => {
  const value = q[key2] ?? "";
  if (value.length > max) fail(400, "INVALID_INPUT", "\u67E5\u8BE2\u5185\u5BB9\u8FC7\u957F");
  return value;
};
function readPublicSite(site, path, q, now = Date.now()) {
  if (!isPublicSitePath(path, q)) missing();
  if (path.startsWith("/api/media/") || path.startsWith("/api/forum/images/")) {
    const asset = site.assets[path];
    if (!asset) missing();
    return { asset };
  }
  if (path === "/api/public/popup") {
    const stamp = new Date(now).toISOString();
    const eligible = site.popups.filter((p) => p.enabled && !["retired", "disabled"].includes(p.state) && p.startsAt <= stamp && p.expiresAt > stamp && (p.targetType === "event" ? site.events : site.articles).some((v) => v.id === p.targetId));
    eligible.sort((a, b) => b.priority - a.priority || b.startsAt.localeCompare(a.startsAt) || b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id));
    return { data: eligible[0] ? { ...eligible[0], state: "active" } : null };
  }
  if (path.startsWith("/api/public/")) {
    const [, , , kind2, id2] = path.split("/");
    const rows = kind2 === "events" ? site.events : site.articles;
    if (id2) return { data: rows.find((v) => v.id === id2) ?? missing() };
    const search2 = text2(q, "search", 100), category = text2(q, "category", 100);
    const items2 = rows.filter((v) => v.title.includes(search2) && (!category || "category" in v && v.category === category)).sort((a, b) => Number("pinned" in b && b.pinned) - Number("pinned" in a && a.pinned) || String(b.publishedAt).localeCompare(String(a.publishedAt)) || a.id.localeCompare(b.id));
    return { data: page(items2, q) };
  }
  if (path.startsWith("/api/resources")) {
    if (path.endsWith("/download")) {
      const record2 = site.resources.find((v) => v.id === path.split("/")[3]) ?? missing();
      return { data: { url: record2.downloadUrl, filename: record2.originalName } };
    }
    const search2 = text2(q, "search", 80).trim().toLowerCase(), category = text2(q, "category", 40).trim();
    const items2 = site.resources.filter((v) => (!category || v.category === category) && [v.title, v.description, v.originalName].join(" ").toLowerCase().includes(search2)).sort((a, b) => String(b.publishedAt).localeCompare(String(a.publishedAt)) || a.id.localeCompare(b.id)).map(({ downloadUrl: _url, ...metadata }) => {
      void _url;
      return metadata;
    });
    return { data: page(items2, q, 50) };
  }
  const [, , , kind, id, action] = path.split("/");
  if (kind === "boards") {
    if (id) return { data: site.boards.find((v) => v.id === id) ?? missing() };
    return { data: page([...site.boards].sort((a, b) => a.position - b.position || a.id.localeCompare(b.id)), q) };
  }
  if (id) {
    const post = site.posts.find((v) => v.id === id) ?? missing();
    if (!action) return { data: post };
    const items2 = site.comments.filter((v) => v.postId === id).sort((a, b) => a.floor - b.floor);
    if (q.anchor) {
      const index = items2.findIndex((v) => v.id === q.anchor);
      if (index < 0) missing();
      q = { ...q, page: String(1 + Math.floor(index / 20)), pageSize: "20" };
    }
    return { data: page(items2, q) };
  }
  const search = text2(q, "search", 80).toLowerCase(), board = text2(q, "boardId", 60), sort = q.sort ?? "latest";
  if (!["latest", "reply", "hot", "featured"].includes(sort)) fail(400, "INVALID_INPUT", "\u6392\u5E8F\u65B9\u5F0F\u65E0\u6548");
  const items = site.posts.filter((v) => (!board || v.boardId === board) && (!search || (v.title + " " + v.body).toLowerCase().includes(search)) && (sort !== "featured" || v.featured)).sort((a, b) => Number(b.pinned) - Number(a.pinned) || (sort === "hot" ? b.likeCount * 3 + b.commentCount * 2 - (a.likeCount * 3 + a.commentCount * 2) : 0) || (sort === "reply" ? b.lastReplyAt.localeCompare(a.lastReplyAt) : b.createdAt.localeCompare(a.createdAt)) || a.id.localeCompare(b.id)).map((v) => ({ ...v, body: v.body.slice(0, 240) }));
  return { data: page(items, q) };
}
async function limitedBytes(response, limit) {
  if (Number(response.headers.get("content-length")) > limit || !response.body)
    throw new Error("PUBLIC_RESPONSE_SIZE");
  const reader = response.body.getReader(), chunks = [];
  let size = 0;
  try {
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      const value = part.value;
      const bytes = value instanceof ArrayBuffer ? new Uint8Array(value) : ArrayBuffer.isView(value) ? new Uint8Array(value.buffer, value.byteOffset, value.byteLength) : null;
      if (!bytes || (size += bytes.byteLength) > limit) throw new Error("PUBLIC_RESPONSE_SIZE");
      chunks.push(new Uint8Array(bytes));
    }
  } finally {
    await reader.cancel().catch(() => {
    });
    reader.releaseLock();
  }
  const result = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }
  return result;
}
async function fetchPublicSite(origin, send = fetch, now = Date.now()) {
  const base = publicOrigin(origin);
  const response = await send(`${base}/${PUBLIC_SITE_KEY}?v=${Math.floor(now / 5e3)}`, {
    cache: "no-store",
    redirect: "manual",
    signal: AbortSignal.timeout(1e4)
  });
  if (!response.ok) throw new Error("PUBLIC_SITE_UNAVAILABLE");
  const site = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await limitedBytes(response, PUBLIC_SITE_MAX_BYTES)));
  if (site.format !== "eclub-public-v1" || typeof site.revision !== "string" || !["events", "articles", "popups", "boards", "posts", "comments", "resources"].every((k) => Array.isArray(site[k])) || !site.assets || typeof site.assets !== "object") throw new Error("PUBLIC_SITE_FORMAT");
  return site;
}
async function fetchPublicAsset(origin, asset, send = fetch) {
  if (!/^electronicclub\/public-site\/v1\/assets\/[a-f0-9]{64}\.(jpg|png|webp)$/.test(asset.key) || !["image/jpeg", "image/png", "image/webp"].includes(asset.mime) || !Number.isSafeInteger(asset.bytes) || asset.bytes < 1 || asset.bytes > 51200) throw new Error("PUBLIC_ASSET_FORMAT");
  const response = await send(`${publicOrigin(origin)}/${asset.key}`, {
    cache: "no-store",
    redirect: "manual",
    signal: AbortSignal.timeout(1e4)
  });
  if (!response.ok) throw new Error("PUBLIC_ASSET_UNAVAILABLE");
  const bytes = await limitedBytes(response, 51200);
  if (bytes.length !== asset.bytes) throw new Error("PUBLIC_ASSET_SIZE");
  return bytes;
}

// src/forum/images.ts
var import_node_zlib = require("node:zlib");
var bad = () => {
  throw new ApiError(
    400,
    "INVALID_IMAGE",
    "\u56FE\u7247\u683C\u5F0F\u6216\u6587\u4EF6\u5185\u5BB9\u4E0D\u5408\u6CD5\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u56FE\u7247"
  );
};
function inspectImage(uri, maxBytes = 32768) {
  const match = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(uri);
  if (!match) return bad();
  const buffer = Buffer.from(match[2], "base64");
  if (buffer.toString("base64") !== match[2] || buffer.length > maxBytes || buffer.length < 20)
    return bad();
  let width = 0, height = 0;
  if (match[1] === "png") {
    if (!buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])))
      return bad();
    let offset = 8, header = false, pixels = false, ended = false, channels = 0;
    const chunks = [];
    while (offset + 12 <= buffer.length) {
      const n = buffer.readUInt32BE(offset), kind = buffer.toString("ascii", offset + 4, offset + 8);
      if (n > buffer.length - offset - 12 || crc32(buffer.subarray(offset + 4, offset + 8 + n)) !== buffer.readUInt32BE(offset + 8 + n))
        return bad();
      if (kind === "IHDR") {
        if (header || offset !== 8 || n !== 13) return bad();
        header = true;
        width = buffer.readUInt32BE(offset + 8);
        height = buffer.readUInt32BE(offset + 12);
        channels = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[buffer[offset + 17]] ?? 0;
        if (buffer[offset + 16] !== 8 || buffer[offset + 18] !== 0 || buffer[offset + 19] !== 0 || buffer[offset + 20] !== 0 || !channels)
          return bad();
      }
      if (kind === "IDAT" && n > 0) {
        pixels = true;
        chunks.push(buffer.subarray(offset + 8, offset + 8 + n));
      }
      if (kind === "IEND") {
        if (n !== 0 || offset + 12 !== buffer.length) return bad();
        ended = true;
      }
      if (kind === "acTL") return bad();
      offset += n + 12;
    }
    if (!header || !pixels || !ended || offset !== buffer.length || width > 2e3 || height > 2e3)
      return bad();
    try {
      const decoded = (0, import_node_zlib.inflateSync)(Buffer.concat(chunks), {
        maxOutputLength: 161e5
      }), stride = width * channels + 1;
      if (decoded.length !== stride * height) return bad();
      for (let row = 0; row < height; row++)
        if (decoded[row * stride] > 4) return bad();
    } catch {
      return bad();
    }
  } else if (match[1] === "jpeg") {
    if (buffer[0] !== 255 || buffer[1] !== 216 || buffer[buffer.length - 2] !== 255 || buffer[buffer.length - 1] !== 217)
      return bad();
    let i = 2, scan = false;
    while (i < buffer.length - 2) {
      if (buffer[i] !== 255) return bad();
      while (buffer[i] === 255) i++;
      const marker = buffer[i++];
      if (marker === 217) return bad();
      if (marker === 0 || marker === 216) return bad();
      if (marker >= 208 && marker <= 215) continue;
      if (i + 2 > buffer.length) return bad();
      const n = buffer.readUInt16BE(i);
      if (n < 2 || i + n > buffer.length) return bad();
      if ([192, 193, 194].includes(marker)) {
        if (n < 8) return bad();
        height = buffer.readUInt16BE(i + 3);
        width = buffer.readUInt16BE(i + 5);
      }
      if (marker === 218) {
        scan = true;
        i += n;
        while (i < buffer.length - 1) {
          if (buffer[i] !== 255) {
            i++;
            continue;
          }
          const next = buffer[i + 1];
          if (next === 0 || next >= 208 && next <= 215) {
            i += 2;
            continue;
          }
          break;
        }
        continue;
      }
      i += n;
    }
    if (!scan || !width || !height) return bad();
  } else {
    if (buffer.toString("ascii", 0, 4) !== "RIFF" || buffer.toString("ascii", 8, 12) !== "WEBP" || buffer.readUInt32LE(4) + 8 !== buffer.length)
      return bad();
    let offset = 12, frame = false;
    while (offset + 8 <= buffer.length) {
      const type = buffer.toString("ascii", offset, offset + 4), n = buffer.readUInt32LE(offset + 4), p = offset + 8;
      if (n > buffer.length - p) return bad();
      if (type === "ANIM" || type === "ANMF") return bad();
      if (type === "VP8X") {
        if (n < 10 || (buffer[p] & 2) !== 0) return bad();
        width = 1 + buffer.readUIntLE(p + 4, 3);
        height = 1 + buffer.readUIntLE(p + 7, 3);
      }
      if (type === "VP8 ") {
        if (n < 10 || !buffer.subarray(p + 3, p + 6).equals(Buffer.from([157, 1, 42])))
          return bad();
        width = buffer.readUInt16LE(p + 6) & 16383;
        height = buffer.readUInt16LE(p + 8) & 16383;
        frame = true;
      }
      if (type === "VP8L") {
        if (n < 5 || buffer[p] !== 47) return bad();
        const bits = buffer.readUInt32LE(p + 1);
        width = 1 + (bits & 16383);
        height = 1 + (bits >>> 14 & 16383);
        frame = true;
      }
      offset = p + n + n % 2;
    }
    if (!frame || offset !== buffer.length) return bad();
  }
  if (!width || !height || width > 2e3 || height > 2e3 || width * height > 4e6)
    return bad();
  return {
    buffer,
    width,
    height,
    mime: "image/" + match[1],
    bytes: buffer.length
  };
}
function crc32(data) {
  let crc = 4294967295;
  for (const byte of data) {
    crc ^= byte;
    for (let n = 0; n < 8; n++)
      crc = crc & 1 ? crc >>> 1 ^ 3988292384 : crc >>> 1;
  }
  return (crc ^ 4294967295) >>> 0;
}

// src/public-site-storage.ts
var import_node_crypto5 = require("node:crypto");

// src/public-site-timed.ts
var import_node_crypto4 = require("node:crypto");
var TIMED_SITE_KEY = "electronicclub/public-site/v1/timed.bin";
var key = () => {
  if (!process.env.QINIU_SECRET_KEY) throw Error("PUBLIC_TIMED_KEY_NOT_CONFIGURED");
  return (0, import_node_crypto4.createHash)("sha256").update("eclub-timed-v1\n" + process.env.QINIU_SECRET_KEY).digest();
};
function encryptTimed(value) {
  const nonce = (0, import_node_crypto4.randomBytes)(12), cipher = (0, import_node_crypto4.createCipheriv)("aes-256-gcm", key(), nonce);
  cipher.setAAD(Buffer.from("eclub-timed-v1"));
  const bytes = Buffer.concat([cipher.update(JSON.stringify(value)), cipher.final()]);
  return Buffer.concat([Buffer.from("ECT1"), nonce, cipher.getAuthTag(), bytes]);
}
function decryptTimed(bytes) {
  const value = Buffer.from(bytes);
  if (value.length < 32 || value.subarray(0, 4).toString() !== "ECT1") throw Error("PUBLIC_TIMED_FORMAT");
  const cipher = (0, import_node_crypto4.createDecipheriv)("aes-256-gcm", key(), value.subarray(4, 16));
  cipher.setAAD(Buffer.from("eclub-timed-v1"));
  cipher.setAuthTag(value.subarray(16, 32));
  const data = JSON.parse(Buffer.concat([cipher.update(value.subarray(32)), cipher.final()]).toString());
  if (!Array.isArray(data.popups) || !Array.isArray(data.retired) || !data.assets) throw Error("PUBLIC_TIMED_FORMAT");
  return data;
}
var popupVersion = (p) => p.id + ":" + p.version;
function scheduledPopup(data, now) {
  const retired = new Set(data.retired);
  const events = [...new Set(data.popups.flatMap((p) => [Math.max(Date.parse(p.startsAt), Date.parse(p.createdAt)), Date.parse(p.expiresAt)]))].filter((v) => Number.isFinite(v) && v <= now).sort((a, b) => a - b);
  let current = null;
  for (const time of events) {
    const eligible = data.popups.filter((p) => p.enabled && !["retired", "disabled"].includes(p.state) && !retired.has(popupVersion(p)) && Math.max(Date.parse(p.startsAt), Date.parse(p.createdAt)) <= time && Date.parse(p.expiresAt) > time).sort((a, b) => b.priority - a.priority || b.startsAt.localeCompare(a.startsAt) || b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id));
    const chosen = eligible[0] ?? null;
    if (current && current.id !== chosen?.id) retired.add(popupVersion(current));
    current = chosen;
  }
  return { popup: current ? { ...current, state: "active" } : null, retired: [...retired] };
}

// src/public-site-storage.ts
var QiniuPublicSiteStorage = class {
  constructor(send = fetch) {
    this.send = send;
  }
  origin() {
    return publicOrigin(process.env.PUBLIC_SITE_ORIGIN ?? process.env.QINIU_DOWNLOAD_DOMAIN ?? "");
  }
  configured() {
    try {
      return !!this.origin() && new QiniuProvider(this.send).status().configured;
    } catch {
      return false;
    }
  }
  config(key2) {
    if (!this.configured()) throw Error("PUBLIC_STORAGE_NOT_CONFIGURED");
    if (![PUBLIC_SITE_KEY, TIMED_SITE_KEY].includes(key2) && !/^electronicclub\/public-site\/v1\/assets\/[a-f0-9]{64}\.(jpg|png|webp)$/.test(key2))
      throw Error("PUBLIC_OBJECT_KEY");
    return { bucket: process.env.QINIU_BUCKET, ak: process.env.QINIU_ACCESS_KEY, sk: process.env.QINIU_SECRET_KEY };
  }
  async read() {
    let missing2 = false;
    try {
      return await fetchPublicSite(this.origin(), async (url, options) => {
        const response = await this.send(url, options);
        missing2 = response.status === 404 || response.status === 612;
        return response;
      });
    } catch (error) {
      if (missing2) return null;
      throw error;
    }
  }
  async asset(value) {
    return fetchPublicAsset(this.origin(), value, this.send);
  }
  async timed() {
    const response = await this.send(`${this.origin()}/${TIMED_SITE_KEY}?v=${Math.floor(Date.now() / 5e3)}`, {
      redirect: "manual",
      cache: "no-store",
      signal: AbortSignal.timeout(1e4)
    });
    if ([404, 612].includes(response.status)) return null;
    if (!response.ok) throw Error("PUBLIC_TIMED_UNAVAILABLE");
    return decryptTimed(await limitedBytes(response, PUBLIC_SITE_MAX_BYTES));
  }
  async putTimed(value) {
    const bytes = encryptTimed(value);
    if (bytes.length > PUBLIC_SITE_MAX_BYTES) throw Error("PUBLIC_TIMED_TOO_LARGE");
    await this.put(TIMED_SITE_KEY, bytes, "application/octet-stream");
  }
  async put(key2, data, mime) {
    const c = this.config(key2), url = process.env.QINIU_UPLOAD_URL ?? "https://upload.qiniup.com";
    if (!/^https:\/\/(?:upload|up)(?:-[a-z0-9-]+)?\.(?:qiniup\.com|qbox\.me)$/.test(url)) throw Error("PUBLIC_UPLOAD_HOST");
    const policy = safe64(JSON.stringify({
      scope: `${c.bucket}:${key2}`,
      deadline: Math.floor(Date.now() / 1e3) + 120,
      insertOnly: 0,
      fsizeLimit: data.length,
      mimeLimit: mime
    }));
    const signature = safe64((0, import_node_crypto5.createHmac)("sha1", c.sk).update(policy).digest());
    const form = new FormData();
    form.set("key", key2);
    form.set("token", `${c.ak}:${signature}:${policy}`);
    form.set("file", new Blob([new Uint8Array(data)], { type: mime }), key2.split("/").pop());
    const response = await this.send(url, { method: "POST", body: form, redirect: "manual", signal: AbortSignal.timeout(8e3) });
    if (!response.ok || (await response.json()).key !== key2) throw Error("PUBLIC_UPLOAD_FAILED");
  }
  async remove(key2) {
    const c = this.config(key2);
    if ([PUBLIC_SITE_KEY, TIMED_SITE_KEY].includes(key2)) throw Error("PUBLIC_MANIFEST_DELETE_FORBIDDEN");
    const path = "/delete/" + safe64(c.bucket + ":" + key2);
    const response = await this.send("https://rs.qiniu.com" + path, {
      method: "POST",
      body: "",
      redirect: "manual",
      signal: AbortSignal.timeout(8e3),
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: `QBox ${c.ak}:${safe64((0, import_node_crypto5.createHmac)("sha1", c.sk).update(path + "\n").digest())}`
      }
    });
    if (!response.ok && ![404, 612].includes(response.status)) throw Error("PUBLIC_DELETE_FAILED");
  }
};

// src/public-site-publisher.ts
var stateKey2 = "public-site:publisher";
async function markPublicDirty(tx) {
  const state = await tx.get("system", stateKey2) ?? { requested: 0, published: 0, dirty: true, owner: null, until: 0 };
  await tx.set("system", stateKey2, { ...state, requested: state.requested + 1, dirty: true });
}
function changesPublicContent(path) {
  if (/^\/api\/(articles|popups)(?:\/|$)/.test(path)) return true;
  if (/^\/api\/events(?:\/|$)/.test(path)) return !/\/checkin$/.test(path);
  if (/^\/api\/forum\/(boards|posts|comments)(?:\/|$)/.test(path)) return !/\/(favorite|view)$/.test(path);
  if (/^\/api\/resources\/[a-f0-9-]{36}\/(update|delete)$/.test(path)) return true;
  return path === "/api/profile" || /^\/api\/members\/[^/]+(?:\/(restore|delete|purge|anonymize))?$/.test(path);
}
function pick(raw, keys2) {
  return Object.fromEntries(keys2.filter((key2) => Object.hasOwn(raw, key2)).map((key2) => [key2, raw[key2]]));
}
var contentKeys = ["id", "title", "summary", "content", "cover", "status", "publishedAt", "createdAt", "updatedAt", "publisherUid", "publisherName"];
var boardKeys = ["id", "name", "description", "position", "status", "requireReview", "createdAt", "updatedAt"];
var postKeys = ["id", "boardId", "authorUid", "title", "body", "imageIds", "status", "pinned", "featured", "locked", "commentsClosed", "viewCount", "likeCount", "commentCount", "commentSequence", "lastReplyAt", "createdAt", "updatedAt"];
var commentKeys = ["id", "postId", "authorUid", "parentId", "body", "status", "floor", "createdAt", "updatedAt"];
var PublicSitePublisher = class {
  constructor(store, readImage, storage = new QiniuPublicSiteStorage(), resources = new QiniuProvider(), clock = () => Date.now()) {
    this.store = store;
    this.readImage = readImage;
    this.storage = storage;
    this.resources = resources;
    this.clock = clock;
  }
  async status() {
    const state = await this.store.read("system", stateKey2);
    const price = Number(process.env.PG_POINTS_PER_CORE_SECOND);
    return {
      configured: this.storage.configured(),
      mode: process.env.PUBLIC_SITE_MODE === "qiniu" ? "qiniu" : "database",
      origin: this.storage.configured() ? this.storage.origin() : "",
      target: 1500,
      reserve: 300,
      pointPrice: Number.isFinite(price) && price > 0 ? price : null,
      dirty: state?.dirty ?? true,
      generatedAt: state?.generatedAt ?? null,
      requested: state?.requested ?? 0,
      published: state?.published ?? 0,
      pendingAssets: state?.pendingAssets ?? 0,
      garbage: state?.cleanupPending ?? 0
    };
  }
  async lease(tx, owner) {
    const state = await tx.get("system", stateKey2);
    if (state?.owner !== owner || this.clock() + 1e4 >= state.until) throw Error("PUBLIC_LEASE_EXPIRED");
    return state;
  }
  async sync() {
    const configured = this.storage.configured(), owner = (0, import_node_crypto6.randomUUID)(), deadline = this.clock() + 4e4;
    const claimed = await this.store.run(async (tx) => {
      const state = await tx.get("system", stateKey2) ?? { requested: 0, published: 0, dirty: true, owner: null, until: 0 };
      state.requested++;
      state.dirty = true;
      const available = configured && (!state.owner || state.until <= this.clock());
      if (available) {
        state.owner = owner;
        state.until = this.clock() + 6e4;
      }
      await tx.set("system", stateKey2, state);
      return available;
    });
    if (!configured) return "failed";
    if (!claimed) return "pending";
    try {
      for (let attempt = 0; attempt < 2 && this.clock() < deadline; attempt++) {
        const state = await this.store.run((tx) => this.lease(tx, owner));
        const { snapshot, records, paths, pending, timed } = await this.build(deadline, owner);
        const bytes = Buffer.from(JSON.stringify(snapshot));
        if (bytes.length > PUBLIC_SITE_MAX_BYTES) throw Error("PUBLIC_SITE_TOO_LARGE");
        await this.store.run((tx) => this.lease(tx, owner));
        await this.storage.putTimed(timed);
        await this.storage.put(PUBLIC_SITE_KEY, bytes, "application/json");
        const inUse = new Set(Object.values(snapshot.assets).map((v) => v.key));
        const obsolete = records.filter((v) => !paths.has(v.path));
        let cleanupPending = obsolete.length;
        for (const record2 of obsolete) {
          if (this.clock() >= deadline) break;
          try {
            await this.store.run(async (tx) => {
              await this.lease(tx, owner);
              await tx.set("system", record2.id, { ...record2, status: "deleting" });
            });
            if (!inUse.has(record2.asset.key)) await this.storage.remove(record2.asset.key);
            await this.store.run(async (tx) => {
              await this.lease(tx, owner);
              await tx.remove("system", record2.id);
            });
            cleanupPending--;
          } catch {
            break;
          }
        }
        const settled = await this.store.run(async (tx) => {
          const current = await this.lease(tx, owner);
          const dirty = current.requested !== state.requested || pending > 0;
          await tx.set("system", stateKey2, {
            ...current,
            published: state.requested,
            dirty,
            pendingAssets: pending,
            cleanupPending,
            generatedAt: snapshot.generatedAt,
            owner: dirty ? owner : null,
            until: dirty ? current.until : 0
          });
          return !dirty;
        });
        if (settled) return "ready";
      }
      return "pending";
    } catch {
      console.error(JSON.stringify({ category: "public_sync", code: "PUBLIC_SYNC_FAILED" }));
      return "failed";
    } finally {
      await this.store.run(async (tx) => {
        const state = await tx.get("system", stateKey2);
        if (state?.owner === owner) await tx.set("system", stateKey2, { ...state, owner: null, until: 0 });
      });
    }
  }
  async build(deadline, owner) {
    const raw = (await this.store.list("public_site_export", {}, { offset: 0, limit: 1 })).items[0];
    const authors = (raw.authors ?? []).map((v) => {
      const author2 = pick(v, ["uid", "nickname", "avatar"]);
      if (!/^(https:\/\/|data:image\/(png|jpeg|webp);base64,)/.test(author2.avatar ?? "")) author2.avatar = "";
      return author2;
    });
    const author = (id) => authors.find((v) => v.uid === id) ?? { uid: id, nickname: "\u5DF2\u6CE8\u9500\u6210\u5458", avatar: "" };
    const boards = raw.boards.map((v) => pick(v, boardKeys));
    const posts = raw.posts.map((v) => {
      const post = pick(v, postKeys);
      return { ...post, author: author(post.authorUid), board: boards.find((b) => b.id === post.boardId) };
    });
    const comments = raw.comments.map((v) => {
      const comment = pick(v, commentKeys);
      return comment.status === "deleted" ? { ...comment, authorUid: "", body: "\u8BE5\u8BC4\u8BBA\u5DF2\u5220\u9664", author: { uid: "", nickname: "", avatar: "" } } : { ...comment, author: author(comment.authorUid), parent: v.parent ? pick(v.parent, ["id", "floor", "nickname"]) : null };
    });
    const snapshot = {
      format: "eclub-public-v1",
      revision: (0, import_node_crypto6.randomUUID)(),
      generatedAt: new Date(this.clock()).toISOString(),
      events: raw.events.map((v) => pick(v, [...contentKeys, "location", "startsAt", "endsAt", "registrationEnabled", "registrationStartsAt", "registrationDeadline", "capacity", "allowCancellation", "approvalRequired", "notesEnabled", "notesRequired", "checkinEnabled", "checkinOpen", "occupied"])),
      articles: raw.articles.map((v) => pick(v, [...contentKeys, "category", "pinned"])),
      popups: [],
      boards,
      posts,
      comments,
      assets: {},
      resources: raw.resources.map((v) => ({ ...resourceView(v), downloadUrl: this.resources.download(v) }))
    };
    let previousTimed = null;
    try {
      previousTimed = await this.storage.timed();
    } catch {
    }
    const popups = raw.popups.map((v) => pick(v, ["id", "version", "title", "summary", "image", "buttonText", "targetType", "targetId", "startsAt", "expiresAt", "priority", "enabled", "state", "createdAt", "updatedAt"]));
    const retired = previousTimed ? scheduledPopup(previousTimed, this.clock()).retired : [];
    const timed = { popups, retired: retired.filter((version) => popups.some((p) => popupVersion(p) === version)), assets: {} };
    for (const entry of raw.timedMedia ?? []) {
      if (this.clock() >= deadline - 1e4) throw Error("PUBLIC_TIMED_TIME_BUDGET");
      const path = "/api/media/" + entry.id;
      const old = previousTimed?.assets[path];
      if (old) {
        timed.assets[path] = { ...old, popupIds: entry.popupIds };
        continue;
      }
      const image2 = await this.store.run(async (tx) => {
        const record2 = await tx.get("media_images", entry.id);
        if (!record2 || record2.status !== "ready" || record2.bytes > 51200 || record2.chunkCount > 3 || !record2.bindings.some((b) => b.kind === "popup_announcements" && entry.popupIds.includes(b.id))) throw Error("PUBLIC_TIMED_IMAGE");
        const chunks = await Promise.all(Array.from({ length: record2.chunkCount }, (_, n) => tx.get("media_chunks", `${entry.id}:${n}`)));
        const bytes = Buffer.concat(chunks.map((v) => Buffer.from(v?.data ?? "", "base64")));
        if (bytes.length !== record2.bytes) throw Error("PUBLIC_TIMED_IMAGE_SIZE");
        const checked = inspectImage(`data:${record2.mime};base64,${bytes.toString("base64")}`, 51200);
        return { mime: checked.mime, base64: bytes.toString("base64"), popupIds: entry.popupIds };
      });
      timed.assets[path] = image2;
    }
    snapshot.hasTimedPopups = popups.length > 0;
    const records = raw.copiedAssets ?? [];
    const paths = /* @__PURE__ */ new Set([
      ...raw.mediaIds.map((id) => "/api/media/" + id),
      ...raw.forumImageIds.map((id) => "/api/forum/images/" + id)
    ]);
    if (paths.size > 640) throw Error("PUBLIC_ASSET_QUOTA");
    const missing2 = [];
    for (const path of paths) {
      const ready = records.find((v) => v.path === path && v.status === "ready");
      if (ready) snapshot.assets[path] = ready.asset;
      else missing2.push(path);
    }
    for (let start = 0; start < missing2.length && this.clock() < deadline - 1e4; start += 3) {
      await Promise.allSettled(missing2.slice(start, start + 3).map(async (path) => {
        const image2 = await this.readImage(path);
        if (!image2.binary || !["image/jpeg", "image/png", "image/webp"].includes(image2.contentType ?? "")) throw Error("PUBLIC_ASSET_MISSING");
        const inspected = inspectImage(`data:${image2.contentType};base64,${image2.binary.toString("base64")}`, 51200);
        const ext = inspected.mime === "image/jpeg" ? "jpg" : inspected.mime.slice("image/".length);
        const record2 = {
          id: "public-site:asset:" + path,
          path,
          status: "pending",
          asset: { key: `electronicclub/public-site/v1/assets/${(0, import_node_crypto6.createHash)("sha256").update(image2.binary).digest("hex")}.${ext}`, mime: inspected.mime, bytes: image2.binary.length }
        };
        await this.store.run(async (tx) => {
          await this.lease(tx, owner);
          await tx.set("system", record2.id, record2);
        });
        await this.storage.put(record2.asset.key, image2.binary, record2.asset.mime);
        record2.status = "ready";
        await this.store.run(async (tx) => {
          await this.lease(tx, owner);
          await tx.set("system", record2.id, record2);
        });
        snapshot.assets[path] = record2.asset;
      }));
    }
    if (Object.values(snapshot.assets).reduce((sum, v) => sum + v.bytes, 0) > 33554432) throw Error("PUBLIC_ASSET_BUDGET");
    snapshot.timedMediaIds = Object.keys(timed.assets).filter((path) => !snapshot.assets[path]).map((path) => path.split("/").pop());
    return { snapshot, records, paths, pending: paths.size - Object.keys(snapshot.assets).length, timed };
  }
};

// src/public-site-reader.ts
async function publicSiteResponse(storage, path, query, now = Date.now()) {
  try {
    const site = await storage.read();
    if (!site) throw Error("PUBLIC_SITE_NOT_PUBLISHED");
    if (site.hasTimedPopups && (path === "/api/public/popup" || !site.assets[path] && site.timedMediaIds?.includes(path.split("/").pop()))) {
      const timed = await storage.timed();
      if (!timed) throw Error("PUBLIC_TIMED_MISSING");
      timed.popups = timed.popups.filter((p) => (p.targetType === "event" ? site.events : site.articles).some((v) => v.id === p.targetId));
      const selected = scheduledPopup(timed, now).popup;
      if (path === "/api/public/popup") return { data: selected };
      if (!site.assets[path] && timed.assets[path]) {
        const image2 = timed.assets[path];
        if (!selected || !image2.popupIds.includes(selected.id)) throw new PublicSiteError(404, "NOT_FOUND", "\u56FE\u7247\u5C1A\u672A\u516C\u5F00\u6216\u4E0D\u5B58\u5728");
        return { binary: Buffer.from(image2.base64, "base64"), contentType: image2.mime };
      }
    }
    const result = readPublicSite(site, path, query, now);
    if (result.asset) return { binary: Buffer.from(await storage.asset(result.asset)), contentType: result.asset.mime };
    return { data: result.data };
  } catch (error) {
    if (error instanceof PublicSiteError) throw new ApiError(error.status, error.code, error.message);
    throw new ApiError(503, "PUBLIC_SITE_UNAVAILABLE", "\u516C\u5F00\u5185\u5BB9\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\uFF1B\u7BA1\u7406\u5458\u53EF\u68C0\u67E5\u516C\u5F00\u53D1\u5E03\u72B6\u6001");
  }
}

// src/media/service.ts
var import_node_crypto7 = require("node:crypto");
var import_zod4 = require("zod");

// src/forum/storage.ts
var IMAGE_STORAGE_KEY = "forum:image-storage";
async function changeImageStorage(tx, delta) {
  const budget = Number(process.env.FORUM_IMAGE_BUDGET_BYTES ?? 33554432);
  ensure(
    Number.isSafeInteger(budget) && budget >= 1024 && budget <= 536870912,
    503,
    "FORUM_STORAGE_CONFIG",
    "\u56FE\u7247\u5B58\u50A8\u9884\u7B97\u914D\u7F6E\u65E0\u6548"
  );
  const state = await tx.get(
    "system",
    IMAGE_STORAGE_KEY
  ) ?? { bytes: 0 };
  ensure(
    delta <= 0 || state.bytes + delta <= budget,
    409,
    "FORUM_STORAGE_BUDGET",
    "\u56FE\u7247\u7A7A\u95F4\u5DF2\u8FBE\u9884\u8BBE\u9884\u7B97\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u6574\u7406"
  );
  await tx.set("system", IMAGE_STORAGE_KEY, {
    bytes: Math.max(0, state.bytes + delta)
  });
}

// src/media/service.ts
var MediaService = class {
  constructor(store, secure, clock = () => Date.now()) {
    this.store = store;
    this.secure = secure;
    this.clock = clock;
  }
  async readable(tx, image2, ctx) {
    if (ctx?.member.uid === image2.ownerUid || ctx?.super) return true;
    for (const b of image2.bindings) {
      if (b.kind === "forum_posts") {
        const post = await tx.get("forum_posts", b.id);
        if (!post || post.status === "deleted") continue;
        const board = await tx.get("forum_boards", post.boardId);
        if (post.status === "published" && board && board.status !== "hidden")
          return true;
        if (ctx && (post.authorUid === ctx.member.uid || ctx.permissions.some(
          (p) => ["forum.posts.review", "forum.posts.delete"].includes(p)
        )))
          return true;
      } else if (b.kind === "events") {
        const event = await tx.get("events", b.id);
        if (event?.status === "published") return true;
        if (event && event.status !== "deleted" && ctx && (event.managerIds.includes(ctx.member.uid) || ctx.permissions.some(
          (p) => [
            "events.edit",
            "events.delete",
            "events.registrations.read",
            "events.registrations.review",
            "events.registrations.export",
            "events.checkin.manage"
          ].includes(p)
        )))
          return true;
      } else if (b.kind === "articles") {
        const article = await tx.get("articles", b.id);
        if (article?.status === "published") return true;
        if (article && article.status !== "deleted" && ctx && (article.publisherUid === ctx.member.uid || ctx.permissions.some(
          (p) => ["articles.edit", "articles.publish", "articles.delete"].includes(
            p
          )
        )))
          return true;
      } else {
        const popup = await tx.get(
          "popup_announcements",
          b.id
        );
        if (!popup?.enabled || popup.state === "retired" || popup.state === "disabled" || popup.startsAt > new Date(this.clock()).toISOString() || popup.expiresAt <= new Date(this.clock()).toISOString())
          continue;
        const parent = await tx.get(
          popup.targetType === "event" ? "events" : "articles",
          popup.targetId
        );
        if (parent?.status === "published") return true;
      }
    }
    return false;
  }
  async execute(token, method, path, input) {
    const m = path.match(
      /^\/api\/media(?:\/([0-9a-f-]{36})(?:\/(complete|delete|chunks\/([0-2])))?)?$/
    );
    ensure(m, 404, "NOT_FOUND", "\u56FE\u7247\u63A5\u53E3\u4E0D\u5B58\u5728");
    const [, id, action, index] = m;
    const work = async (tx, ctx) => {
      if (method === "POST" && !id) {
        ensure(ctx, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
        const restriction = await tx.get("forum_user_restrictions", ctx.member.uid);
        const restricted = restriction?.posts && (!restriction.postsUntil || Date.parse(restriction.postsUntil) > this.clock());
        ensure(
          !restricted || ctx.super || ctx.permissions.some(
            (p) => [
              "events.create",
              "events.edit",
              "articles.create",
              "articles.edit",
              "announcements.popup.manage"
            ].includes(p)
          ),
          403,
          "FORUM_RESTRICTED",
          "\u5F53\u524D\u8D26\u53F7\u5DF2\u88AB\u9650\u5236\u53D1\u5E03\u56FE\u7247"
        );
        const body = import_zod4.z.object({
          mime: import_zod4.z.enum(["image/png", "image/jpeg", "image/webp"]),
          bytes: import_zod4.z.number().int().min(20).max(MAX_MEDIA_IMAGE_BYTES)
        }).strict().parse(input);
        const key2 = "media:uploads:" + ctx.member.uid;
        let state = await tx.get("system", key2) ?? { start: this.clock(), count: 0, pending: [] };
        if (state.start + 6e5 <= this.clock())
          state = { ...state, start: this.clock(), count: 0 };
        const pending = await Promise.all(
          state.pending.map((i) => tx.get("media_images", i))
        );
        state.pending = pending.filter((i) => i && !i.bindings.length).map((i) => i.id);
        ensure(
          state.count < 24 && state.pending.length < 16,
          429,
          "MEDIA_RATE_LIMIT",
          "\u672A\u53D1\u5E03\u56FE\u7247\u8FC7\u591A\u6216\u4E0A\u4F20\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u5148\u4FDD\u5B58\u5185\u5BB9\u6216\u79FB\u9664\u672A\u4F7F\u7528\u7684\u56FE\u7247"
        );
        const image3 = {
          id: (0, import_node_crypto7.randomUUID)(),
          ownerUid: ctx.member.uid,
          ...body,
          chunkCount: Math.ceil(body.bytes / MEDIA_CHUNK_BYTES),
          status: "uploading",
          bindings: [],
          createdAt: new Date(this.clock()).toISOString()
        };
        await changeImageStorage(tx, Math.ceil(image3.bytes / 3) * 4);
        await tx.set("media_images", image3.id, image3);
        await tx.set("system", key2, {
          ...state,
          count: state.count + 1,
          pending: [...state.pending, image3.id]
        });
        return { data: { id: image3.id, chunkCount: image3.chunkCount } };
      }
      const image2 = id ? await tx.get("media_images", id) : null;
      ensure(image2, 404, "NOT_FOUND", "\u56FE\u7247\u4E0D\u5B58\u5728");
      if (method === "GET" && !action) {
        ensure(
          image2.status === "ready" && await this.readable(tx, image2, ctx),
          404,
          "NOT_FOUND",
          "\u56FE\u7247\u5C1A\u672A\u516C\u5F00\u6216\u4E0D\u5B58\u5728"
        );
        const data = await this.bytes(tx, image2);
        return { binary: data, contentType: image2.mime };
      }
      ensure(
        ctx && image2.ownerUid === ctx.member.uid,
        403,
        "MEDIA_OWNER",
        "\u53EA\u80FD\u64CD\u4F5C\u672C\u4EBA\u4E0A\u4F20\u7684\u56FE\u7247"
      );
      if (method === "POST" && action?.startsWith("chunks/")) {
        ensure(
          image2.status === "uploading",
          409,
          "MEDIA_COMPLETE",
          "\u56FE\u7247\u5DF2\u5B8C\u6210\u4E0A\u4F20"
        );
        const n = Number(index);
        ensure(n < image2.chunkCount, 400, "INVALID_CHUNK", "\u56FE\u7247\u5206\u7247\u7F16\u53F7\u65E0\u6548");
        const { data } = import_zod4.z.object({ data: import_zod4.z.string().min(1).max(32768) }).strict().parse(input);
        const chunk = Buffer.from(data, "base64"), expected = Math.min(
          MEDIA_CHUNK_BYTES,
          image2.bytes - n * MEDIA_CHUNK_BYTES
        );
        ensure(
          chunk.toString("base64") === data && chunk.length === expected,
          400,
          "INVALID_CHUNK",
          "\u56FE\u7247\u5206\u7247\u5927\u5C0F\u6216\u683C\u5F0F\u65E0\u6548"
        );
        await tx.set("media_chunks", `${image2.id}:${n}`, {
          id: `${image2.id}:${n}`,
          imageId: image2.id,
          index: n,
          data
        });
        return { data: { ok: true } };
      }
      if (method === "POST" && action === "complete") {
        import_zod4.z.object({}).strict().parse(input);
        const bytes = await this.bytes(tx, image2);
        const inspected = inspectImage(
          `data:${image2.mime};base64,${bytes.toString("base64")}`,
          MAX_MEDIA_IMAGE_BYTES
        );
        await tx.set("media_images", image2.id, {
          ...image2,
          status: "ready",
          width: inspected.width,
          height: inspected.height
        });
        return {
          data: {
            id: image2.id,
            bytes: image2.bytes,
            width: inspected.width,
            height: inspected.height
          }
        };
      }
      if (method === "POST" && action === "delete") {
        import_zod4.z.object({}).strict().parse(input);
        ensure(
          !image2.bindings.length,
          409,
          "MEDIA_IN_USE",
          "\u56FE\u7247\u4ECD\u88AB\u6B63\u6587\u6216\u5C01\u9762\u4F7F\u7528\uFF0C\u8BF7\u5148\u5728\u7F16\u8F91\u5668\u4E2D\u79FB\u9664\u5E76\u4FDD\u5B58"
        );
        await removeMedia(tx, image2);
        return { data: { ok: true } };
      }
      throw new ApiError(404, "NOT_FOUND", "\u56FE\u7247\u63A5\u53E3\u4E0D\u5B58\u5728");
    };
    if (method === "GET") {
      try {
        return await this.store.run((tx) => work(tx));
      } catch (error) {
        if (!(error instanceof ApiError && error.status === 404) || !token)
          throw error;
      }
      try {
        return await this.secure(token, work);
      } catch (error) {
        if (error instanceof ApiError && error.status === 401)
          throw new ApiError(404, "NOT_FOUND", "\u56FE\u7247\u5C1A\u672A\u516C\u5F00\u6216\u4E0D\u5B58\u5728");
        throw error;
      }
    }
    return this.secure(token, (tx, ctx) => work(tx, ctx));
  }
  async bytes(tx, image2) {
    const chunks = await Promise.all(
      Array.from(
        { length: image2.chunkCount },
        (_, n) => tx.get("media_chunks", `${image2.id}:${n}`)
      )
    );
    ensure(
      chunks.every(Boolean),
      409,
      "MEDIA_INCOMPLETE",
      "\u56FE\u7247\u672A\u4E0A\u4F20\u5B8C\u6574\uFF0C\u8BF7\u91CD\u8BD5"
    );
    const bytes = Buffer.concat(
      chunks.map((c) => Buffer.from(c.data, "base64"))
    );
    ensure(
      bytes.length === image2.bytes,
      409,
      "MEDIA_INCOMPLETE",
      "\u56FE\u7247\u5927\u5C0F\u4E0D\u4E00\u81F4"
    );
    return bytes;
  }
};
async function removeMedia(tx, image2) {
  for (let n = 0; n < image2.chunkCount; n++)
    await tx.remove("media_chunks", `${image2.id}:${n}`);
  await tx.remove("media_images", image2.id);
  await changeImageStorage(tx, -Math.ceil(image2.bytes / 3) * 4);
}

// src/media/model.ts
function references(body = "", cover = "") {
  ensure(
    bodyMedia(body).length <= MAX_BODY_IMAGES,
    400,
    "IMAGE_LIMIT",
    "\u6BCF\u7BC7\u6B63\u6587\u6700\u591A12\u5F20\u56FE\u7247"
  );
  return [
    .../* @__PURE__ */ new Set([
      ...bodyMedia(body),
      ...mediaReference(cover) ? [mediaReference(cover)] : []
    ])
  ];
}
async function syncMedia(tx, ctx, kind, id, next, previous = [], trustedImages = []) {
  ensure(
    next.length <= MAX_BODY_IMAGES + 1,
    400,
    "IMAGE_LIMIT",
    "\u6BCF\u7BC7\u6B63\u6587\u6700\u591A12\u5F20\u56FE\u7247\uFF0C\u53E6\u53EF\u8BBE\u7F6E1\u5F20\u5C01\u9762"
  );
  for (const imageId of /* @__PURE__ */ new Set([...next, ...previous])) {
    const image2 = await tx.get("media_images", imageId);
    if (!next.includes(imageId)) {
      if (image2) {
        image2.bindings = image2.bindings.filter(
          (b) => b.kind !== kind || b.id !== id
        );
        await tx.set("media_images", imageId, image2);
      }
      continue;
    }
    ensure(
      image2?.status === "ready",
      400,
      "INVALID_MEDIA",
      "\u56FE\u7247\u672A\u4E0A\u4F20\u5B8C\u6210\u6216\u4E0D\u5B58\u5728\uFF0C\u8BF7\u91CD\u65B0\u63D2\u5165\u56FE\u7247"
    );
    const existing = image2.bindings.some((b) => b.kind === kind && b.id === id);
    ensure(
      existing || image2.ownerUid === ctx.member.uid || trustedImages.includes(imageId),
      403,
      "MEDIA_OWNER",
      "\u4E0D\u80FD\u4F7F\u7528\u5176\u4ED6\u6210\u5458\u5C1A\u672A\u6388\u6743\u7684\u56FE\u7247"
    );
    if (!existing) {
      ensure(
        image2.bindings.length < 20,
        409,
        "MEDIA_LINK_LIMIT",
        "\u56FE\u7247\u5DF2\u88AB\u8FC7\u591A\u5185\u5BB9\u5F15\u7528\uFF0C\u8BF7\u91CD\u65B0\u4E0A\u4F20"
      );
      image2.bindings.push({ kind, id });
      await tx.set("media_images", imageId, image2);
    }
  }
}

// src/forum/service.ts
var import_node_crypto9 = require("node:crypto");
var import_zod6 = require("zod");

// src/members/crypto.ts
var import_node_crypto8 = require("node:crypto");
var digest = (value) => (0, import_node_crypto8.createHash)("sha256").update(value).digest("hex");
var randomToken = () => (0, import_node_crypto8.randomBytes)(32).toString("base64url");
async function hashPassword(password) {
  const salt = (0, import_node_crypto8.randomBytes)(16).toString("hex");
  const key2 = await derive(password, salt);
  return `scrypt$${salt}$${key2.toString("hex")}`;
}
function derive(password, salt) {
  return new Promise(
    (resolve, reject) => (0, import_node_crypto8.scrypt)(
      password,
      salt,
      64,
      { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 },
      (err, key2) => err ? reject(err) : resolve(key2)
    )
  );
}
async function verifyPassword(password, hash) {
  const parts = hash.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") {
    await derive(password, "invalid-credential-padding");
    return false;
  }
  const key2 = await derive(password, parts[1]);
  const expected = Buffer.from(parts[2], "hex");
  return key2.length === expected.length && (0, import_node_crypto8.timingSafeEqual)(key2, expected);
}
var studentIdKey = (studentId) => digest(normalizeStudentId(studentId));

// src/forum/model.ts
var import_zod5 = require("zod");
var boardInput = import_zod5.z.object({
  name: import_zod5.z.string().trim().min(1).max(40),
  description: import_zod5.z.string().trim().max(300).default(""),
  position: import_zod5.z.number().int().min(0).max(1e3).default(0),
  status: import_zod5.z.enum(["active", "hidden", "disabled"]).default("active"),
  requireReview: import_zod5.z.boolean().default(false)
}).strict();
var postInput = import_zod5.z.object({
  title: import_zod5.z.string().trim().min(2).max(120),
  body: import_zod5.z.string().trim().min(2).max(6e3),
  boardId: import_zod5.z.string().min(1).max(60),
  imageIds: import_zod5.z.array(import_zod5.z.string().uuid()).max(3).default([])
}).strict();
var commentInput = import_zod5.z.object({
  body: import_zod5.z.string().trim().min(1).max(1500),
  parentId: import_zod5.z.string().uuid().nullable().default(null)
}).strict();
var moderationInput = import_zod5.z.object({
  action: import_zod5.z.enum([
    "approve",
    "hide",
    "delete",
    "pin",
    "feature",
    "lock",
    "close-comments"
  ]),
  value: import_zod5.z.boolean().default(true),
  reason: import_zod5.z.string().trim().min(1).max(300)
}).strict();
var reasonInput = import_zod5.z.object({ reason: import_zod5.z.string().trim().min(2).max(500) }).strict();
var restrictionInput = import_zod5.z.object({
  studentId: import_zod5.z.string().min(4).max(24),
  posts: import_zod5.z.boolean(),
  comments: import_zod5.z.boolean(),
  postsUntil: import_zod5.z.string().datetime({ offset: true }).nullable(),
  commentsUntil: import_zod5.z.string().datetime({ offset: true }).nullable(),
  reason: import_zod5.z.string().trim().min(2).max(300)
}).strict();
var imageInput = import_zod5.z.object({ dataUrl: import_zod5.z.string().max(45e3) }).strict();

// src/forum/service.ts
var postModeration = [
  "forum.posts.review",
  "forum.posts.pin",
  "forum.posts.feature",
  "forum.posts.lock",
  "forum.posts.delete"
];
var ForumService = class {
  constructor(store, secure, clock = () => Date.now()) {
    this.store = store;
    this.secure = secure;
    this.clock = clock;
  }
  now() {
    return new Date(this.clock()).toISOString();
  }
  can(ctx, p) {
    return !!ctx && (ctx.super || ctx.permissions.includes(p));
  }
  require(ctx, p) {
    ensure(this.can(ctx, p), 403, "FORBIDDEN", "\u6CA1\u6709\u6B64\u793E\u533A\u7BA1\u7406\u6743\u9650");
  }
  member(ctx) {
    ensure(ctx, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
    return ctx;
  }
  async audit(tx, ctx, action, target, details = {}) {
    const id = (0, import_node_crypto9.randomUUID)();
    await tx.set("audit_logs", id, {
      id,
      actor: ctx.member.uid,
      action,
      target,
      details,
      fields: [],
      createdAt: this.now()
    });
  }
  async notify(tx, uid, postId, message, commentId = null) {
    const id = (0, import_node_crypto9.randomUUID)();
    await tx.set("forum_notifications", id, {
      id,
      recipientUid: uid,
      postId,
      commentId,
      message,
      read: false,
      createdAt: this.now()
    });
  }
  async rate(tx, ctx, kind, limit, windowMs) {
    const id = `forum:rate:${ctx.member.uid}:${kind}`;
    let state = await tx.get("system", id);
    if (!state || state.start + windowMs <= this.clock())
      state = { count: 0, start: this.clock() };
    ensure(
      state.count < limit,
      429,
      "FORUM_RATE_LIMIT",
      "\u64CD\u4F5C\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5"
    );
    state.count++;
    await tx.set("system", id, state);
  }
  async allowed(tx, ctx, kind) {
    const r = await tx.get(
      "forum_user_restrictions",
      ctx.member.uid
    );
    const end = kind === "posts" ? r?.postsUntil : r?.commentsUntil;
    ensure(
      !r || !r[kind] || !!end && Date.parse(end) <= this.clock(),
      403,
      "FORUM_RESTRICTED",
      "\u8D26\u53F7\u6682\u65F6\u88AB\u9650\u5236\u6B64\u793E\u533A\u64CD\u4F5C"
    );
  }
  async board(tx, id) {
    const b = await tx.get("forum_boards", id);
    ensure(b, 404, "NOT_FOUND", "\u7248\u5757\u4E0D\u5B58\u5728");
    return { ...b, id };
  }
  async post(tx, id, ctx) {
    const p = await tx.get("forum_posts", id);
    ensure(p && p.status !== "deleted", 404, "NOT_FOUND", "\u5E16\u5B50\u4E0D\u5B58\u5728\u6216\u5DF2\u5220\u9664");
    const board = await this.board(tx, p.boardId);
    const moderation = this.can(ctx, "forum.posts.review") || this.can(ctx, "forum.posts.delete");
    ensure(
      p.status === "published" && board.status !== "hidden" || ctx?.member.uid === p.authorUid || moderation,
      404,
      "NOT_FOUND",
      "\u5E16\u5B50\u4E0D\u5B58\u5728\u6216\u5C1A\u672A\u516C\u5F00"
    );
    return { ...p, id };
  }
  async author(tx, uid) {
    const user = await tx.get("users", uid);
    return {
      uid,
      nickname: user && user.status !== "deleted" ? user.nickname : "\u5DF2\u6CE8\u9500\u6210\u5458",
      avatar: user && user.status === "active" && /^(https:\/\/|data:image\/(png|jpeg|webp);base64,)/.test(user.avatar) ? user.avatar : ""
    };
  }
  async postView(tx, p, ctx) {
    const { moderationReason, ...publicFields } = p;
    return {
      ...publicFields,
      ...ctx?.member.uid === p.authorUid || this.can(ctx, "forum.posts.review") ? { moderationReason } : {},
      author: await this.author(tx, p.authorUid),
      board: await this.board(tx, p.boardId)
    };
  }
  async publicPosts(tx, items, ctx) {
    const values = await Promise.all(
      items.map(async (row) => {
        const current = await tx.get("forum_posts", row.id);
        if (!current || current.status !== "published") return null;
        const board = await this.board(tx, current.boardId);
        if (board.status === "hidden") return null;
        const view = await this.postView(tx, { ...current, id: row.id }, ctx);
        return { ...view, body: view.body.slice(0, 240) };
      })
    );
    return values.filter((value) => value !== null);
  }
  async commentView(tx, c, moderation = false) {
    if (c.status === "deleted" || c.status === "hidden" && !moderation)
      return {
        ...c,
        body: c.status === "deleted" ? "\u8BE5\u8BC4\u8BBA\u5DF2\u5220\u9664" : "\u8BE5\u8BC4\u8BBA\u6682\u4E0D\u53EF\u89C1",
        author: { uid: "", nickname: "", avatar: "" }
      };
    const parent = c.parentId ? await tx.get("forum_comments", c.parentId) : null;
    return {
      ...c,
      author: await this.author(tx, c.authorUid),
      parent: parent ? {
        id: parent.id,
        floor: parent.floor,
        nickname: parent.status === "published" ? (await this.author(tx, parent.authorUid)).nickname : "\u5DF2\u5220\u9664\u6216\u9690\u85CF"
      } : null
    };
  }
  async page(collection, filter, q) {
    const page2 = import_zod6.z.coerce.number().int().min(1).max(1e4).parse(q.page ?? 1), pageSize = import_zod6.z.coerce.number().int().min(1).max(30).parse(q.pageSize ?? 20);
    return {
      ...await this.store.list(collection, filter, {
        offset: (page2 - 1) * pageSize,
        limit: pageSize
      }),
      page: page2,
      pageSize
    };
  }
  async attach(tx, ctx, postId, ids) {
    ensure(
      new Set(ids).size === ids.length,
      400,
      "DUPLICATE_IMAGE",
      "\u56FE\u7247\u4E0D\u80FD\u91CD\u590D"
    );
    for (const id of ids) {
      const image2 = await tx.get("forum_images", id);
      ensure(
        image2 && image2.ownerUid === ctx.member.uid && (!image2.postId || image2.postId === postId),
        403,
        "IMAGE_SCOPE",
        "\u56FE\u7247\u4E0D\u5C5E\u4E8E\u5F53\u524D\u6210\u5458\u6216\u5DF2\u7528\u4E8E\u5176\u4ED6\u5E16\u5B50"
      );
      await tx.set("forum_images", id, { ...image2, postId, status: "attached" });
    }
  }
  async execute(token, method, path, input, q) {
    const parts = path.slice("/api/forum".length).split("/").filter(Boolean), [kind, id, action] = parts;
    const publicRead = method === "GET" && ["boards", "posts", "images"].includes(kind ?? "") && q.admin !== "true";
    const work = async (tx, ctx) => {
      if (kind === "boards") {
        if (method === "GET") {
          if (q.admin === "true") this.require(ctx, "forum.boards.manage");
          if (id) {
            const board2 = await this.board(tx, id);
            ensure(
              board2.status !== "hidden" || this.can(ctx, "forum.boards.manage"),
              404,
              "NOT_FOUND",
              "\u7248\u5757\u4E0D\u5B58\u5728"
            );
            return { data: board2 };
          }
          return {
            data: await this.page(
              "forum_boards",
              q.admin === "true" ? {} : { _public: true },
              q
            )
          };
        }
        ensure(method === "POST", 404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
        this.require(ctx, "forum.boards.manage");
        const data = boardInput.parse(input), now = this.now(), previous = id ? await this.board(tx, id) : null;
        const board = {
          ...data,
          id: id ?? (0, import_node_crypto9.randomUUID)(),
          createdAt: previous?.createdAt ?? now,
          updatedAt: now
        };
        await tx.set("forum_boards", board.id, board);
        await this.audit(tx, ctx, "forum.boards.save", board.id, {
          status: board.status,
          requireReview: board.requireReview
        });
        return { data: board };
      }
      if (kind === "images") {
        if (method === "POST" && !id) {
          const user = this.member(ctx);
          await this.allowed(tx, user, "posts");
          await this.rate(tx, user, "images", 6, 6e5);
          const pending = await this.store.list(
            "forum_images",
            { ownerUid: user.member.uid, status: "staged" },
            { offset: 0, limit: 1 }
          );
          ensure(
            pending.total < 6,
            409,
            "IMAGE_QUOTA",
            "\u672A\u4F7F\u7528\u56FE\u7247\u8FC7\u591A\uFF0C\u8BF7\u5148\u53D1\u5E03\u5E16\u5B50\u6216\u79FB\u9664\u672A\u4F7F\u7528\u56FE\u7247"
          );
          const data = imageInput.parse(input), image3 = inspectImage(data.dataUrl);
          const record2 = {
            id: (0, import_node_crypto9.randomUUID)(),
            ownerUid: user.member.uid,
            postId: null,
            dataUrl: data.dataUrl,
            mime: image3.mime,
            width: image3.width,
            height: image3.height,
            bytes: image3.bytes,
            status: "staged",
            createdAt: this.now()
          };
          await changeImageStorage(tx, record2.dataUrl.length);
          await tx.set("forum_images", record2.id, record2);
          return {
            data: {
              id: record2.id,
              width: record2.width,
              height: record2.height,
              bytes: record2.bytes
            }
          };
        }
        if (method === "POST" && id && action === "delete") {
          const user = this.member(ctx), image3 = await tx.get("forum_images", id);
          ensure(
            image3 && image3.ownerUid === user.member.uid && image3.status === "staged",
            403,
            "IMAGE_SCOPE",
            "\u53EA\u80FD\u79FB\u9664\u672C\u4EBA\u672A\u53D1\u5E03\u7684\u56FE\u7247"
          );
          await tx.remove("forum_images", id);
          await changeImageStorage(tx, -image3.dataUrl.length);
          return { data: { ok: true } };
        }
        ensure(method === "GET" && id, 404, "NOT_FOUND", "\u56FE\u7247\u4E0D\u5B58\u5728");
        const image2 = await tx.get("forum_images", id);
        ensure(image2, 404, "NOT_FOUND", "\u56FE\u7247\u4E0D\u5B58\u5728");
        if (image2.postId) {
          const post = await this.post(tx, image2.postId, ctx);
          ensure(
            post.imageIds.includes(id),
            404,
            "NOT_FOUND",
            "\u56FE\u7247\u5DF2\u4ECE\u5E16\u5B50\u79FB\u9664"
          );
        } else
          ensure(
            ctx?.member.uid === image2.ownerUid,
            404,
            "NOT_FOUND",
            "\u56FE\u7247\u5C1A\u672A\u53D1\u5E03"
          );
        ensure(
          ["image/jpeg", "image/png", "image/webp"].includes(image2.mime),
          404,
          "NOT_FOUND",
          "\u56FE\u7247\u4E0D\u5B58\u5728"
        );
        const buffer = Buffer.from(image2.dataUrl.split(",")[1] ?? "", "base64");
        ensure(
          buffer.length <= 32768 && buffer.length === image2.bytes,
          404,
          "NOT_FOUND",
          "\u56FE\u7247\u6570\u636E\u4E0D\u5B8C\u6574"
        );
        return { binary: buffer, contentType: image2.mime };
      }
      if (kind === "posts" && !id && method === "GET") {
        const filter = { _public: true };
        if (q.boardId) filter.boardId = import_zod6.z.string().max(60).parse(q.boardId);
        if (q.search) filter._search = import_zod6.z.string().max(80).parse(q.search);
        const sort = import_zod6.z.enum(["latest", "reply", "hot", "featured"]).parse(q.sort ?? "latest");
        filter._sort = sort;
        if (sort === "featured") filter._featured = true;
        const result = await this.page("forum_posts", filter, q);
        return {
          data: {
            ...result,
            items: await this.publicPosts(tx, result.items, ctx)
          }
        };
      }
      if (kind === "posts" && !id && method === "POST") {
        const user = this.member(ctx);
        await this.allowed(tx, user, "posts");
        await this.rate(tx, user, "post-cooldown", 1, 3e4);
        await this.rate(tx, user, "post-hour", 10, 36e5);
        const data = postInput.parse(input), board = await this.board(tx, data.boardId);
        ensure(
          board.status === "active",
          409,
          "BOARD_DISABLED",
          "\u6B64\u7248\u5757\u6682\u4E0D\u63A5\u53D7\u65B0\u5E16"
        );
        const now = this.now();
        const p = {
          ...data,
          id: (0, import_node_crypto9.randomUUID)(),
          authorUid: user.member.uid,
          status: board.requireReview ? "pending" : "published",
          pinned: false,
          featured: false,
          locked: false,
          commentsClosed: false,
          viewCount: 0,
          likeCount: 0,
          commentCount: 0,
          commentSequence: 0,
          lastReplyAt: now,
          createdAt: now,
          updatedAt: now
        };
        await syncMedia(tx, user, "forum_posts", p.id, references(p.body));
        await tx.set("forum_posts", p.id, p);
        await this.attach(tx, user, p.id, p.imageIds);
        await this.audit(tx, user, "forum.posts.create", p.id);
        return { data: await this.postView(tx, p, user) };
      }
      if (kind === "posts" && id) {
        const post = await this.post(tx, id, ctx);
        if (method === "GET" && !action)
          return { data: await this.postView(tx, post, ctx) };
        if (action === "comments" && method === "GET") {
          if (q.anchor) {
            const anchor = await tx.get(
              "forum_comments",
              q.anchor
            );
            ensure(
              anchor && anchor.postId === id && ["published", "deleted"].includes(anchor.status),
              404,
              "NOT_FOUND",
              "\u56DE\u590D\u5DF2\u9690\u85CF\u6216\u4E0D\u5B58\u5728"
            );
            const before = await this.store.list(
              "forum_comments",
              { postId: id, _public: true, _beforeFloor: String(anchor.floor) },
              { offset: 0, limit: 1 }
            );
            q = {
              ...q,
              page: String(1 + Math.floor(before.total / 20)),
              pageSize: "20"
            };
          }
          const result = await this.page(
            "forum_comments",
            {
              postId: id,
              ...post.status === "published" ? { _public: true } : { status: "published" }
            },
            q
          );
          return {
            data: {
              ...result,
              items: (await Promise.all(
                result.items.map(async (c) => {
                  const current = await tx.get(
                    "forum_comments",
                    c.id
                  );
                  return current && ["published", "deleted"].includes(current.status) ? this.commentView(tx, { ...current, id: c.id }) : null;
                })
              )).filter((value) => value !== null)
            }
          };
        }
        const user = this.member(ctx);
        if (action === "state" && method === "GET") {
          return {
            data: {
              liked: !!await tx.get(
                "forum_likes",
                `${id}:${user.member.uid}`
              ),
              favorited: !!await tx.get(
                "forum_favorites",
                `${id}:${user.member.uid}`
              ),
              own: post.authorUid === user.member.uid
            }
          };
        }
        if (action === "view" && method === "POST") {
          const key2 = `forum:view:${id}:${user.member.uid}`, last = await tx.get("system", key2);
          if (!last || last.at + 864e5 <= this.clock()) {
            post.viewCount++;
            await tx.set("system", key2, { at: this.clock() });
            await tx.set("forum_posts", id, post);
          }
          return { data: { viewCount: post.viewCount } };
        }
        if (action === "update" && method === "POST") {
          ensure(
            post.authorUid === user.member.uid,
            403,
            "FORBIDDEN",
            "\u53EA\u80FD\u7F16\u8F91\u672C\u4EBA\u5E16\u5B50"
          );
          ensure(!post.locked, 409, "POST_LOCKED", "\u5E16\u5B50\u5DF2\u9501\u5B9A");
          await this.allowed(tx, user, "posts");
          await this.rate(tx, user, "post-edit", 5, 6e4);
          const data = postInput.parse(input), board = await this.board(tx, data.boardId);
          ensure(board.status === "active", 409, "BOARD_DISABLED", "\u7248\u5757\u5DF2\u505C\u7528");
          await this.attach(tx, user, id, data.imageIds);
          const next = {
            ...post,
            ...data,
            status: board.requireReview || post.status === "hidden" || post.status === "pending" ? "pending" : "published",
            updatedAt: this.now()
          };
          await syncMedia(tx, user, "forum_posts", id, references(next.body), references(post.body));
          await tx.set("forum_posts", id, next);
          for (const removed of post.imageIds.filter(
            (v) => !data.imageIds.includes(v)
          )) {
            const old = await tx.get("forum_images", removed);
            if (old) {
              await tx.remove("forum_images", removed);
              await changeImageStorage(tx, -old.dataUrl.length);
            }
          }
          await this.audit(tx, user, "forum.posts.edit", id);
          return { data: await this.postView(tx, next, user) };
        }
        if (action === "delete" && method === "POST") {
          ensure(
            post.authorUid === user.member.uid,
            403,
            "FORBIDDEN",
            "\u53EA\u80FD\u5220\u9664\u672C\u4EBA\u5E16\u5B50"
          );
          await tx.set("forum_posts", id, {
            ...post,
            status: "deleted",
            updatedAt: this.now()
          });
          await this.audit(tx, user, "forum.posts.delete-own", id);
          return { data: { ok: true } };
        }
        if (action === "comments" && method === "POST") {
          ensure(
            post.status === "published" && !post.locked && !post.commentsClosed,
            409,
            "COMMENTS_CLOSED",
            "\u5E16\u5B50\u672A\u516C\u5F00\u3001\u5DF2\u9501\u5B9A\u6216\u5DF2\u5173\u95ED\u8BC4\u8BBA"
          );
          const board = await this.board(tx, post.boardId);
          ensure(
            board.status === "active",
            409,
            "BOARD_DISABLED",
            "\u7248\u5757\u6682\u4E0D\u63A5\u53D7\u8BC4\u8BBA"
          );
          await this.allowed(tx, user, "comments");
          await this.rate(tx, user, "comment-cooldown", 1, 5e3);
          await this.rate(tx, user, "comment-hour", 60, 36e5);
          const data = commentInput.parse(input), parent = data.parentId ? await tx.get("forum_comments", data.parentId) : null;
          if (data.parentId)
            ensure(
              parent && parent.postId === id && parent.status === "published",
              400,
              "INVALID_PARENT",
              "\u56DE\u590D\u76EE\u6807\u4E0D\u5C5E\u4E8E\u6B64\u5E16\u6216\u5DF2\u5220\u9664"
            );
          post.commentSequence++;
          post.commentCount++;
          post.lastReplyAt = this.now();
          const comment = {
            ...data,
            id: (0, import_node_crypto9.randomUUID)(),
            postId: id,
            authorUid: user.member.uid,
            status: "published",
            floor: post.commentSequence,
            createdAt: this.now(),
            updatedAt: this.now()
          };
          await tx.set("forum_posts", id, post);
          await tx.set("forum_comments", comment.id, comment);
          const recipients = /* @__PURE__ */ new Set([post.authorUid, parent?.authorUid]);
          for (const uid of recipients)
            if (uid && uid !== user.member.uid)
              await this.notify(
                tx,
                uid,
                id,
                parent?.authorUid === uid ? "\u6709\u4EBA\u56DE\u590D\u4E86\u4F60\u7684\u8BC4\u8BBA" : "\u6709\u4EBA\u56DE\u590D\u4E86\u4F60\u7684\u5E16\u5B50",
                comment.id
              );
          await this.audit(tx, user, "forum.comments.create", comment.id);
          return { data: await this.commentView(tx, comment) };
        }
        if (["like", "favorite"].includes(action ?? "") && method === "POST") {
          ensure(
            post.status === "published",
            409,
            "POST_NOT_PUBLIC",
            "\u5E16\u5B50\u5C1A\u672A\u516C\u5F00"
          );
          await this.rate(tx, user, "reactions", 30, 6e4);
          const data = import_zod6.z.object({ active: import_zod6.z.boolean() }).strict().parse(input), collection = action === "like" ? "forum_likes" : "forum_favorites", key2 = `${id}:${user.member.uid}`, exists = await tx.get(collection, key2);
          if (data.active && !exists) {
            await tx.set(collection, key2, {
              id: key2,
              postId: id,
              uid: user.member.uid,
              createdAt: this.now()
            });
            if (action === "like") post.likeCount++;
          }
          if (!data.active && exists) {
            await tx.remove(collection, key2);
            if (action === "like")
              post.likeCount = Math.max(0, post.likeCount - 1);
          }
          if (action === "like") await tx.set("forum_posts", id, post);
          return { data: { active: data.active, likeCount: post.likeCount } };
        }
        if (action === "moderate" && method === "POST") {
          const data = moderationInput.parse(input), permission = {
            approve: "forum.posts.review",
            hide: "forum.posts.review",
            delete: "forum.posts.delete",
            pin: "forum.posts.pin",
            feature: "forum.posts.feature",
            lock: "forum.posts.lock",
            "close-comments": "forum.posts.lock"
          }[data.action];
          this.require(user, permission);
          if (data.action === "approve") post.status = "published";
          if (data.action === "hide")
            post.status = data.value ? "hidden" : "published";
          if (data.action === "delete") post.status = "deleted";
          if (data.action === "pin") post.pinned = data.value;
          if (data.action === "feature") post.featured = data.value;
          if (data.action === "lock") post.locked = data.value;
          if (data.action === "close-comments") post.commentsClosed = data.value;
          post.moderationReason = data.reason;
          post.updatedAt = this.now();
          await tx.set("forum_posts", id, post);
          await this.audit(tx, user, "forum.posts." + data.action, id, {
            reason: data.reason,
            value: data.value
          });
          await this.notify(
            tx,
            post.authorUid,
            id,
            "\u4F60\u7684\u5E16\u5B50\u5DF2\u88AB\u7BA1\u7406\u5458\u5904\u7406\uFF1A" + data.reason
          );
          return { data: await this.postView(tx, post, user) };
        }
      }
      if (kind === "comments" && id && method === "POST") {
        const user = this.member(ctx), comment = await tx.get("forum_comments", id);
        ensure(comment, 404, "NOT_FOUND", "\u8BC4\u8BBA\u4E0D\u5B58\u5728");
        const post = await this.post(tx, comment.postId, user);
        if (action === "delete") {
          ensure(
            comment.authorUid === user.member.uid,
            403,
            "FORBIDDEN",
            "\u53EA\u80FD\u5220\u9664\u672C\u4EBA\u8BC4\u8BBA"
          );
          if (comment.status === "published")
            post.commentCount = Math.max(0, post.commentCount - 1);
          comment.status = "deleted";
          await this.audit(tx, user, "forum.comments.delete-own", id);
        } else if (action === "moderate") {
          this.require(user, "forum.comments.moderate");
          const data = import_zod6.z.object({
            status: import_zod6.z.enum(["published", "hidden", "deleted"]),
            reason: import_zod6.z.string().trim().min(1).max(300)
          }).strict().parse(input);
          if (comment.status === "published" && data.status !== "published")
            post.commentCount = Math.max(0, post.commentCount - 1);
          ensure(
            comment.status !== "deleted" || data.status === "deleted",
            409,
            "COMMENT_DELETED",
            "\u5DF2\u5220\u9664\u8BC4\u8BBA\u4E0D\u80FD\u91CD\u65B0\u516C\u5F00"
          );
          if (comment.status !== "published" && data.status === "published")
            post.commentCount++;
          comment.status = data.status;
          await this.audit(tx, user, "forum.comments." + data.status, id, {
            reason: data.reason,
            status: data.status
          });
          await this.notify(
            tx,
            comment.authorUid,
            post.id,
            "\u4F60\u7684\u8BC4\u8BBA\u5DF2\u88AB\u7BA1\u7406\u5458\u5904\u7406\uFF1A" + data.reason,
            id
          );
        } else return this.notFound();
        comment.updatedAt = this.now();
        await tx.set("forum_comments", id, comment);
        await tx.set("forum_posts", post.id, post);
        return { data: { ok: true } };
      }
      if (kind === "reports" && method === "POST") {
        const user = this.member(ctx);
        if (!id) {
          await this.rate(tx, user, "reports", 5, 864e5);
          const data2 = import_zod6.z.object({
            targetType: import_zod6.z.enum(["post", "comment"]),
            targetId: import_zod6.z.string().uuid(),
            reason: reasonInput.shape.reason
          }).strict().parse(input);
          let postId = data2.targetId;
          if (data2.targetType === "comment") {
            const c = await tx.get(
              "forum_comments",
              data2.targetId
            );
            ensure(
              c && c.status === "published",
              404,
              "NOT_FOUND",
              "\u8BC4\u8BBA\u4E0D\u5B58\u5728"
            );
            postId = c.postId;
          }
          await this.post(tx, postId, user);
          const r2 = {
            ...data2,
            id: (0, import_node_crypto9.randomUUID)(),
            reporterUid: user.member.uid,
            postId,
            status: "open",
            resolution: "",
            createdAt: this.now(),
            updatedAt: this.now()
          };
          await tx.set("forum_reports", r2.id, r2);
          await this.audit(tx, user, "forum.reports.create", r2.id);
          return { data: r2 };
        }
        this.require(user, "forum.reports.manage");
        const data = import_zod6.z.object({
          status: import_zod6.z.enum(["resolved", "dismissed"]),
          resolution: import_zod6.z.string().trim().min(2).max(500)
        }).strict().parse(input), r = await tx.get("forum_reports", id);
        ensure(r, 404, "NOT_FOUND", "\u4E3E\u62A5\u4E0D\u5B58\u5728");
        ensure(r.status === "open", 409, "REPORT_CLOSED", "\u4E3E\u62A5\u5DF2\u5904\u7406");
        await tx.set("forum_reports", id, {
          ...r,
          ...data,
          updatedAt: this.now()
        });
        await this.audit(tx, user, "forum.reports." + data.status, id, {
          status: data.status,
          resolution: data.resolution
        });
        await this.notify(
          tx,
          r.reporterUid,
          r.postId,
          "\u4F60\u7684\u4E3E\u62A5\u5DF2\u5904\u7406\uFF1A" + data.resolution
        );
        return { data: { ok: true } };
      }
      if (kind === "restrictions") {
        const user = this.member(ctx);
        this.require(user, "forum.users.restrict");
        if (method === "GET")
          return { data: await this.page("forum_user_restrictions", {}, q) };
        ensure(method === "POST", 404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
        const data = restrictionInput.parse(input), studentId = studentIdSchema.parse(data.studentId), mapping = await tx.get(
          "student_ids",
          studentIdKey(studentId)
        );
        ensure(mapping, 404, "NOT_FOUND", "\u6210\u5458\u4E0D\u5B58\u5728");
        const target = await tx.get("users", mapping.uid);
        ensure(
          target?.status === "active",
          409,
          "INACTIVE_MEMBER",
          "\u6210\u5458\u8D26\u53F7\u4E0D\u662F\u6B63\u5E38\u72B6\u6001"
        );
        const { studentId: _sid, ...fields } = data;
        void _sid;
        const previous = await tx.get(
          "forum_user_restrictions",
          mapping.uid
        );
        const record2 = {
          ...fields,
          id: mapping.uid,
          uid: mapping.uid,
          createdAt: previous?.createdAt ?? this.now(),
          updatedAt: this.now()
        };
        await tx.set("forum_user_restrictions", mapping.uid, record2);
        await this.audit(tx, user, "forum.users.restrict", mapping.uid, {
          posts: data.posts,
          comments: data.comments,
          reason: data.reason
        });
        return { data: record2 };
      }
      if (kind === "me") {
        const user = this.member(ctx);
        if (id === "notifications" && action && method === "POST") {
          const n = await tx.get(
            "forum_notifications",
            action
          );
          ensure(
            n && n.recipientUid === user.member.uid,
            404,
            "NOT_FOUND",
            "\u901A\u77E5\u4E0D\u5B58\u5728"
          );
          await tx.set("forum_notifications", action, { ...n, read: true });
          return { data: { ok: true } };
        }
        ensure(method === "GET", 404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
        if (id === "posts") {
          const result = await this.page(
            "forum_posts",
            { authorUid: user.member.uid, _notDeleted: true },
            q
          );
          return {
            data: {
              ...result,
              items: await Promise.all(
                result.items.map(
                  (p) => this.postView(tx, p, user)
                )
              )
            }
          };
        }
        if (id === "comments") {
          const result = await this.page(
            "forum_comments",
            { authorUid: user.member.uid, _notDeleted: true },
            q
          );
          return {
            data: {
              ...result,
              items: await Promise.all(
                result.items.map(
                  (c) => this.commentView(tx, c)
                )
              )
            }
          };
        }
        if (id === "favorites") {
          const result = await this.page(
            "forum_posts",
            { _favoriteUid: user.member.uid, _public: true },
            q
          );
          return {
            data: {
              ...result,
              items: await Promise.all(
                result.items.map(
                  (p) => this.postView(tx, p, user)
                )
              )
            }
          };
        }
        if (id === "notifications")
          return {
            data: await this.page(
              "forum_notifications",
              { recipientUid: user.member.uid },
              q
            )
          };
        if (id === "reports")
          return {
            data: await this.page(
              "forum_reports",
              { reporterUid: user.member.uid },
              q
            )
          };
        if (id === "restrictions")
          return {
            data: await tx.get("forum_user_restrictions", user.member.uid)
          };
      }
      if (kind === "admin" && method === "GET") {
        const user = this.member(ctx);
        if (id === "posts") {
          ensure(
            postModeration.some((p) => this.can(user, p)),
            403,
            "FORBIDDEN",
            "\u6CA1\u6709\u5E16\u5B50\u7BA1\u7406\u6743\u9650"
          );
          const filter = {};
          if (!this.can(user, "forum.posts.review") && !this.can(user, "forum.posts.delete"))
            filter._public = true;
          if (q.status)
            filter.status = import_zod6.z.enum(["pending", "published", "hidden", "deleted"]).parse(q.status);
          if (q.search) filter._search = import_zod6.z.string().max(80).parse(q.search);
          const result = await this.page("forum_posts", filter, q);
          return {
            data: {
              ...result,
              items: await Promise.all(
                result.items.map(
                  (p) => this.postView(tx, p, user)
                )
              )
            }
          };
        }
        if (id === "comments") {
          this.require(user, "forum.comments.moderate");
          return {
            data: await this.page(
              "forum_comments",
              q.postId ? { postId: q.postId } : {},
              q
            )
          };
        }
        if (id === "reports") {
          this.require(user, "forum.reports.manage");
          return {
            data: await this.page(
              "forum_reports",
              q.status ? {
                status: import_zod6.z.enum(["open", "resolved", "dismissed"]).parse(q.status)
              } : {},
              q
            )
          };
        }
        if (id === "audit") {
          ensure(
            FORUM_PERMISSIONS.some((p) => this.can(user, p)),
            403,
            "FORBIDDEN",
            "\u6CA1\u6709\u5BA1\u6838\u8BB0\u5F55\u6743\u9650"
          );
          const result = await this.page("audit_logs", { _forumAudit: true }, q);
          const items = result.items.map((row) => {
            const required = row.action.startsWith("forum.users.") ? "forum.users.restrict" : row.action.startsWith("forum.reports.") ? "forum.reports.manage" : row.action.startsWith("forum.comments.") ? "forum.comments.moderate" : row.action.startsWith("forum.boards.") ? "forum.boards.manage" : row.action === "forum.posts.pin" ? "forum.posts.pin" : row.action === "forum.posts.feature" ? "forum.posts.feature" : [
              "forum.posts.lock",
              "forum.posts.close-comments"
            ].includes(row.action) ? "forum.posts.lock" : "forum.posts.review";
            return this.can(user, required) ? row : { ...row, details: void 0 };
          });
          return { data: { ...result, items } };
        }
      }
      return this.notFound();
    };
    if (publicRead && !token) return this.store.run((tx) => work(tx));
    try {
      return await this.secure(token, (tx, ctx) => work(tx, ctx));
    } catch (error) {
      if (publicRead && error.status === 401)
        return this.store.run((tx) => work(tx));
      throw error;
    }
  }
  notFound() {
    ensure(false, 404, "NOT_FOUND", "\u793E\u533A\u63A5\u53E3\u4E0D\u5B58\u5728");
  }
};

// src/stage3/manager-options.ts
var import_zod7 = require("zod");
async function managerSummaries(tx, uids) {
  const members = await Promise.all(
    uids.map((id) => tx.get("users", id))
  );
  const roleCache = /* @__PURE__ */ new Map();
  return Promise.all(
    members.filter((m) => !!m).map(async (member) => ({
      uid: member.uid,
      name: member.name,
      nickname: member.nickname,
      status: member.status,
      roles: (await Promise.all(
        member.roleIds.map((id) => {
          if (!roleCache.has(id))
            roleCache.set(id, tx.get("roles", id));
          return roleCache.get(id);
        })
      )).flatMap((r) => r ? [{ id: r.id, name: r.name }] : [])
    }))
  );
}
async function managerOptions(tx, store, ctx, method, resource, action, input, query) {
  ensure(
    ctx.super || ctx.permissions.includes("events.edit"),
    403,
    "FORBIDDEN",
    "\u9700\u8981\u6D3B\u52A8\u8D1F\u8D23\u4EBA\u5206\u914D\u6743\u9650"
  );
  const roleCache = /* @__PURE__ */ new Map();
  const role = (id) => {
    if (!roleCache.has(id)) roleCache.set(id, tx.get("roles", id));
    return roleCache.get(id);
  };
  const option = async (member) => ({
    uid: member.uid,
    name: member.name,
    nickname: member.nickname,
    status: member.status,
    roles: (await Promise.all(member.roleIds.map(role))).flatMap(
      (r) => r ? [{ id: r.id, name: r.name }] : []
    )
  });
  if (resource === "manager-roles" && method === "GET" && !action) {
    const q = import_zod7.z.object({ page: import_zod7.z.coerce.number().int().min(1).max(100).default(1) }).strict().parse(query);
    const result = await store.list(
      "roles",
      {},
      { offset: (q.page - 1) * 100, limit: 100 }
    );
    return {
      data: {
        items: result.items.map((r) => ({ id: r.id, name: r.name })),
        total: result.total,
        page: q.page,
        pageSize: 100
      }
    };
  }
  if (resource === "manager-options" && method === "GET" && !action) {
    const q = import_zod7.z.object({
      search: import_zod7.z.string().trim().max(100).default(""),
      roleId: import_zod7.z.string().max(64).default(""),
      page: import_zod7.z.coerce.number().int().min(1).max(1e4).default(1),
      pageSize: import_zod7.z.coerce.number().int().min(1).max(50).default(20)
    }).strict().parse(query);
    if (q.roleId)
      ensure(await role(q.roleId), 404, "ROLE_NOT_FOUND", "\u6240\u9009\u89D2\u8272\u4E0D\u5B58\u5728");
    const result = await store.list(
      "users",
      {
        status: "active",
        _search: q.search,
        ...q.roleId ? { roleIds: q.roleId } : {}
      },
      { offset: (q.page - 1) * q.pageSize, limit: q.pageSize }
    );
    return {
      data: {
        items: await Promise.all(result.items.map(option)),
        total: result.total,
        page: q.page,
        pageSize: q.pageSize
      }
    };
  }
  if (resource === "manager-options" && action === "resolve" && method === "POST") {
    const body = import_zod7.z.object({ uids: import_zod7.z.array(import_zod7.z.string().uuid()).max(MAX_EVENT_MANAGERS) }).strict().parse(input);
    const members = await Promise.all(
      [...new Set(body.uids)].map((id) => tx.get("users", id))
    );
    return {
      data: {
        items: await Promise.all(
          members.filter((m) => !!m).map(option)
        )
      }
    };
  }
  if (resource === "manager-options" && action === "by-role" && method === "POST") {
    const body = import_zod7.z.object({ roleIds: import_zod7.z.array(import_zod7.z.string().min(1).max(64)).min(1).max(20) }).strict().parse(input);
    const members = /* @__PURE__ */ new Map();
    for (const id of new Set(body.roleIds)) {
      ensure(await role(id), 404, "ROLE_NOT_FOUND", "\u6240\u9009\u89D2\u8272\u4E0D\u5B58\u5728");
      const page2 = await store.list(
        "users",
        { status: "active", roleIds: id },
        { offset: 0, limit: MAX_EVENT_MANAGERS }
      );
      ensure(
        page2.total <= MAX_EVENT_MANAGERS,
        409,
        "MANAGER_LIMIT",
        `\u8BE5\u89D2\u8272\u6709\u6548\u6210\u5458\u8D85\u8FC7${MAX_EVENT_MANAGERS}\u4EBA\uFF0C\u8BF7\u6309\u59D3\u540D\u641C\u7D22\u6216\u5206\u9875\u52FE\u9009`
      );
      for (const member of page2.items) members.set(member.uid, member);
      ensure(
        members.size <= MAX_EVENT_MANAGERS,
        409,
        "MANAGER_LIMIT",
        `\u8D1F\u8D23\u4EBA\u6700\u591A${MAX_EVENT_MANAGERS}\u4EBA\uFF0C\u8BF7\u51CF\u5C11\u9009\u62E9\u7684\u89D2\u8272`
      );
    }
    return {
      data: { items: await Promise.all([...members.values()].map(option)) }
    };
  }
  ensure(false, 405, "METHOD_NOT_ALLOWED", "\u65B9\u6CD5\u4E0D\u652F\u6301");
}

// src/stage3/service.ts
var import_node_crypto10 = require("node:crypto");
var import_zod9 = require("zod");

// src/members/xlsx.ts
var import_exceljs = __toESM(require("exceljs"));
var import_yauzl = require("yauzl");
var columns = ["\u5B66\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u5B66\u9662", "\u4E13\u4E1A", "\u73ED\u7EA7", "\u5E74\u7EA7"];
async function validateZip(buffer) {
  ensure(buffer.length <= 2e6, 413, "FILE_TOO_LARGE", "\u6587\u4EF6\u6700\u59272MB");
  await new Promise(
    (resolve, reject) => (0, import_yauzl.fromBuffer)(buffer, { lazyEntries: true }, (error, zip) => {
      if (error || !zip) return reject(new Error("\u65E0\u6548\u7684 XLSX \u538B\u7F29\u6587\u4EF6"));
      let size = 0, count = 0, ended = false, actualSize = 0;
      const fail2 = () => {
        if (!ended) {
          ended = true;
          zip.close();
          reject(new Error("XLSX \u89E3\u538B\u6570\u636E\u8FC7\u5927\u6216\u683C\u5F0F\u5F02\u5E38"));
        }
      };
      zip.on("error", fail2);
      zip.on("entry", (entry) => {
        size += entry.uncompressedSize;
        count++;
        if (size > 2e7 || count > 2e3 || entry.fileName.includes("..") || entry.generalPurposeBitFlag & 1)
          fail2();
        else
          zip.openReadStream(entry, (err, stream) => {
            if (err || !stream) {
              fail2();
              return;
            }
            stream.on("data", (chunk) => {
              actualSize += chunk.length;
              if (actualSize > 2e7) {
                stream.destroy();
                fail2();
              }
            });
            stream.on("error", fail2);
            stream.on("end", () => {
              if (!ended) zip.readEntry();
            });
          });
      });
      zip.on("end", () => {
        if (!ended) {
          ended = true;
          resolve();
        }
      });
      zip.readEntry();
    })
  );
}
async function parseWorkbook(buffer) {
  try {
    await validateZip(buffer);
  } catch {
    ensure(false, 400, "INVALID_XLSX", "\u6587\u4EF6\u65E0\u6548\u6216\u89E3\u538B\u4F53\u79EF\u8D85\u8FC720MB");
  }
  const workbook = new import_exceljs.default.Workbook();
  try {
    await workbook.xlsx.load(buffer);
  } catch {
    ensure(false, 400, "INVALID_XLSX", "\u65E0\u6CD5\u89E3\u6790XLSX\u6587\u4EF6");
  }
  const sheet = workbook.worksheets[0];
  ensure(sheet, 400, "NO_SHEET", "\u6587\u4EF6\u6CA1\u6709\u5DE5\u4F5C\u8868");
  ensure(
    columns.every(
      (name, index) => sheet.getRow(1).getCell(index + 1).text === name
    ),
    400,
    "INVALID_COLUMNS",
    "\u8868\u5934\u987B\u4E3A\uFF1A" + columns.join("\u3001")
  );
  ensure(
    sheet.rowCount <= 1001,
    413,
    "TOO_MANY_ROWS",
    "\u6BCF\u6587\u4EF6\u6700\u591A1000\u884C\uFF0C\u8BF7\u5206\u6587\u4EF6\u5BFC\u5165"
  );
  const rows = [];
  const seen = /* @__PURE__ */ new Set();
  for (let line = 2; line <= sheet.rowCount; line++) {
    const row = sheet.getRow(line);
    if (row.actualCellCount === 0 || columns.every((_, i) => !row.getCell(i + 1).text.trim()))
      continue;
    if (typeof row.getCell(1).value !== "string") {
      rows.push({
        line,
        error: "\u5B66\u53F7\u5FC5\u987B\u4E3A\u6587\u672C\u5355\u5143\u683C\uFF1B\u6570\u5B57\u6216\u79D1\u5B66\u8BA1\u6570\u6CD5\u65E0\u6CD5\u53EF\u9760\u6062\u590D\uFF0C\u8BF7\u91CD\u65B0\u586B\u5199\u6A21\u677F"
      });
      continue;
    }
    const values = {};
    let invalid = false;
    for (const [index, key2] of [
      "studentId",
      "name",
      "gender",
      "college",
      "major",
      "className",
      "grade"
    ].entries()) {
      const cell = row.getCell(index + 1);
      if (typeof cell.value === "object" && cell.value !== null) {
        invalid = true;
        break;
      }
      values[key2] = key2 === "studentId" ? cell.text : cell.text.trim();
    }
    if (invalid) {
      rows.push({ line, error: "\u4E0D\u652F\u6301\u516C\u5F0F\u3001\u8D85\u94FE\u63A5\u6216\u5BCC\u6587\u672C\u5355\u5143\u683C" });
      continue;
    }
    if (!values.gender) values.gender = "\u672A\u586B\u5199";
    const parsed = memberSchema.safeParse(values);
    if (!parsed.success) {
      rows.push({
        line,
        error: parsed.error.issues.map((e) => `${e.path.join(".")}: ${e.message}`).join("\uFF1B")
      });
      continue;
    }
    const member = {
      studentId: parsed.data.studentId,
      name: parsed.data.name,
      gender: parsed.data.gender,
      college: parsed.data.college,
      major: parsed.data.major,
      className: parsed.data.className,
      grade: parsed.data.grade
    };
    const duplicate = seen.has(member.studentId);
    seen.add(member.studentId);
    rows.push({
      line,
      member,
      ...duplicate ? { error: "\u6587\u4EF6\u5185\u5B66\u53F7\u91CD\u590D" } : {}
    });
  }
  ensure(rows.length > 0, 400, "EMPTY_FILE", "\u6CA1\u6709\u53EF\u5BFC\u5165\u7684\u6570\u636E\u884C");
  return rows;
}
async function templateWorkbook() {
  const book = new import_exceljs.default.Workbook();
  const sheet = book.addWorksheet("\u6210\u5458\u5BFC\u5165");
  sheet.addRow(columns);
  sheet.getColumn(1).numFmt = "@";
  sheet.columns.forEach((column) => {
    column.width = 22;
  });
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  return Buffer.from(await book.xlsx.writeBuffer());
}
async function exportWorkbook(headers, rows) {
  const book = new import_exceljs.default.Workbook();
  const sheet = book.addWorksheet("\u6570\u636E");
  sheet.addRow(headers);
  sheet.columns = headers.map(() => ({ width: 24, style: { numFmt: "@" } }));
  for (const row of rows) sheet.addRow(row);
  return Buffer.from(await book.xlsx.writeBuffer());
}

// src/stage3/model.ts
var import_zod8 = require("zod");
var text3 = import_zod8.z.string().trim();
var image = import_zod8.z.string().max(15e5).refine(
  (v) => !v || !!mediaReference(v) || /^https:\/\/[^\s]+$/i.test(v) || /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v),
  "\u56FE\u7247\u987B\u4E3AHTTPS\u5730\u5740\u6216PNG/JPEG/WebP\u56FE\u7247"
);
var date = import_zod8.z.string().datetime({ offset: true }).transform((v) => new Date(v).toISOString());
var optionalDate = import_zod8.z.union([date, import_zod8.z.literal("")]).default("");
var eventSchema = import_zod8.z.object({
  title: text3.min(1).max(120),
  summary: text3.max(500).default(""),
  content: import_zod8.z.string().max(1e5).default(""),
  cover: image.default(""),
  location: text3.max(200).default(""),
  startsAt: date,
  endsAt: date,
  status: import_zod8.z.enum(["draft", "published", "disabled"]).default("draft"),
  registrationEnabled: import_zod8.z.boolean().default(false),
  registrationStartsAt: optionalDate,
  registrationDeadline: optionalDate,
  capacity: import_zod8.z.number().int().min(1).max(1e5).nullable().default(null),
  allowCancellation: import_zod8.z.boolean().default(true),
  approvalRequired: import_zod8.z.boolean().default(false),
  notesEnabled: import_zod8.z.boolean().default(false),
  notesRequired: import_zod8.z.boolean().default(false),
  checkinEnabled: import_zod8.z.boolean().default(false),
  checkinTtlSeconds: import_zod8.z.number().int().min(30).max(MAX_CHECKIN_TTL_SECONDS).default(DEFAULT_CHECKIN_TTL_SECONDS),
  managerIds: import_zod8.z.array(import_zod8.z.string().uuid()).max(MAX_EVENT_MANAGERS).transform((ids) => [...new Set(ids)]).default([])
}).strict().superRefine((v, ctx) => {
  if (v.endsAt <= v.startsAt)
    ctx.addIssue({ code: "custom", message: "\u7ED3\u675F\u65F6\u95F4\u987B\u665A\u4E8E\u5F00\u59CB\u65F6\u95F4" });
  if (v.registrationEnabled && (!v.registrationDeadline || v.registrationDeadline > v.endsAt))
    ctx.addIssue({
      code: "custom",
      message: "\u5F00\u542F\u62A5\u540D\u5FC5\u987B\u8BBE\u7F6E\u4E0D\u665A\u4E8E\u6D3B\u52A8\u7ED3\u675F\u7684\u622A\u6B62\u65F6\u95F4"
    });
  if (v.registrationStartsAt && v.registrationDeadline && v.registrationStartsAt >= v.registrationDeadline)
    ctx.addIssue({ code: "custom", message: "\u62A5\u540D\u5F00\u59CB\u987B\u65E9\u4E8E\u622A\u6B62" });
  if (v.notesRequired && !v.notesEnabled)
    ctx.addIssue({ code: "custom", message: "\u5FC5\u586B\u5907\u6CE8\u987B\u5148\u542F\u7528\u5907\u6CE8" });
});
var articleSchema = import_zod8.z.object({
  title: text3.min(1).max(120),
  summary: text3.max(500).default(""),
  content: import_zod8.z.string().max(1e5),
  cover: image.default(""),
  category: text3.min(1).max(40).default("\u516C\u544A"),
  pinned: import_zod8.z.boolean().default(false),
  status: import_zod8.z.enum(["draft", "published", "withdrawn"]).default("draft")
}).strict();
var popupSchema = import_zod8.z.object({
  title: text3.min(1).max(120),
  summary: text3.max(500).default(""),
  image: image.default(""),
  buttonText: text3.min(1).max(30).default("\u67E5\u770B\u8BE6\u60C5"),
  targetType: import_zod8.z.enum(["event", "article"]),
  targetId: import_zod8.z.string().uuid(),
  startsAt: date,
  expiresAt: date,
  priority: import_zod8.z.number().int().min(0).max(1e3).default(0)
}).strict().refine((v) => v.expiresAt > v.startsAt, "\u5931\u6548\u65F6\u95F4\u987B\u665A\u4E8E\u751F\u6548\u65F6\u95F4");

// src/stage3/service.ts
var empty = () => ({ events: [], articles: [], popups: [] });
var sha = (v) => (0, import_node_crypto10.createHash)("sha256").update(v).digest("hex");
var publicEvent = (e) => {
  const { managerIds: _managers, registrationIds: _rows, ...data } = e;
  void _managers;
  void _rows;
  return data;
};
var Stage3Service = class {
  constructor(store, secure, clock = () => Date.now()) {
    this.store = store;
    this.secure = secure;
    this.clock = clock;
  }
  now() {
    return new Date(this.clock()).toISOString();
  }
  async content(tx, collection, id) {
    const value = await tx.get(collection, id);
    if (!value) return null;
    if (value.id !== id)
      console.warn(
        JSON.stringify({
          category: "data",
          stage: "content_read",
          code: "CONTENT_ID_MISMATCH",
          collection
        })
      );
    return { ...value, id };
  }
  can(ctx, p) {
    return ctx.super || ctx.permissions.includes(p);
  }
  require(ctx, p) {
    ensure(this.can(ctx, p), 403, "FORBIDDEN", "\u6CA1\u6709\u6B64\u64CD\u4F5C\u6743\u9650");
  }
  readableEvent(ctx, e) {
    return ctx.super || e.managerIds.includes(ctx.member.uid) || [
      "events.edit",
      "events.delete",
      "events.registrations.read",
      "events.registrations.review",
      "events.registrations.export",
      "events.checkin.manage"
    ].some((p) => ctx.permissions.includes(p));
  }
  scope(ctx, e, p) {
    ensure(
      this.can(ctx, p) || e.managerIds.includes(ctx.member.uid),
      403,
      "EVENT_SCOPE",
      "\u672A\u83B7\u6B64\u6D3B\u52A8\u7BA1\u7406\u6388\u6743"
    );
  }
  access(ctx, e) {
    const manager = e.managerIds.includes(ctx.member.uid);
    const can = (p) => this.can(ctx, p) || manager;
    return {
      edit: can("events.edit"),
      assignManagers: this.can(ctx, "events.edit"),
      roster: [
        "events.registrations.read",
        "events.registrations.review",
        "events.registrations.export",
        "events.checkin.manage"
      ].some(can),
      review: can("events.registrations.review"),
      export: can("events.registrations.export"),
      checkin: can("events.checkin.manage")
    };
  }
  async audit(tx, ctx, action, target) {
    const id = (0, import_node_crypto10.randomUUID)();
    await tx.set("audit_logs", id, {
      id,
      actor: ctx.member.uid,
      action,
      target,
      fields: [],
      createdAt: this.now()
    });
  }
  async catalog(tx) {
    return await tx.get("system", "stage3_catalog") ?? empty();
  }
  async page(items, q) {
    const page2 = import_zod9.z.coerce.number().int().min(1).max(1e4).parse(q.page ?? 1), pageSize = import_zod9.z.coerce.number().int().min(1).max(100).parse(q.pageSize ?? 20);
    return {
      items: items.slice((page2 - 1) * pageSize, page2 * pageSize),
      total: items.length,
      page: page2,
      pageSize
    };
  }
  async roster(e, q) {
    const parsed = import_zod9.z.object({
      page: import_zod9.z.coerce.number().int().min(1).max(1e4).default(1),
      pageSize: import_zod9.z.coerce.number().int().min(1).max(100).default(20),
      search: import_zod9.z.string().max(100).default(""),
      college: import_zod9.z.string().max(100).default(""),
      className: import_zod9.z.string().max(100).default(""),
      status: import_zod9.z.enum(["", "pending", "approved", "rejected", "cancelled", "manual"]).default(""),
      checkedIn: import_zod9.z.enum(["", "yes", "no"]).default("")
    }).strict().parse(q);
    const { page: page2, pageSize, ...filters } = parsed;
    const filter = { ...filters, eventId: e.id }, options = { offset: (page2 - 1) * pageSize, limit: pageSize };
    validateRosterQuery(filter, options);
    return {
      ...await this.store.list(
        "event_roster",
        filter,
        options
      ),
      page: page2,
      pageSize
    };
  }
  async retireDue(tx, catalog, except = "") {
    for (const id of catalog.popups) {
      if (id === except) continue;
      const p = await tx.get("popup_announcements", id);
      if (p && p.enabled && p.state !== "retired" && p.startsAt <= this.now())
        await tx.set("popup_announcements", id, {
          ...p,
          state: "retired",
          updatedAt: this.now()
        });
    }
  }
  async popup(tx) {
    const catalog = await this.catalog(tx), now = this.now();
    const all = (await Promise.all(
      catalog.popups.map(
        (id) => tx.get("popup_announcements", id)
      )
    )).filter((v) => !!v);
    const eligible = [];
    for (const p of all) {
      if (!p.enabled || p.state === "retired" || p.startsAt > now || p.expiresAt <= now)
        continue;
      const target = await this.content(
        tx,
        p.targetType === "event" ? "events" : "articles",
        p.targetId
      );
      if (target?.status === "published") eligible.push(p);
    }
    eligible.sort(
      (a, b) => b.priority - a.priority || b.startsAt.localeCompare(a.startsAt) || b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id)
    );
    const chosen = eligible[0] ?? null;
    for (const p of all) {
      const state = p.id === chosen?.id ? "active" : p.state === "active" || p.enabled && p.expiresAt <= now ? "retired" : p.state;
      if (state !== p.state)
        await tx.set("popup_announcements", p.id, {
          ...p,
          state,
          updatedAt: now
        });
    }
    const current = await tx.get("popup_state", "current");
    if (!current || current.popupId !== (chosen?.id ?? null) || current.version !== (chosen?.version ?? null))
      await tx.set("popup_state", "current", {
        id: "current",
        popupId: chosen?.id ?? null,
        version: chosen?.version ?? null,
        updatedAt: now
      });
    return chosen ? { ...chosen, state: "active" } : null;
  }
  async execute(token, method, path, input, q) {
    if (method === "POST" && /^\/api\/(events|articles)\/[^/]+\/update$/.test(path)) {
      path = path.slice(0, -"/update".length);
      method = "PATCH";
    }
    const publicRead = method === "GET" && path.startsWith("/api/public/");
    const work = async (tx, ctx) => {
      const cat = await this.catalog(tx);
      if (path === "/api/public/popup") return { data: await this.popup(tx) };
      if (path.startsWith("/api/public/")) {
        const [, kind2, id2] = path.slice("/api/public".length).split("/");
        const collection = kind2 === "events" ? "events" : kind2 === "articles" ? "articles" : "";
        ensure(collection, 404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
        if (id2) {
          const item = await this.content(
            tx,
            collection,
            id2
          );
          ensure(
            item?.status === "published",
            404,
            "NOT_FOUND",
            "\u5185\u5BB9\u672A\u53D1\u5E03\u6216\u4E0D\u5B58\u5728"
          );
          return {
            data: collection === "events" ? publicEvent(item) : item
          };
        }
        const ids = collection === "events" ? cat.events : cat.articles;
        const items = (await Promise.all(
          ids.map(
            (id3) => this.content(tx, collection, id3)
          )
        )).filter(
          (v) => !!v && v.status === "published"
        ).filter(
          (v) => (!q.search || v.title.includes(q.search)) && (!q.category || "category" in v && v.category === q.category)
        ).sort(
          (a, b) => Number("pinned" in b && b.pinned) - Number("pinned" in a && a.pinned) || String(b.publishedAt).localeCompare(String(a.publishedAt))
        );
        return {
          data: await this.page(
            items.map(
              (v) => collection === "events" ? publicEvent(v) : v
            ),
            q
          )
        };
      }
      ensure(ctx, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
      const parts = path.slice("/api/".length).split("/"), kind = parts[0], id = parts[1], action = parts[2];
      if (kind === "events") {
        if (id === "manager-options" || id === "manager-roles") {
          const result = await managerOptions(
            tx,
            this.store,
            ctx,
            method,
            id,
            action,
            input,
            q
          );
          await this.audit(tx, ctx, "events.manager_candidates", "users");
          return result;
        }
        if (!id && method === "GET") {
          const all = (await Promise.all(
            cat.events.map((id2) => this.content(tx, "events", id2))
          )).filter(
            (e) => !!e && e.status !== "deleted" && this.readableEvent(ctx, e) && (!q.search || e.title.includes(q.search)) && (!q.status || e.status === q.status)
          );
          return { data: await this.page(all, q) };
        }
        if (!id && method === "POST") {
          this.require(ctx, "events.create");
          const data = eventSchema.parse(input);
          if (data.managerIds.some((uid) => uid !== ctx.member.uid))
            this.require(ctx, "events.edit");
          for (const uid of data.managerIds) {
            const member = await tx.get("users", uid);
            ensure(
              member?.status === "active",
              400,
              "INVALID_MANAGER",
              "\u8D1F\u8D23\u4EBA\u987B\u4E3A\u6709\u6548\u6210\u5458"
            );
          }
          const event2 = {
            ...data,
            id: (0, import_node_crypto10.randomUUID)(),
            publisherUid: ctx.member.uid,
            publisherName: ctx.member.nickname,
            publishedAt: data.status === "published" ? this.now() : null,
            createdAt: this.now(),
            updatedAt: this.now(),
            registrationIds: [],
            occupied: 0,
            checkinOpen: false
          };
          if (!event2.managerIds.includes(ctx.member.uid))
            event2.managerIds.push(ctx.member.uid);
          ensure(
            event2.managerIds.length <= MAX_EVENT_MANAGERS,
            400,
            "MANAGER_LIMIT",
            `\u8D1F\u8D23\u4EBA\u6700\u591A${MAX_EVENT_MANAGERS}\u4EBA\uFF0C\u5305\u542B\u521B\u5EFA\u8005`
          );
          await syncMedia(
            tx,
            ctx,
            "events",
            event2.id,
            references(event2.content, event2.cover)
          );
          await tx.set("events", event2.id, event2);
          for (const uid of event2.managerIds)
            await tx.set("event_managers", `${event2.id}:${uid}`, {
              eventId: event2.id,
              uid
            });
          cat.events.push(event2.id);
          await tx.set("system", "stage3_catalog", cat);
          await this.audit(tx, ctx, "events.create", event2.id);
          return { data: event2 };
        }
        if (id === "manager-lookup" && method === "GET") {
          this.require(ctx, "events.edit");
          const studentId = studentIdSchema.parse(q.studentId);
          const mapping = await tx.get(
            "student_ids",
            studentIdKey(studentId)
          );
          const member = mapping ? await tx.get("users", mapping.uid) : null;
          ensure(
            member?.status === "active",
            404,
            "NOT_FOUND",
            "\u672A\u627E\u5230\u6709\u6548\u6210\u5458"
          );
          await this.audit(tx, ctx, "events.manager_lookup", member.uid);
          return {
            data: {
              uid: member.uid,
              studentId: member.studentId,
              nickname: member.nickname
            }
          };
        }
        const event = await this.content(tx, "events", id);
        ensure(
          event && event.status !== "deleted",
          404,
          "NOT_FOUND",
          "\u6D3B\u52A8\u4E0D\u5B58\u5728"
        );
        if (!action && method === "GET") {
          ensure(
            this.readableEvent(ctx, event),
            403,
            "EVENT_SCOPE",
            "\u672A\u83B7\u6D3B\u52A8\u67E5\u770B\u6388\u6743"
          );
          return { data: event };
        }
        if (action === "access" && method === "GET")
          return { data: this.access(ctx, event) };
        if (action === "managers" && method === "GET") {
          ensure(
            this.readableEvent(ctx, event),
            403,
            "EVENT_SCOPE",
            "\u672A\u83B7\u6B64\u6D3B\u52A8\u7BA1\u7406\u6388\u6743"
          );
          return {
            data: { items: await managerSummaries(tx, event.managerIds) }
          };
        }
        if (!action && method === "PATCH") {
          this.scope(ctx, event, "events.edit");
          const data = eventSchema.parse({
            ...Object.fromEntries(
              Object.keys(eventSchema.shape).map((key2) => [
                key2,
                event[key2]
              ])
            ),
            ...import_zod9.z.record(import_zod9.z.string(), import_zod9.z.unknown()).parse(input)
          });
          if (data.managerIds.length !== event.managerIds.length || data.managerIds.some((uid) => !event.managerIds.includes(uid)))
            this.require(ctx, "events.edit");
          ensure(
            data.capacity === null || data.capacity >= event.occupied,
            409,
            "CAPACITY_BELOW_OCCUPIED",
            "\u4EBA\u6570\u4E0A\u9650\u4E0D\u80FD\u4F4E\u4E8E\u5DF2\u5360\u540D\u989D"
          );
          for (const uid of data.managerIds) {
            const member = await tx.get("users", uid);
            ensure(
              member && (member.status === "active" || event.managerIds.includes(uid)),
              400,
              "INVALID_MANAGER",
              "\u8D1F\u8D23\u4EBA\u987B\u4E3A\u6709\u6548\u6210\u5458"
            );
          }
          for (const uid of event.managerIds)
            await tx.remove("event_managers", `${event.id}:${uid}`);
          for (const uid of data.managerIds)
            await tx.set("event_managers", `${event.id}:${uid}`, {
              eventId: event.id,
              uid
            });
          const next = {
            ...event,
            ...data,
            checkinOpen: data.checkinEnabled && data.status === "published" && event.checkinOpen,
            publishedAt: event.publishedAt ?? (data.status === "published" ? this.now() : null),
            updatedAt: this.now()
          };
          await syncMedia(
            tx,
            ctx,
            "events",
            event.id,
            references(next.content, next.cover),
            references(event.content, event.cover)
          );
          await tx.set("events", event.id, next);
          if (!next.checkinOpen)
            await tx.set("system", `checkin:${event.id}`, {
              hash: "",
              expiresAt: 0
            });
          await this.audit(tx, ctx, "events.edit", event.id);
          return { data: next };
        }
        if (!action && method === "DELETE") {
          this.require(ctx, "events.delete");
          await tx.set("events", event.id, {
            ...event,
            status: "deleted",
            updatedAt: this.now()
          });
          await this.audit(tx, ctx, "events.delete", event.id);
          return { data: { ok: true } };
        }
        if (action === "member-lookup" && method === "GET") {
          this.scope(ctx, event, "events.checkin.manage");
          const studentId = studentIdSchema.parse(q.studentId);
          const mapping = await tx.get(
            "student_ids",
            studentIdKey(studentId)
          );
          const member = mapping ? await tx.get("users", mapping.uid) : null;
          ensure(
            member?.status === "active",
            404,
            "NOT_FOUND",
            "\u672A\u627E\u5230\u6709\u6548\u6210\u5458"
          );
          await this.audit(tx, ctx, "events.checkin_member_lookup", event.id);
          return {
            data: {
              uid: member.uid,
              studentId: member.studentId,
              nickname: member.nickname
            }
          };
        }
        const registrationId = `${event.id}:${ctx.member.uid}`;
        if (action === "registration" && method === "GET")
          return {
            data: await tx.get("registrations", registrationId)
          };
        if (action === "registration" && method === "POST") {
          const body = import_zod9.z.object({ note: import_zod9.z.string().trim().max(2e3).default("") }).strict().parse(input);
          ensure(
            event.status === "published" && event.registrationEnabled,
            409,
            "REGISTRATION_CLOSED",
            "\u6D3B\u52A8\u672A\u5F00\u653E\u62A5\u540D"
          );
          ensure(
            (!event.registrationStartsAt || this.now() >= event.registrationStartsAt) && this.now() < event.registrationDeadline,
            409,
            "REGISTRATION_TIME",
            "\u4E0D\u5728\u62A5\u540D\u65F6\u95F4\u5185"
          );
          ensure(
            event.notesEnabled || !body.note,
            400,
            "NOTES_DISABLED",
            "\u6D3B\u52A8\u672A\u5F00\u542F\u5907\u6CE8"
          );
          ensure(
            !event.notesRequired || !!body.note,
            400,
            "NOTE_REQUIRED",
            "\u8BF7\u586B\u5199\u5907\u6CE8"
          );
          const previous = await tx.get(
            "registrations",
            registrationId
          );
          ensure(
            !previous?.checkedInAt,
            409,
            "ALREADY_CHECKED_IN",
            "\u5DF2\u7B7E\u5230\u8BB0\u5F55\u4E0D\u80FD\u91CD\u65B0\u62A5\u540D"
          );
          ensure(
            !previous || ["cancelled", "rejected"].includes(previous.status),
            409,
            "ALREADY_REGISTERED",
            "\u8BF7\u52FF\u91CD\u590D\u62A5\u540D"
          );
          ensure(
            event.capacity === null || event.occupied < event.capacity,
            409,
            "EVENT_FULL",
            "\u62A5\u540D\u5DF2\u6EE1"
          );
          const m = ctx.member;
          const r = {
            id: registrationId,
            eventId: event.id,
            uid: m.uid,
            snapshot: {
              studentId: m.studentId,
              name: m.name,
              gender: m.gender,
              college: m.college,
              major: m.major,
              className: m.className,
              grade: m.grade
            },
            note: body.note,
            status: event.approvalRequired ? "pending" : "approved",
            registeredAt: this.now(),
            updatedAt: this.now()
          };
          await tx.set("registrations", r.id, r);
          if (!event.registrationIds.includes(r.id))
            event.registrationIds.push(r.id);
          event.occupied++;
          await tx.set("events", event.id, event);
          await this.audit(tx, ctx, "events.register", r.id);
          return { data: r };
        }
        if (action === "registration" && method === "DELETE") {
          ensure(
            event.allowCancellation && this.now() < event.registrationDeadline,
            409,
            "CANCELLATION_CLOSED",
            "\u4E0D\u5141\u8BB8\u53D6\u6D88\u6216\u5DF2\u8D85\u8FC7\u622A\u6B62\u65F6\u95F4"
          );
          const r = await tx.get("registrations", registrationId);
          ensure(
            r && ["pending", "approved"].includes(r.status) && !r.checkedInAt,
            409,
            "CANNOT_CANCEL",
            "\u6B64\u62A5\u540D\u4E0D\u53EF\u53D6\u6D88"
          );
          await tx.set("registrations", r.id, {
            ...r,
            status: "cancelled",
            updatedAt: this.now()
          });
          event.occupied--;
          await tx.set("events", event.id, event);
          await this.audit(tx, ctx, "events.cancel", r.id);
          return { data: { ok: true } };
        }
        if (action === "registrations" && method === "GET") {
          const exporting = parts[3] === "export.xlsx";
          if (exporting) this.scope(ctx, event, "events.registrations.export");
          else
            ensure(
              this.access(ctx, event).roster,
              403,
              "EVENT_SCOPE",
              "\u672A\u83B7\u6B64\u6D3B\u52A8\u62A5\u540D\u540D\u5355\u67E5\u770B\u6388\u6743"
            );
          const page2 = await this.roster(
            event,
            exporting ? { ...q, page: "1", pageSize: "100" } : q
          );
          let rows = page2.items;
          await this.audit(
            tx,
            ctx,
            parts[3] === "export.xlsx" ? "events.registrations.export" : "events.registrations.read",
            event.id
          );
          if (parts[3] === "export.xlsx") {
            ensure(
              page2.total <= 1e4,
              413,
              "EXPORT_LIMIT",
              "\u5BFC\u51FA\u6700\u591A10000\u6761\u8BB0\u5F55\uFF0C\u8BF7\u5148\u6309\u72B6\u6001\u3001\u59D3\u540D\u6216\u5B66\u9662\u7B5B\u9009"
            );
            for (let nextPage = 2; rows.length < page2.total; nextPage++) {
              const next = await this.roster(event, {
                ...q,
                page: String(nextPage),
                pageSize: "100"
              });
              if (!next.items.length) break;
              rows = rows.concat(next.items);
            }
            const statuses = {
              pending: "\u5F85\u5BA1\u6838",
              approved: "\u5DF2\u901A\u8FC7",
              rejected: "\u5DF2\u62D2\u7EDD",
              cancelled: "\u5DF2\u53D6\u6D88",
              manual: "\u4EBA\u5DE5\u8865\u7B7E"
            };
            const binary = await exportWorkbook(
              [
                "\u5E8F\u53F7",
                "\u5B66\u53F7",
                "\u59D3\u540D",
                "\u6027\u522B",
                "\u5B66\u9662",
                "\u4E13\u4E1A",
                "\u73ED\u7EA7",
                "\u5E74\u7EA7",
                "\u5907\u6CE8",
                "\u62A5\u540D\u65F6\u95F4",
                "\u62A5\u540D\u72B6\u6001",
                "\u7B7E\u5230\u72B6\u6001"
              ],
              rows.map((r, i) => [
                String(i + 1),
                r.snapshot.studentId,
                r.snapshot.name,
                r.snapshot.gender,
                r.snapshot.college,
                r.snapshot.major,
                r.snapshot.className,
                r.snapshot.grade,
                r.note,
                new Date(r.registeredAt).toLocaleString("zh-CN", {
                  timeZone: "Asia/Shanghai"
                }),
                statuses[r.status],
                r.checkedInAt ? "\u5DF2\u7B7E\u5230" : "\u672A\u7B7E\u5230"
              ])
            );
            return {
              binary,
              filename: `${[...event.title.replace(/[\\/:*?"<>|\r\n]/g, "_")].slice(0, 48).join("")}-\u62A5\u540D\u7B7E\u5230\u540D\u5355-${new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Shanghai" }).format(new Date(this.clock()))}.xlsx`
            };
          }
          return { data: page2 };
        }
        if (action === "review" && method === "POST") {
          this.scope(ctx, event, "events.registrations.review");
          const body = import_zod9.z.object({
            uid: import_zod9.z.string().uuid(),
            status: import_zod9.z.enum(["approved", "rejected"])
          }).strict().parse(input);
          const r = await tx.get(
            "registrations",
            `${event.id}:${body.uid}`
          );
          ensure(
            r?.status === "pending",
            409,
            "NOT_PENDING",
            "\u6B64\u8BB0\u5F55\u4E0D\u5728\u5F85\u5BA1\u6838\u72B6\u6001"
          );
          if (body.status === "rejected") event.occupied--;
          await tx.set("registrations", r.id, {
            ...r,
            status: body.status,
            reviewedBy: ctx.member.uid,
            updatedAt: this.now()
          });
          await tx.set("events", event.id, event);
          await this.audit(tx, ctx, "events.review", r.id);
          return { data: { ok: true } };
        }
        if (action === "checkin-status" && method === "GET") {
          this.scope(ctx, event, "events.checkin.manage");
          const key2 = await tx.get(
            "system",
            `checkin:${event.id}`
          );
          return {
            data: {
              enabled: event.checkinEnabled && event.status === "published",
              open: !!(event.checkinEnabled && event.status === "published" && event.checkinOpen && key2 && key2.expiresAt > this.clock()),
              expiresAt: key2 && key2.expiresAt > 0 ? new Date(key2.expiresAt).toISOString() : null,
              ttlSeconds: event.checkinTtlSeconds ?? DEFAULT_CHECKIN_TTL_SECONDS
            }
          };
        }
        if (action === "checkin-code" && method === "POST") {
          this.scope(ctx, event, "events.checkin.manage");
          const body = import_zod9.z.object({
            open: import_zod9.z.boolean(),
            ttlSeconds: import_zod9.z.number().int().min(30).max(MAX_CHECKIN_TTL_SECONDS).optional()
          }).strict().parse(input);
          ensure(
            !body.open || event.checkinEnabled && event.status === "published",
            409,
            "CHECKIN_DISABLED",
            "\u6B64\u6D3B\u52A8\u672A\u542F\u7528\u7B7E\u5230"
          );
          const ttlSeconds = body.ttlSeconds ?? event.checkinTtlSeconds ?? DEFAULT_CHECKIN_TTL_SECONDS;
          const code = body.open ? (0, import_node_crypto10.randomBytes)(24).toString("base64url") : null;
          event.checkinOpen = body.open;
          event.checkinTtlSeconds = ttlSeconds;
          event.updatedAt = this.now();
          await tx.set("events", event.id, event);
          await tx.set("system", `checkin:${event.id}`, {
            hash: code ? sha(code) : "",
            expiresAt: body.open ? this.clock() + ttlSeconds * 1e3 : 0
          });
          await this.audit(tx, ctx, "events.checkin_code", event.id);
          return {
            data: {
              code,
              enabled: event.checkinEnabled && event.status === "published",
              ttlSeconds,
              expiresAt: body.open ? new Date(this.clock() + ttlSeconds * 1e3).toISOString() : null,
              open: body.open
            }
          };
        }
        if (action === "checkin" && method === "POST") {
          const body = import_zod9.z.object({ code: import_zod9.z.string().min(1).max(200) }).strict().parse(input), key2 = await tx.get(
            "system",
            `checkin:${event.id}`
          );
          ensure(
            event.status === "published" && event.checkinEnabled && event.checkinOpen && key2 && key2.expiresAt > this.clock() && /^[a-f0-9]{64}$/.test(key2.hash) && (0, import_node_crypto10.timingSafeEqual)(
              Buffer.from(key2.hash, "hex"),
              Buffer.from(sha(body.code), "hex")
            ),
            409,
            "INVALID_CHECKIN_CODE",
            "\u7B7E\u5230\u672A\u5F00\u653E\u6216\u7B7E\u5230\u7801\u5DF2\u5931\u6548"
          );
          const r = await tx.get("registrations", registrationId);
          ensure(
            r?.status === "approved",
            403,
            "REGISTRATION_REQUIRED",
            "\u4EC5\u5DF2\u901A\u8FC7\u62A5\u540D\u7684\u6210\u5458\u53EF\u7B7E\u5230"
          );
          if (!r.checkedInAt) {
            const checked = {
              ...r,
              checkedInAt: this.now(),
              checkinMethod: "code"
            };
            await tx.set("registrations", r.id, checked);
            await tx.set("checkins", r.id, {
              id: r.id,
              eventId: event.id,
              uid: r.uid,
              checkedInAt: checked.checkedInAt,
              method: "code"
            });
            await this.audit(tx, ctx, "events.checkin", r.id);
          }
          return { data: { ok: true } };
        }
        if (action === "manual-checkin" && method === "POST") {
          ensure(
            event.checkinEnabled && event.status === "published",
            409,
            "CHECKIN_DISABLED",
            "\u6B64\u6D3B\u52A8\u672A\u542F\u7528\u7B7E\u5230"
          );
          this.scope(ctx, event, "events.checkin.manage");
          const body = import_zod9.z.object({
            uid: import_zod9.z.string().uuid(),
            reason: import_zod9.z.string().trim().min(1).max(500)
          }).strict().parse(input);
          const rid = `${event.id}:${body.uid}`;
          const member = await tx.get("users", body.uid);
          ensure(
            member?.status === "active",
            400,
            "INVALID_MEMBER",
            "\u8865\u7B7E\u5BF9\u8C61\u987B\u4E3A\u6709\u6548\u6210\u5458"
          );
          let existing = await tx.get("registrations", rid);
          if (!existing) {
            const m = await tx.get("users", body.uid);
            ensure(
              m?.status === "active",
              400,
              "INVALID_MEMBER",
              "\u8865\u7B7E\u5BF9\u8C61\u987B\u4E3A\u6709\u6548\u6210\u5458"
            );
            existing = {
              id: rid,
              eventId: event.id,
              uid: m.uid,
              snapshot: {
                studentId: m.studentId,
                name: m.name,
                gender: m.gender,
                college: m.college,
                major: m.major,
                className: m.className,
                grade: m.grade
              },
              note: "\u7BA1\u7406\u5458\u8865\u7B7E\uFF1A" + body.reason,
              status: "manual",
              registeredAt: this.now(),
              updatedAt: this.now()
            };
            event.registrationIds.push(rid);
            await tx.set("events", event.id, event);
          }
          if (!existing.checkedInAt) {
            await tx.set("registrations", rid, {
              ...existing,
              status: existing.status === "pending" ? "approved" : ["cancelled", "rejected"].includes(existing.status) ? "manual" : existing.status,
              checkedInAt: this.now(),
              checkinMethod: "manual",
              ...existing.status === "pending" ? { reviewedBy: ctx.member.uid } : {},
              updatedAt: this.now()
            });
            await tx.set("checkins", rid, {
              id: rid,
              eventId: event.id,
              uid: body.uid,
              checkedInAt: this.now(),
              method: "manual",
              reason: body.reason,
              actor: ctx.member.uid
            });
            await this.audit(tx, ctx, "events.manual_checkin", rid);
          }
          return { data: { ok: true } };
        }
      }
      if (kind === "articles") {
        if (!id && method === "GET") {
          ensure(
            [
              "articles.create",
              "articles.edit",
              "articles.publish",
              "articles.delete"
            ].some((p) => this.can(ctx, p)),
            403,
            "FORBIDDEN",
            "\u6CA1\u6709\u6587\u7AE0\u6743\u9650"
          );
          return {
            data: await this.page(
              (await Promise.all(
                cat.articles.map(
                  (id2) => this.content(tx, "articles", id2)
                )
              )).filter(
                (v) => v && v.status !== "deleted" && (!q.search || v.title.includes(q.search)) && (!q.status || v.status === q.status) && (!q.category || v.category === q.category) && (this.can(ctx, "articles.edit") || this.can(ctx, "articles.publish") || this.can(ctx, "articles.delete") || v.publisherUid === ctx.member.uid)
              ),
              q
            )
          };
        }
        const previous = id ? await this.content(tx, "articles", id) : null;
        if (id)
          ensure(
            previous && previous.status !== "deleted",
            404,
            "NOT_FOUND",
            "\u6587\u7AE0\u4E0D\u5B58\u5728"
          );
        if (action === "publish" && method === "POST") {
          this.require(ctx, "articles.publish");
          const body = import_zod9.z.object({ publish: import_zod9.z.boolean() }).strict().parse(input);
          const next = {
            ...previous,
            status: body.publish ? "published" : "withdrawn",
            publishedAt: previous.publishedAt ?? (body.publish ? this.now() : null),
            updatedAt: this.now()
          };
          await tx.set("articles", id, next);
          await this.audit(tx, ctx, "articles.publish", id);
          return { data: next };
        }
        if (method === "DELETE") {
          this.require(ctx, "articles.delete");
          await tx.set("articles", id, {
            ...previous,
            status: "deleted",
            updatedAt: this.now()
          });
          await this.audit(tx, ctx, "articles.delete", id);
          return { data: { ok: true } };
        }
        if (method === "GET") {
          ensure(
            this.can(ctx, "articles.edit") || this.can(ctx, "articles.publish") || this.can(ctx, "articles.delete") || this.can(ctx, "articles.create") && previous?.publisherUid === ctx.member.uid,
            403,
            "FORBIDDEN",
            "\u6CA1\u6709\u6587\u7AE0\u67E5\u770B\u6743\u9650"
          );
          return { data: previous };
        }
        if (method === "POST" || method === "PATCH") {
          this.require(ctx, previous ? "articles.edit" : "articles.create");
          const body = articleSchema.parse(
            previous ? {
              ...Object.fromEntries(
                Object.keys(articleSchema.shape).map((key2) => [
                  key2,
                  previous[key2]
                ])
              ),
              ...import_zod9.z.record(import_zod9.z.string(), import_zod9.z.unknown()).parse(input)
            } : input
          );
          if (body.status === "published" || previous?.status === "published")
            this.require(ctx, "articles.publish");
          const article = {
            ...body,
            id: previous?.id ?? (0, import_node_crypto10.randomUUID)(),
            publisherUid: previous?.publisherUid ?? ctx.member.uid,
            publisherName: previous?.publisherName ?? ctx.member.nickname,
            publishedAt: previous?.publishedAt ?? (body.status === "published" ? this.now() : null),
            createdAt: previous?.createdAt ?? this.now(),
            updatedAt: this.now()
          };
          await syncMedia(
            tx,
            ctx,
            "articles",
            article.id,
            references(article.content, article.cover),
            references(previous?.content, previous?.cover)
          );
          await tx.set("articles", article.id, article);
          if (!previous) {
            cat.articles.push(article.id);
            await tx.set("system", "stage3_catalog", cat);
          }
          await this.audit(tx, ctx, "articles.save", article.id);
          return { data: article };
        }
      }
      if (kind === "popups") {
        this.require(ctx, "announcements.popup.manage");
        if (method === "GET") {
          const current = await this.popup(tx);
          return {
            data: {
              current,
              items: (await Promise.all(
                cat.popups.map(
                  (id2) => tx.get("popup_announcements", id2)
                )
              )).filter(Boolean)
            }
          };
        }
        if (method === "POST") {
          const body = popupSchema.parse(input), target = await this.content(
            tx,
            body.targetType === "event" ? "events" : "articles",
            body.targetId
          );
          ensure(
            target?.status === "published",
            400,
            "UNPUBLISHED_TARGET",
            "\u8BF7\u5148\u53D1\u5E03\u5173\u8054\u5185\u5BB9"
          );
          const item = {
            ...body,
            id: (0, import_node_crypto10.randomUUID)(),
            version: (0, import_node_crypto10.randomUUID)(),
            enabled: true,
            state: "scheduled",
            createdAt: this.now(),
            updatedAt: this.now()
          };
          if (item.startsAt <= this.now()) await this.retireDue(tx, cat);
          cat.popups.push(item.id);
          await syncMedia(
            tx,
            ctx,
            "popup_announcements",
            item.id,
            references("", item.image),
            [],
            references("", target.cover)
          );
          await tx.set("popup_announcements", item.id, item);
          await tx.set("system", "stage3_catalog", cat);
          await this.popup(tx);
          await this.audit(tx, ctx, "popups.create", item.id);
          return {
            data: await tx.get(
              "popup_announcements",
              item.id
            )
          };
        }
        if (id && method === "PATCH") {
          const old = await tx.get("popup_announcements", id);
          ensure(old, 404, "NOT_FOUND", "\u5F39\u7A97\u4E0D\u5B58\u5728");
          const body = import_zod9.z.object({ enabled: import_zod9.z.boolean() }).strict().parse(input);
          if (body.enabled) {
            ensure(
              old.expiresAt > this.now(),
              409,
              "POPUP_EXPIRED",
              "\u516C\u544A\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u53D1\u5E03\u65B0\u7248\u672C"
            );
            if (old.startsAt <= this.now()) await this.retireDue(tx, cat, id);
          }
          await tx.set("popup_announcements", id, {
            ...old,
            enabled: body.enabled,
            state: body.enabled ? "scheduled" : "disabled",
            version: (0, import_node_crypto10.randomUUID)(),
            createdAt: this.now(),
            updatedAt: this.now()
          });
          await this.popup(tx);
          await this.audit(tx, ctx, "popups.toggle", id);
          return { data: { ok: true } };
        }
      }
      throw new ApiError(404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
    };
    return publicRead ? this.store.run((tx) => work(tx)) : this.secure(token, (tx, ctx) => work(tx, ctx));
  }
};

// src/members/service.ts
var import_node_crypto11 = require("node:crypto");
var import_zod10 = require("zod");
var failure = (status, code, message) => ({
  status,
  error: { code, message }
});
var MemberService = class {
  constructor(store, clock = () => Date.now(), resourceProvider, publicStorage = new QiniuPublicSiteStorage()) {
    this.store = store;
    this.clock = clock;
    this.resourceProvider = resourceProvider;
    this.publicStorage = publicStorage;
    this.publicCache = new PublicReadCache(clock);
    this.publisher = new PublicSitePublisher(
      store,
      (path) => this.executeUncached("", "GET", path, {}, {}),
      publicStorage,
      resourceProvider,
      clock
    );
  }
  publicCache;
  publisher;
  now() {
    return new Date(this.clock()).toISOString();
  }
  async control(tx, mutate = true) {
    const control = await tx.get("system", "control");
    ensure(control?.initialized, 503, "NOT_INITIALIZED", "\u6210\u5458\u7CFB\u7EDF\u5C1A\u672A\u521D\u59CB\u5316");
    if (mutate) {
      control.revision++;
      await tx.set("system", "control", control);
    }
    return control;
  }
  async audit(tx, actor2, action, target, fields = [], login) {
    const id = (0, import_node_crypto11.randomUUID)();
    const log = {
      id,
      actor: actor2,
      action,
      target,
      fields,
      createdAt: this.now(),
      ...login ? { login } : {}
    };
    await tx.set("audit_logs", id, log);
  }
  async identity(tx, user) {
    const roles = await Promise.all(
      user.roleIds.map((id) => tx.get("roles", id))
    );
    const permissions = [
      ...new Set(roles.flatMap((role) => role?.permissionIds ?? []))
    ];
    return {
      roles: roles.flatMap(
        (role) => role ? [{ id: role.id, name: role.name }] : []
      ),
      member: user,
      permissions,
      super: roles.some((role) => role?.super === true)
    };
  }
  require(ctx, permission) {
    ensure(
      ctx.super || ctx.permissions.includes(permission),
      403,
      "FORBIDDEN",
      "\u6CA1\u6709\u6267\u884C\u6B64\u64CD\u4F5C\u7684\u6743\u9650"
    );
  }
  async authenticate(tx, token, control, allowActivation = false) {
    ensure(token, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
    const sessionId = digest(token);
    const session = await tx.get("sessions", sessionId);
    ensure(
      session && session.expiresAt > this.clock() && session.idleExpiresAt > this.clock(),
      401,
      "SESSION_EXPIRED",
      "\u4F1A\u8BDD\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55"
    );
    const user = await tx.get("users", session.uid);
    ensure(
      user && user.status === "active" && user.version === session.version,
      401,
      "SESSION_REVOKED",
      "\u8D26\u53F7\u6216\u4F1A\u8BDD\u5DF2\u5931\u6548"
    );
    ensure(
      !user.mustChangePassword || allowActivation,
      403,
      "PASSWORD_CHANGE_REQUIRED",
      "\u8BF7\u5148\u4FEE\u6539\u521D\u59CB\u5BC6\u7801"
    );
    if (user.mustChangePassword)
      ensure(
        Date.parse(user.activationExpiresAt) > this.clock(),
        401,
        "ACTIVATION_EXPIRED",
        "\u6FC0\u6D3B\u51ED\u636E\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u91CD\u7F6E"
      );
    const idleExpiresAt = Math.min(
      session.expiresAt,
      this.clock() + 30 * 6e4
    );
    if (idleExpiresAt - session.idleExpiresAt >= 6e4) {
      session.idleExpiresAt = idleExpiresAt;
      await tx.set("sessions", sessionId, session);
    }
    return { ...await this.identity(tx, user), control, sessionId };
  }
  async secure(token, fn, activation = false, publicMutation = false) {
    return this.store.run(async (tx) => {
      const control = await this.control(tx, false);
      const ctx = await this.authenticate(tx, token, control, activation);
      let mutated = false;
      const tracked = {
        get: (collection, id) => tx.get(collection, id),
        set: async (collection, id, value) => {
          mutated = true;
          await tx.set(collection, id, value);
        },
        remove: async (collection, id) => {
          mutated = true;
          await tx.remove(collection, id);
        }
      };
      const result = await fn(tracked, ctx);
      if (mutated) {
        if (publicMutation) await markPublicDirty(tx);
        control.revision++;
        await tx.set("system", "control", control);
      }
      return result;
    });
  }
  async manageable(tx, ctx, user) {
    const identity = await this.identity(tx, user);
    ensure(
      ctx.super || !identity.super && identity.permissions.every((p) => ctx.permissions.includes(p)),
      403,
      "SCOPE_EXCEEDED",
      "\u4E0D\u80FD\u7BA1\u7406\u6743\u9650\u9AD8\u4E8E\u81EA\u8EAB\u7684\u6210\u5458"
    );
  }
  async adjustRoles(tx, user, newIds) {
    for (const id of /* @__PURE__ */ new Set([...user.roleIds, ...newIds])) {
      const role = await tx.get("roles", id);
      ensure(role, 400, "INVALID_ROLE", "\u89D2\u8272\u4E0D\u5B58\u5728");
      role.memberCount += Number(newIds.includes(id)) - Number(user.roleIds.includes(id));
      await tx.set("roles", id, role);
    }
  }
  async protectLast(tx, ctx, user, changes) {
    const was = (await this.identity(tx, user)).super && user.status === "active";
    const next = { ...user, ...changes };
    const will = (await this.identity(tx, next)).super && next.status === "active";
    const count = ctx.control.superAdminCount + Number(will) - Number(was);
    ensure(
      count >= 1,
      409,
      "LAST_SUPER_ADMIN",
      "\u4E0D\u80FD\u5220\u9664\u3001\u7981\u7528\u6216\u964D\u7EA7\u6700\u540E\u4E00\u4E2A\u8D85\u7EA7\u7BA1\u7406\u5458"
    );
    ctx.control.superAdminCount = count;
    await tx.set("system", "control", ctx.control);
  }
  async createMember(tx, input, actor2, password = "123456", roleIds = ["role_member"], mustChangePassword = true) {
    const data = memberSchema.parse(input);
    ensure(
      !await tx.get("student_ids", studentIdKey(data.studentId)),
      409,
      "STUDENT_ID_EXISTS",
      "\u5B66\u53F7\u5DF2\u5B58\u5728\uFF08\u5305\u62EC\u8F6F\u5220\u9664\u8D26\u53F7\uFF09"
    );
    const uid = (0, import_node_crypto11.randomUUID)();
    const now = this.now();
    const user = {
      ...data,
      uid,
      nickname: data.nickname ?? data.name,
      roleIds,
      status: "active",
      mustChangePassword,
      createdAt: now,
      updatedAt: now,
      version: 1,
      activationExpiresAt: new Date(this.clock() + 7 * 864e5).toISOString()
    };
    await this.adjustRoles(tx, { ...user, roleIds: [] }, roleIds);
    await tx.set("users", uid, user);
    await tx.set("student_ids", studentIdKey(data.studentId), { uid });
    await tx.set("credentials", uid, { hash: await hashPassword(password) });
    await this.audit(tx, actor2, "members.create", uid, Object.keys(data));
    return user;
  }
  async bootstrap(input, password) {
    const data = memberSchema.parse(input);
    passwordSchema.parse(password);
    return this.store.run(async (tx) => {
      ensure(
        !await tx.get("system", "control"),
        409,
        "ALREADY_INITIALIZED",
        "\u521D\u59CB\u5316\u5DF2\u5B8C\u6210\uFF0C\u62D2\u7EDD\u91CD\u590D\u521D\u59CB\u5316"
      );
      const now = this.now();
      for (const permission of permissionDefinitions)
        await tx.set("permissions", permission.id, {
          ...permission,
          createdAt: now
        });
      const names = [
        "\u8D85\u7EA7\u7BA1\u7406\u5458",
        "\u7BA1\u7406\u5458",
        "\u4F1A\u957F",
        "\u526F\u4F1A\u957F",
        "\u90E8\u957F",
        "\u526F\u90E8\u957F",
        "\u666E\u901A\u6210\u5458"
      ];
      const ids = [
        "role_super",
        "role_admin",
        "role_president",
        "role_vice_president",
        "role_head",
        "role_vice_head",
        "role_member"
      ];
      for (let i = 0; i < ids.length; i++) {
        const role = {
          id: ids[i],
          name: names[i],
          description: "\u521D\u59CB\u89D2\u8272\uFF1B\u793E\u56E2\u804C\u4F4D\u53E6\u5B58\u4E8E\u6210\u5458 position \u5B57\u6BB5",
          permissionIds: i === 0 ? permissionDefinitions.map((p) => p.id) : i === 1 ? permissionDefinitions.filter(
            (p) => p.implemented && !["security.logins.read", "members.purge"].includes(
              p.id
            )
          ).map((p) => p.id) : [],
          memberCount: 0,
          builtin: true,
          super: i === 0,
          createdAt: now
        };
        await tx.set("roles", role.id, role);
      }
      const user = await this.createMember(
        tx,
        data,
        "bootstrap",
        password,
        ["role_super"],
        false
      );
      await tx.set("system", "control", {
        initialized: true,
        superAdminCount: 1,
        revision: 1
      });
      await this.audit(tx, "bootstrap", "system.initialize", user.uid);
      return user;
    });
  }
  async login(input, source) {
    const context = safeLoginContext(source);
    const ip2 = context.ip ?? (typeof source === "string" ? source : "gateway-unavailable");
    const body = import_zod10.z.object({
      studentId: studentIdSchema,
      password: import_zod10.z.string().min(1).max(128)
    }).strict().parse(input);
    return this.store.run(async (tx) => {
      await this.control(tx);
      for (const [key2, limit] of [
        [`account:${body.studentId}`, 10],
        [`ip:${ip2}`, 200]
      ]) {
        const id = digest(key2);
        let rate = await tx.get("login_limits", id);
        if (!rate || rate.until <= this.clock())
          rate = { count: 0, until: this.clock() + 15 * 6e4 };
        if (rate.count >= limit) {
          if (!rate.reported) {
            await this.audit(
              tx,
              "anonymous",
              "auth.login_blocked",
              "redacted",
              [],
              {
                ...context,
                memberUid: null,
                outcome: "blocked",
                reason: "RATE_LIMITED"
              }
            );
            await tx.set("login_limits", id, {
              ...rate,
              reported: true,
              createdAt: this.now()
            });
          }
          return failure(
            429,
            "RATE_LIMITED",
            "\u767B\u5F55\u5C1D\u8BD5\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF715\u5206\u949F\u540E\u518D\u8BD5"
          );
        }
        rate.count++;
        await tx.set("login_limits", id, { ...rate, createdAt: this.now() });
      }
      const mapping = await tx.get(
        "student_ids",
        studentIdKey(body.studentId)
      );
      const user = mapping ? await tx.get("users", mapping.uid) : null;
      const credential = user ? await tx.get("credentials", user.uid) : null;
      const valid = await verifyPassword(body.password, credential?.hash ?? "");
      if (!user || user.status !== "active" || !valid) {
        await this.audit(tx, "anonymous", "auth.login_failed", "redacted", [], {
          ...context,
          memberUid: user?.uid ?? null,
          outcome: "failure",
          reason: "INVALID_CREDENTIALS"
        });
        return failure(401, "INVALID_CREDENTIALS", "\u5B66\u53F7\u3001\u5BC6\u7801\u9519\u8BEF\u6216\u8D26\u53F7\u4E0D\u53EF\u7528");
      }
      if (user.mustChangePassword && Date.parse(user.activationExpiresAt) <= this.clock()) {
        await this.audit(
          tx,
          "anonymous",
          "auth.login_blocked",
          "redacted",
          [],
          {
            ...context,
            memberUid: user.uid,
            outcome: "blocked",
            reason: "ACTIVATION_EXPIRED"
          }
        );
        return failure(
          401,
          "ACTIVATION_EXPIRED",
          "\u521D\u59CB\u51ED\u636E\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u91CD\u7F6E"
        );
      }
      await tx.set("login_limits", digest(`account:${body.studentId}`), {
        count: 0,
        until: this.clock() + 15 * 6e4,
        createdAt: this.now()
      });
      const token = randomToken();
      const expiresAt = this.clock() + (user.mustChangePassword ? 15 * 6e4 : 8 * 36e5);
      await tx.set("sessions", digest(token), {
        createdAt: this.now(),
        uid: user.uid,
        version: user.version,
        expiresAt,
        idleExpiresAt: Math.min(expiresAt, this.clock() + 30 * 6e4)
      });
      await this.audit(tx, user.uid, "auth.login", user.uid, [], {
        ...context,
        memberUid: user.uid,
        outcome: "success",
        reason: ""
      });
      return { data: await this.identity(tx, user), token };
    });
  }
  async authorize(token, permission) {
    return this.secure(token, async (_tx, ctx) => this.require(ctx, permission));
  }
  async prepareImport(token, input) {
    const body = import_zod10.z.object({ file: import_zod10.z.string().min(1).max(3e6) }).strict().parse(input);
    await this.secure(
      token,
      async (_tx, ctx) => this.require(ctx, "members.import")
    );
    const file = Buffer.from(body.file, "base64");
    const hash = digest(file.toString("base64"));
    const rows = await parseWorkbook(file);
    for (let start = 0; start < rows.length; start += 20)
      await Promise.all(
        rows.slice(start, start + 20).map(async (row) => {
          if (row.member && !row.error && await this.store.read(
            "student_ids",
            studentIdKey(row.member.studentId)
          ))
            row.error = "\u5B66\u53F7\u5DF2\u5B58\u5728\uFF08\u5305\u62EC\u8F6F\u5220\u9664\u8D26\u53F7\uFF09";
        })
      );
    ensure(
      Buffer.byteLength(JSON.stringify(rows)) <= 7e5,
      413,
      "IMPORT_TOO_LARGE",
      "\u89E3\u6790\u540E\u6570\u636E\u8FC7\u5927\uFF0C\u8BF7\u62C6\u5206\u6587\u4EF6"
    );
    return this.secure(token, async (tx, ctx) => {
      this.require(ctx, "members.import");
      const existing = await tx.get("import_jobs", hash);
      if (existing) {
        ensure(
          existing.owner === ctx.member.uid || ctx.super,
          403,
          "FORBIDDEN",
          "\u8BE5\u6587\u4EF6\u5DF2\u7531\u5176\u4ED6\u7BA1\u7406\u5458\u5BFC\u5165"
        );
        return { data: existing };
      }
      const job = {
        id: hash,
        hash,
        owner: ctx.member.uid,
        rows,
        offset: 0,
        created: 0,
        skipped: 0,
        status: "preview",
        createdAt: this.now(),
        updatedAt: this.now()
      };
      await tx.set("import_jobs", hash, job);
      await this.audit(tx, ctx.member.uid, "imports.preview", hash);
      return { data: job };
    });
  }
  async execute(token, method, path, input, query) {
    if (process.env.PUBLIC_SITE_MODE === "qiniu" && method === "GET") {
      if (isPublicSitePath(path, query)) return publicSiteResponse(this.publicStorage, path, query, this.clock());
      if (isPublicSitePath(path, {}) && query.live !== "true" && query.admin !== "true")
        throw new ApiError(400, "INVALID_INPUT", "\u516C\u5F00\u67E5\u8BE2\u53C2\u6570\u65E0\u6548");
      if (path.startsWith("/api/public/") && !isPublicSitePath(path, {}))
        throw new ApiError(404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
      ensure(token, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
      if (query.live === "true") {
        ensure(token, 401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
        await this.secure(token, async () => void 0);
      }
    }
    const key2 = publicReadKey(method, path, query);
    if (key2) {
      return this.publicCache.load(
        key2,
        6e4,
        () => this.executeUncached(token, method, path, input, query)
      );
    }
    if (method === "GET")
      return this.executeUncached(token, method, path, input, query);
    this.publicCache.clear();
    try {
      const result = await this.executeUncached(token, method, path, input, query);
      if (!result.error && (process.env.PUBLIC_SITE_MODE === "qiniu" || process.env.PUBLIC_SITE_ORIGIN) && changesPublicContent(path)) {
        try {
          result.publicSync = await this.publisher.sync();
        } catch {
          result.publicSync = "failed";
        }
      }
      return result;
    } finally {
      this.publicCache.clear();
    }
  }
  async executeUncached(token, method, path, input, query) {
    const publicMutation = method !== "GET" && Boolean(process.env.PUBLIC_SITE_MODE === "qiniu" || process.env.PUBLIC_SITE_ORIGIN) && changesPublicContent(path);
    if (path === "/api/public-site/status" && method === "GET") {
      await this.secure(token, async (_tx, ctx) => ensure(ctx.super, 403, "FORBIDDEN", "\u4EC5\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u7BA1\u7406\u516C\u5F00\u53D1\u5E03"));
      return { data: await this.publisher.status() };
    }
    if (path === "/api/public-site/rebuild" && method === "POST") {
      await this.secure(token, async (tx, ctx) => {
        ensure(ctx.super, 403, "FORBIDDEN", "\u4EC5\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u7BA1\u7406\u516C\u5F00\u53D1\u5E03");
        await this.audit(tx, ctx.member.uid, "public-site.rebuild", "public-site");
      });
      const state = await this.publisher.sync();
      return { data: { state }, publicSync: state };
    }
    if (/^\/api\/resources(?:\/|$)/.test(path))
      return new ResourceService(
        this.store,
        (token2, fn) => this.secure(token2, fn, false, publicMutation),
        this.clock,
        this.resourceProvider
      ).execute(token, method, path, input, query);
    if (/^\/api\/media(?:\/|$)/.test(path))
      return new MediaService(
        this.store,
        (token2, fn) => this.secure(token2, fn, false, publicMutation),
        this.clock
      ).execute(token, method, path, input);
    if (/^\/api\/forum(?:\/|$)/.test(path))
      return new ForumService(
        this.store,
        (token2, fn) => this.secure(token2, fn, false, publicMutation),
        this.clock
      ).execute(token, method, path, input, query);
    if (/^\/api\/(?:public|events|articles|popups)(?:\/|$)/.test(path))
      return new Stage3Service(
        this.store,
        (token2, fn) => this.secure(token2, fn, false, publicMutation),
        this.clock
      ).execute(token, method, path, input, query);
    if (method === "POST" && path === "/api/imports/preview")
      return this.prepareImport(token, input);
    return this.secure(
      token,
      async (tx, ctx) => {
        const user = ctx.member;
        if (path === "/api/members/stats" && method === "GET") {
          ensure(
            ctx.super || ctx.permissions.includes("members.read") || ctx.permissions.includes("security.logins.read"),
            403,
            "FORBIDDEN",
            "\u6CA1\u6709\u6210\u5458\u7EDF\u8BA1\u67E5\u770B\u6743\u9650"
          );
          import_zod10.z.object({}).strict().parse(query);
          const result = await this.store.list(
            "member_stats",
            {},
            { offset: 0, limit: 1 }
          );
          return { data: { ...result.items[0], asOf: this.now() } };
        }
        if (path === "/api/auth/me" && method === "GET")
          return {
            data: {
              member: user,
              roles: ctx.roles,
              permissions: ctx.permissions,
              super: ctx.super
            }
          };
        if (path === "/api/auth/logout" && method === "POST") {
          await tx.remove("sessions", ctx.sessionId);
          await this.audit(tx, user.uid, "auth.logout", user.uid);
          return { data: { ok: true }, clearCookie: true };
        }
        if (path === "/api/auth/password" && method === "POST") {
          const body = import_zod10.z.object({
            oldPassword: import_zod10.z.string().max(128),
            newPassword: passwordSchema
          }).strict().parse(input);
          const credential = await tx.get("credentials", user.uid);
          ensure(
            credential && await verifyPassword(body.oldPassword, credential.hash),
            400,
            "WRONG_PASSWORD",
            "\u539F\u5BC6\u7801\u9519\u8BEF"
          );
          ensure(
            body.oldPassword !== body.newPassword,
            400,
            "PASSWORD_UNCHANGED",
            "\u65B0\u5BC6\u7801\u4E0D\u80FD\u4E0E\u539F\u5BC6\u7801\u76F8\u540C"
          );
          await tx.set("credentials", user.uid, {
            hash: await hashPassword(body.newPassword)
          });
          await tx.set("users", user.uid, {
            ...user,
            mustChangePassword: false,
            version: user.version + 1,
            updatedAt: this.now()
          });
          await this.audit(tx, user.uid, "auth.password_change", user.uid);
          return { data: { ok: true }, clearCookie: true };
        }
        if (path === "/api/auth/revoke-sessions" && method === "POST") {
          await tx.set("users", user.uid, {
            ...user,
            version: user.version + 1,
            updatedAt: this.now()
          });
          await this.audit(tx, user.uid, "auth.revoke_all", user.uid);
          return { data: { ok: true }, clearCookie: true };
        }
        if (path === "/api/profile" && method === "PATCH") {
          const changes = profileSchema.parse(input);
          const next = { ...user, ...changes, updatedAt: this.now() };
          await tx.set("users", user.uid, next);
          await this.audit(
            tx,
            user.uid,
            "members.profile",
            user.uid,
            Object.keys(changes)
          );
          return { data: next };
        }
        if (path === "/api/members" && method === "GET") {
          this.require(ctx, "members.read");
          const options = listSchema.parse(query);
          const filter = {};
          if (options.status === "all") filter._notDeleted = true;
          else filter.status = options.status;
          if (options.search) filter._search = options.search;
          for (const key2 of ["college", "className"])
            if (options[key2]) filter[key2] = options[key2];
          if (options.roleId) filter.roleIds = options.roleId;
          const result = await this.store.list("users", filter, {
            offset: (options.page - 1) * options.pageSize,
            limit: options.pageSize
          });
          return {
            data: { ...result, page: options.page, pageSize: options.pageSize }
          };
        }
        if (path === "/api/members" && method === "POST") {
          this.require(ctx, "members.create");
          return { data: await this.createMember(tx, input, user.uid) };
        }
        if (path === "/api/members/export" && method === "GET") {
          this.require(ctx, "members.export");
          this.require(ctx, "members.read");
          const options = import_zod10.z.object({
            page: import_zod10.z.coerce.number().int().min(1).max(1e4).default(1)
          }).strict().parse(query);
          const result = await this.store.list(
            "users",
            { _notDeleted: true },
            { offset: (options.page - 1) * 100, limit: 100 }
          );
          await this.audit(tx, user.uid, "members.export", "users", [
            `page:${options.page}`
          ]);
          return { data: { ...result, page: options.page, pageSize: 100 } };
        }
        const memberMatch = path.match(
          /^\/api\/members\/([a-zA-Z0-9-]+)(?:\/(roles|password|status|restore|anonymize|purge))?$/
        );
        if (memberMatch) {
          const id = memberMatch[1];
          const action = memberMatch[2];
          const target = await tx.get("users", id);
          ensure(target, 404, "NOT_FOUND", "\u6210\u5458\u4E0D\u5B58\u5728");
          if (!action && method === "GET") {
            this.require(ctx, "members.read");
            return { data: target };
          }
          const required = action === "purge" ? "members.purge" : action === "roles" ? "roles.assign" : action === "password" ? "members.password" : action === "status" ? "members.status" : action === "restore" || action === "anonymize" || method === "DELETE" ? "members.delete" : "members.edit";
          this.require(ctx, required);
          await this.manageable(tx, ctx, target);
          if (action === "purge" && method === "POST") {
            const body = import_zod10.z.object({ confirmUid: import_zod10.z.string().uuid() }).strict().parse(input);
            ensure(
              body.confirmUid === id,
              400,
              "PURGE_CONFIRMATION",
              "\u5220\u9664\u786E\u8BA4\u4E0E\u76EE\u6807\u6210\u5458\u4E0D\u4E00\u81F4"
            );
            ensure(
              id !== user.uid,
              409,
              "PURGE_SELF",
              "\u4E0D\u80FD\u5F7B\u5E95\u5220\u9664\u5F53\u524D\u767B\u5F55\u8D26\u53F7"
            );
            ensure(
              target.status === "deleted",
              409,
              "PURGE_NOT_DELETED",
              "\u8BF7\u5148\u8F6F\u5220\u9664\u6210\u5458\uFF0C\u518D\u6267\u884C\u5F7B\u5E95\u5220\u9664"
            );
            ensure(
              !(await this.identity(tx, target)).super,
              409,
              "PURGE_SUPER_ADMIN",
              "\u8D85\u7EA7\u7BA1\u7406\u5458\u8D26\u53F7\u4E0D\u80FD\u5F7B\u5E95\u5220\u9664"
            );
            ensure(
              await tx.get("system", "member_purge"),
              503,
              "PURGE_MIGRATION_REQUIRED",
              "\u8BF7\u5148\u6267\u884C014-member-purge.sql\u6570\u636E\u5E93\u5347\u7EA7"
            );
            await this.protectLast(tx, ctx, target, { status: "deleted" });
            await this.adjustRoles(tx, target, []);
            await tx.remove("users", id);
            await this.audit(tx, user.uid, "members.purge", id, [
              "account",
              "credentials",
              "sessions",
              "studentId",
              "importPersonalData",
              "loginMetadata"
            ]);
            return { data: { uid: id, deleted: true } };
          }
          let next = { ...target, updatedAt: this.now() };
          let fields = [];
          if (!action && method === "PATCH") {
            ensure(target.status !== "deleted", 409, "DELETED", "\u8BF7\u5148\u6062\u590D\u6210\u5458");
            const changes = editSchema.parse(input);
            fields = Object.keys(changes);
            if (changes.studentId && changes.studentId !== target.studentId) {
              ensure(
                !await tx.get("student_ids", studentIdKey(changes.studentId)),
                409,
                "STUDENT_ID_EXISTS",
                "\u5B66\u53F7\u5DF2\u5B58\u5728"
              );
              await tx.remove("student_ids", studentIdKey(target.studentId));
              await tx.set("student_ids", studentIdKey(changes.studentId), {
                uid: id
              });
              next.version++;
            }
            next = { ...next, ...changes };
          } else if (action === "roles" && method === "PUT") {
            ensure(target.status !== "deleted", 409, "DELETED", "\u8BF7\u5148\u6062\u590D\u6210\u5458");
            const body = import_zod10.z.object({
              roleIds: import_zod10.z.array(import_zod10.z.string().min(1).max(64)).min(1).max(10)
            }).strict().parse(input);
            const roleIds = [...new Set(body.roleIds)];
            for (const roleId of roleIds) {
              const role = await tx.get("roles", roleId);
              ensure(role, 400, "INVALID_ROLE", "\u89D2\u8272\u4E0D\u5B58\u5728");
              ensure(
                ctx.super || !role.super && role.permissionIds.every(
                  (p) => ctx.permissions.includes(p)
                ),
                403,
                "SCOPE_EXCEEDED",
                "\u4E0D\u80FD\u5206\u914D\u8D85\u51FA\u81EA\u8EAB\u6743\u9650\u7684\u89D2\u8272"
              );
            }
            await this.protectLast(tx, ctx, target, { roleIds });
            await this.adjustRoles(tx, target, roleIds);
            next.roleIds = roleIds;
            next.version++;
            fields = ["roleIds"];
          } else if (action === "password" && method === "POST") {
            import_zod10.z.object({}).strict().parse(input);
            ensure(target.status !== "deleted", 409, "DELETED", "\u8BF7\u5148\u6062\u590D\u6210\u5458");
            await tx.set("credentials", id, {
              hash: await hashPassword("123456")
            });
            next.mustChangePassword = true;
            next.activationExpiresAt = new Date(
              this.clock() + 7 * 864e5
            ).toISOString();
            next.version++;
            fields = ["credentials"];
          } else if (action === "status" && method === "PATCH") {
            const body = import_zod10.z.object({ status: import_zod10.z.enum(["active", "disabled"]) }).strict().parse(input);
            ensure(
              target.status !== "deleted",
              409,
              "DELETED",
              "\u8BF7\u4F7F\u7528\u6062\u590D\u64CD\u4F5C"
            );
            await this.protectLast(tx, ctx, target, body);
            next.status = body.status;
            next.version++;
            fields = ["status"];
          } else if (action === "restore" && method === "POST") {
            ensure(
              target.status === "deleted" && !target.anonymizedAt,
              409,
              "NOT_RESTORABLE",
              "\u8D26\u53F7\u4E0D\u53EF\u6062\u590D"
            );
            next.status = "disabled";
            delete next.deletedAt;
            next.version++;
            fields = ["status"];
          } else if (!action && method === "DELETE") {
            await this.protectLast(tx, ctx, target, { status: "deleted" });
            next.status = "deleted";
            next.deletedAt = this.now();
            next.version++;
            fields = ["status", "deletedAt"];
          } else if (action === "anonymize" && method === "POST") {
            ensure(
              ctx.super && target.status === "deleted",
              403,
              "FORBIDDEN",
              "\u4EC5\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u533F\u540D\u5316\u5DF2\u8F6F\u5220\u9664\u6210\u5458"
            );
            ensure(
              !target.anonymizedAt,
              409,
              "ALREADY_ANONYMIZED",
              "\u5DF2\u7ECF\u533F\u540D\u5316"
            );
            await tx.set("privacy_jobs", id, {
              id,
              uid: id,
              studentIdDigest: studentIdKey(target.studentId),
              status: "pending",
              createdAt: this.now()
            });
            await this.adjustRoles(tx, target, []);
            await tx.remove("student_ids", studentIdKey(target.studentId));
            await tx.remove("credentials", id);
            next = {
              ...next,
              studentId: "",
              name: "\u5DF2\u533F\u540D\u5316",
              nickname: "\u5DF2\u533F\u540D\u5316",
              gender: "\u672A\u586B\u5199",
              college: "",
              major: "",
              className: "",
              grade: "",
              phone: "",
              email: "",
              avatar: "",
              position: "",
              roleIds: [],
              anonymizedAt: this.now(),
              version: next.version + 1
            };
            fields = ["personalData"];
          } else throw new ApiError(405, "METHOD_NOT_ALLOWED", "\u65B9\u6CD5\u4E0D\u652F\u6301");
          await tx.set("users", id, next);
          await this.audit(
            tx,
            user.uid,
            `members.${action ?? (method === "DELETE" ? "delete" : "edit")}`,
            id,
            fields
          );
          return { data: next };
        }
        const accessRoster = path.match(
          /^\/api\/(roles|permissions)\/([a-zA-Z0-9_.-]+)\/members$/
        );
        if (accessRoster && method === "GET") {
          this.require(ctx, "roles.read");
          this.require(ctx, "members.read");
          const [, scope, id] = accessRoster;
          ensure(await tx.get(scope, id), 404, "NOT_FOUND", "\u89D2\u8272\u6216\u6743\u9650\u4E0D\u5B58\u5728");
          const options = import_zod10.z.object({
            page: import_zod10.z.coerce.number().int().min(1).max(1e4).default(1),
            pageSize: import_zod10.z.coerce.number().int().min(1).max(50).default(20),
            search: import_zod10.z.string().max(80).default(""),
            status: import_zod10.z.enum(["active", "disabled", "deleted", "all"]).default(scope === "roles" ? "all" : "active")
          }).strict().parse(query);
          const result = await this.store.list(
            "access_members",
            {
              [scope === "roles" ? "roleId" : "permissionId"]: id,
              search: options.search,
              status: options.status
            },
            {
              offset: (options.page - 1) * options.pageSize,
              limit: options.pageSize
            }
          );
          return {
            data: { ...result, page: options.page, pageSize: options.pageSize }
          };
        }
        if (path === "/api/roles/member-lookup" && method === "GET") {
          this.require(ctx, "roles.read");
          this.require(ctx, "members.read");
          this.require(ctx, "roles.assign");
          const { studentId } = import_zod10.z.object({ studentId: studentIdSchema }).strict().parse(query);
          const index = await tx.get(
            "student_ids",
            studentIdKey(studentId)
          );
          const target = index ? await tx.get("users", index.uid) : void 0;
          ensure(
            target && target.status !== "deleted",
            404,
            "NOT_FOUND",
            "\u672A\u627E\u5230\u53EF\u5206\u914D\u89D2\u8272\u7684\u6210\u5458"
          );
          await this.manageable(tx, ctx, target);
          const roles = await Promise.all(
            target.roleIds.map(async (id) => {
              const r = await tx.get("roles", id);
              return { id, name: r?.name ?? id, super: !!r?.super };
            })
          );
          return {
            data: {
              uid: target.uid,
              studentId: target.studentId,
              name: target.name,
              nickname: target.nickname,
              status: target.status,
              roleIds: target.roleIds,
              roles,
              sources: []
            }
          };
        }
        const accessChange = path.match(
          /^\/api\/roles\/([a-zA-Z0-9_-]+)\/members\/([a-zA-Z0-9-]+)$/
        );
        if (accessChange && method === "POST") {
          this.require(ctx, "roles.read");
          this.require(ctx, "roles.assign");
          const [, roleId, uid] = accessChange;
          const body = import_zod10.z.object({
            action: import_zod10.z.enum(["add", "remove"]),
            replacementRoleId: import_zod10.z.string().min(1).max(64).optional()
          }).strict().parse(input);
          ensure(
            body.action === "remove" || !body.replacementRoleId,
            400,
            "INVALID_INPUT",
            "\u6DFB\u52A0\u89D2\u8272\u65F6\u65E0\u9700\u66FF\u4EE3\u89D2\u8272"
          );
          const target = await tx.get("users", uid);
          ensure(
            target && target.status !== "deleted",
            404,
            "NOT_FOUND",
            "\u6210\u5458\u4E0D\u5B58\u5728\u6216\u5DF2\u5220\u9664"
          );
          await this.manageable(tx, ctx, target);
          for (const id of [
            roleId,
            ...body.replacementRoleId ? [body.replacementRoleId] : []
          ]) {
            const role = await tx.get("roles", id);
            ensure(role, 400, "INVALID_ROLE", "\u89D2\u8272\u4E0D\u5B58\u5728");
            ensure(
              ctx.super || !role.super && role.permissionIds.every((p) => ctx.permissions.includes(p)),
              403,
              "SCOPE_EXCEEDED",
              "\u4E0D\u80FD\u5206\u914D\u6216\u79FB\u9664\u8D85\u51FA\u81EA\u8EAB\u6743\u9650\u7684\u89D2\u8272"
            );
          }
          const has = target.roleIds.includes(roleId);
          if (has === (body.action === "add"))
            return { data: { uid, changed: false, roleIds: target.roleIds } };
          ensure(
            body.replacementRoleId !== roleId,
            400,
            "INVALID_ROLE",
            "\u66FF\u4EE3\u89D2\u8272\u4E0D\u80FD\u4E0E\u79FB\u9664\u7684\u89D2\u8272\u76F8\u540C"
          );
          const roleIds = body.action === "add" ? [...target.roleIds, roleId] : [
            .../* @__PURE__ */ new Set([
              ...target.roleIds.filter((id) => id !== roleId),
              ...body.replacementRoleId ? [body.replacementRoleId] : []
            ])
          ];
          await this.protectLast(tx, ctx, target, { roleIds });
          ensure(
            roleIds.length >= 1 && roleIds.length <= 10,
            400,
            "INVALID_ROLES",
            "\u6210\u5458\u9700\u4FDD\u7559 1 \u81F3 10 \u4E2A\u89D2\u8272\uFF0C\u8BF7\u9009\u62E9\u66FF\u4EE3\u89D2\u8272"
          );
          await this.adjustRoles(tx, target, roleIds);
          await tx.set("users", uid, {
            ...target,
            roleIds,
            version: target.version + 1,
            updatedAt: new Date(this.clock()).toISOString()
          });
          await this.audit(tx, user.uid, `roles.members.${body.action}`, uid, [
            `role:${roleId}`,
            ...body.replacementRoleId ? [`replacement:${body.replacementRoleId}`] : []
          ]);
          return { data: { uid, changed: true, roleIds } };
        }
        if (path === "/api/permissions" && method === "GET") {
          this.require(ctx, "roles.read");
          return {
            data: (await this.store.list(
              "permissions",
              {},
              { offset: 0, limit: 100 }
            )).items.map((p) => ({ ...p, group: permissionGroup(p.id) }))
          };
        }
        if (path === "/api/roles" && method === "GET") {
          this.require(ctx, "roles.read");
          const page2 = import_zod10.z.coerce.number().int().min(1).max(100).parse(query.page ?? 1);
          const result = await this.store.list(
            "roles",
            {},
            { offset: (page2 - 1) * 100, limit: 100 }
          );
          return { data: { ...result, page: page2, pageSize: 100 } };
        }
        if (path === "/api/roles" && method === "POST" || /^\/api\/roles\/[a-zA-Z0-9_-]+$/.test(path)) {
          this.require(ctx, "roles.manage");
          const id = path.split("/")[3] ?? (0, import_node_crypto11.randomUUID)();
          const previous = await tx.get("roles", id);
          if (method !== "POST")
            ensure(previous, 404, "NOT_FOUND", "\u89D2\u8272\u4E0D\u5B58\u5728");
          if (previous)
            ensure(
              !previous.super && (ctx.super || previous.permissionIds.every(
                (p) => ctx.permissions.includes(p)
              )),
              403,
              "SCOPE_EXCEEDED",
              "\u6B64\u89D2\u8272\u8D85\u51FA\u53EF\u7BA1\u7406\u8303\u56F4"
            );
          if (method === "DELETE") {
            ensure(
              previous && !previous.builtin && previous.memberCount === 0,
              409,
              "ROLE_IN_USE",
              "\u521D\u59CB\u89D2\u8272\u6216\u4ECD\u88AB\u6210\u5458\u4F7F\u7528\u7684\u89D2\u8272\u4E0D\u53EF\u5220\u9664"
            );
            await tx.remove("roles", id);
            await this.audit(tx, user.uid, "roles.delete", id);
            return { data: { ok: true } };
          }
          ensure(
            method === "POST" || method === "PUT",
            405,
            "METHOD_NOT_ALLOWED",
            "\u65B9\u6CD5\u4E0D\u652F\u6301"
          );
          ensure(
            !(method === "POST" && path !== "/api/roles"),
            405,
            "METHOD_NOT_ALLOWED",
            "\u65B9\u6CD5\u4E0D\u652F\u6301"
          );
          const data = roleSchema.parse(input);
          ensure(
            data.name !== "\u8D85\u7EA7\u7BA1\u7406\u5458",
            400,
            "RESERVED_ROLE_NAME",
            "\u8D85\u7EA7\u7BA1\u7406\u5458\u4E3A\u4FDD\u7559\u89D2\u8272\u540D\u79F0"
          );
          for (const permission of data.permissionIds) {
            ensure(
              await tx.get("permissions", permission),
              400,
              "INVALID_PERMISSION",
              "\u6743\u9650\u4E0D\u5B58\u5728"
            );
            ensure(
              ctx.super || ctx.permissions.includes(permission),
              403,
              "SCOPE_EXCEEDED",
              "\u4E0D\u80FD\u6388\u4E88\u8D85\u51FA\u81EA\u8EAB\u7684\u6743\u9650"
            );
          }
          const role = {
            ...data,
            id,
            builtin: previous?.builtin ?? false,
            super: false,
            memberCount: previous?.memberCount ?? 0,
            createdAt: previous?.createdAt ?? this.now()
          };
          await tx.set("roles", id, role);
          await this.audit(
            tx,
            user.uid,
            previous ? "roles.edit" : "roles.create",
            id,
            ["name", "description", "permissionIds"]
          );
          return { data: role };
        }
        const jobMatch = path.match(
          /^\/api\/imports\/([a-f0-9]{64})(?:\/(process))?$/
        );
        if (jobMatch) {
          this.require(ctx, "members.import");
          const job = await tx.get("import_jobs", jobMatch[1]);
          ensure(job, 404, "NOT_FOUND", "\u5BFC\u5165\u4EFB\u52A1\u4E0D\u5B58\u5728");
          ensure(
            job.owner === user.uid || ctx.super,
            403,
            "FORBIDDEN",
            "\u4E0D\u80FD\u8BFB\u53D6\u4ED6\u4EBA\u7684\u5BFC\u5165\u4EFB\u52A1"
          );
          if (method === "GET" && !jobMatch[2]) return { data: job };
          ensure(
            method === "POST" && jobMatch[2] === "process",
            405,
            "METHOD_NOT_ALLOWED",
            "\u65B9\u6CD5\u4E0D\u652F\u6301"
          );
          const body = import_zod10.z.object({ offset: import_zod10.z.number().int().min(0) }).strict().parse(input);
          if (body.offset !== job.offset || job.status === "completed")
            return { data: job };
          const end = Math.min(job.offset + 20, job.rows.length);
          for (let i = job.offset; i < end; i++) {
            const row = job.rows[i];
            if (!row.error && row.member) {
              if (await tx.get("student_ids", studentIdKey(row.member.studentId)))
                row.error = "\u5B66\u53F7\u5DF2\u5B58\u5728\u6216\u88AB\u5176\u4ED6\u4EFB\u52A1\u521B\u5EFA";
              else
                row.uid = (await this.createMember(tx, row.member, user.uid)).uid;
            }
            if (row.uid) job.created++;
            else job.skipped++;
          }
          job.offset = end;
          job.status = end === job.rows.length ? "completed" : "processing";
          job.updatedAt = this.now();
          await tx.set("import_jobs", job.id, job);
          await this.audit(tx, user.uid, "members.import", job.id, [
            `offset:${body.offset}`,
            `created:${job.created}`,
            `skipped:${job.skipped}`
          ]);
          return { data: job };
        }
        if (path === "/api/login-history" && method === "GET") {
          this.require(ctx, "security.logins.read");
          const options = import_zod10.z.object({
            page: import_zod10.z.coerce.number().int().min(1).max(1e4).default(1),
            pageSize: import_zod10.z.coerce.number().int().min(1).max(50).default(20),
            search: import_zod10.z.string().trim().max(80).default(""),
            outcome: import_zod10.z.enum(["all", "success", "failure", "blocked"]).default("all"),
            from: import_zod10.z.string().datetime({ offset: true }).optional(),
            to: import_zod10.z.string().datetime({ offset: true }).optional()
          }).strict().parse(query);
          ensure(
            !options.from || !options.to || Date.parse(options.from) < Date.parse(options.to),
            400,
            "INVALID_DATE_RANGE",
            "\u7ED3\u675F\u65E5\u671F\u987B\u665A\u4E8E\u5F00\u59CB\u65E5\u671F"
          );
          const filter = {
            search: options.search,
            outcome: options.outcome,
            ...options.from ? { from: new Date(options.from).toISOString() } : {},
            ...options.to ? { to: new Date(options.to).toISOString() } : {}
          };
          const result = await this.store.list("login_history", filter, {
            offset: (options.page - 1) * options.pageSize,
            limit: options.pageSize
          });
          return {
            data: { ...result, page: options.page, pageSize: options.pageSize }
          };
        }
        if (path === "/api/audit" && method === "GET") {
          this.require(ctx, "audit.read");
          const page2 = import_zod10.z.coerce.number().int().min(1).max(1e4).parse(query.page ?? 1);
          const result = await this.store.list(
            "audit_logs",
            {},
            { offset: (page2 - 1) * 50, limit: 50 }
          );
          return {
            data: {
              ...result,
              items: result.items.map(({ login: _login, ...record2 }) => {
                void _login;
                return record2;
              }),
              page: page2,
              pageSize: 50
            }
          };
        }
        throw new ApiError(404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
      },
      ["/api/auth/me", "/api/auth/logout", "/api/auth/password"].includes(path),
      publicMutation
    );
  }
};

// src/members/cloudbase-auth.ts
var import_node_crypto12 = require("node:crypto");
var import_signature_nodejs = require("@cloudbase/signature-nodejs");
function cloudbaseAuthorization(env) {
  let cached;
  let pending;
  const invalidate = () => {
    cached = void 0;
  };
  async function header() {
    if (process.env.CLOUDBASE_APIKEY)
      return `Bearer ${process.env.CLOUDBASE_APIKEY}`;
    const secretId = process.env.TENCENTCLOUD_SECRETID, secretKey = process.env.TENCENTCLOUD_SECRETKEY, sessionToken = process.env.TENCENTCLOUD_SESSIONTOKEN;
    if (!secretId || !secretKey)
      throw new DatabaseFailure(
        "runtime_identity",
        "CLOUDBASE_IDENTITY_UNAVAILABLE"
      );
    const fingerprint = (0, import_node_crypto12.createHash)("sha256").update(JSON.stringify([secretId, secretKey, sessionToken])).digest("hex");
    if (cached?.fingerprint === fingerprint && cached.until > Date.now())
      return `Bearer ${cached.token}`;
    if (!pending || pending.fingerprint !== fingerprint) {
      const exchange = async () => {
        const url = `https://${env}.api.tcloudbasegateway.com/auth/v1/token/clientCredential`;
        const body = { grant_type: "client_credentials" };
        const headers = {
          "Content-Type": "application/json",
          Host: new URL(url).host,
          "X-TCB-Source": `${process.env.TCB_SOURCE || ""},scf`,
          "X-Client-Timestamp": String(Date.now()),
          "X-SDK-Version": "tcb-node-sdk/3.18.7"
        };
        if (process.env.TENCENTCLOUD_REGION)
          headers["X-TCB-Region"] = process.env.TENCENTCLOUD_REGION;
        const signed = (0, import_signature_nodejs.sign)({
          secretId,
          secretKey,
          method: "POST",
          url,
          params: body,
          headers,
          timestamp: Math.floor(Date.now() / 1e3) - 1,
          withSignedParams: false,
          isCloudApi: true
        });
        headers.Authorization = `${signed.authorization}, Timestamp=${signed.timestamp}${sessionToken ? `, Token=${sessionToken}` : ""}`;
        let response;
        try {
          response = await fetch(url, {
            method: "POST",
            headers,
            body: JSON.stringify(body),
            signal: AbortSignal.timeout(15e3)
          });
        } catch {
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_UNREACHABLE"
          );
        }
        if (!response.ok)
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_REJECTED"
          );
        let result;
        try {
          result = await response.json();
        } catch {
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_INVALID_RESPONSE"
          );
        }
        if (!result || typeof result.access_token !== "string" || !result.access_token)
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_INVALID_RESPONSE"
          );
        const lifetime = typeof result.expires_in === "number" && Number.isFinite(result.expires_in) ? Math.max(0, Math.min(result.expires_in, 3600) - 60) : 0;
        cached = {
          token: result.access_token,
          until: Date.now() + lifetime * 1e3,
          fingerprint
        };
        return `Bearer ${result.access_token}`;
      };
      pending = { fingerprint, promise: exchange() };
    }
    const active = pending;
    try {
      return await active.promise;
    } finally {
      if (pending === active) pending = void 0;
    }
  }
  return { header, invalidate };
}

// src/members/rdb-diagnostics.ts
var providerCodes = /* @__PURE__ */ new Set([
  "INVALID_PATH",
  "INVALID_ENV",
  "INVALID_ENV_ID",
  "ENV_NOT_FOUND",
  "RESOURCE_NOT_FOUND",
  "DATABASE_NOT_INITIALIZED",
  "DATABASE_NOT_FOUND",
  "PERMISSION_DENIED",
  "UNAUTHORIZED",
  "FORBIDDEN",
  "NOT_FOUND",
  "INTERNAL_ERROR",
  "INTERNAL_SERVER_ERROR",
  "FAILED_OPERATION",
  "ACCESS_TOKEN_INVALID",
  "TOKEN_EXPIRED",
  "FailedOperation",
  "InvalidParameter",
  "InvalidParameterValue",
  "ResourceNotFound",
  "UnauthorizedOperation",
  "AuthFailure",
  "InternalError",
  "OperationDenied",
  "ServiceUnavailable"
]);
var sqlStates = /* @__PURE__ */ new Set([
  "P1401",
  "P1402",
  "P1403",
  "42501",
  "42P01",
  "42883",
  "3F000",
  "23505",
  "23503",
  "23514",
  "23502",
  "40001",
  "40P01",
  "53300",
  "53400",
  "57014",
  "55P03",
  "08000",
  "08001",
  "08003",
  "08004",
  "08006",
  "08P01",
  "XX000",
  "P0001"
]);
var record = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
function safeCode(value) {
  if (typeof value !== "string") return void 0;
  return providerCodes.has(value) || sqlStates.has(value) || /^PGRST\d{3}$/.test(value) ? value : void 0;
}
function safeId(value) {
  return typeof value === "string" && /^(?:[0-9a-f]{32}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(
    value
  ) ? value : void 0;
}
async function rdbDiagnostic(response, operation) {
  let body = {};
  try {
    body = record(await response.json());
  } catch {
  }
  const wrapper = record(body.Response);
  const nested = record(body.error);
  const error = record(wrapper.Error);
  const code = [body.code, nested.code, error.Code, body.errorCode].map(safeCode).find(Boolean);
  const requestId = [
    response.headers.get("x-request-id"),
    response.headers.get("x-tcb-request-id"),
    response.headers.get("x-cloudbase-request-id"),
    body.requestId,
    body.request_id,
    body.reqId,
    body.RequestId,
    wrapper.RequestId
  ].map(safeId).find(Boolean);
  const contentType = response.headers.get("content-type") ?? "";
  return {
    upstreamStatus: response.status,
    upstreamCode: code ?? "UNRECOGNIZED",
    upstreamRequestId: requestId,
    operation: ["ec_read", "ec_list", "ec_commit"].includes(operation) ? operation : "unknown",
    responseKind: contentType.includes("json") ? "json" : contentType.includes("html") ? "html" : "other"
  };
}
function rdbFailureCode(diagnostic) {
  const code = diagnostic.upstreamCode;
  if ([401, 403].includes(diagnostic.upstreamStatus) || [
    "42501",
    "PGRST301",
    "PERMISSION_DENIED",
    "UNAUTHORIZED",
    "FORBIDDEN",
    "AuthFailure",
    "UnauthorizedOperation",
    "ACCESS_TOKEN_INVALID",
    "TOKEN_EXPIRED"
  ].includes(code))
    return "RDB_HTTP_PERMISSION_DENIED";
  if (["PGRST202", "42883"].includes(code)) return "RDB_RPC_NOT_INSTALLED";
  if (["42P01", "3F000", "PGRST205"].includes(code))
    return "RDB_SCHEMA_NOT_INSTALLED";
  if (code === "PGRST106") return "RDB_SCHEMA_NOT_EXPOSED";
  if (code === "INVALID_PATH") return "RDB_ENDPOINT_NOT_AVAILABLE";
  if (["PGRST000", "PGRST001"].includes(code))
    return "RDB_DATABASE_UNAVAILABLE";
  return "RDB_HTTP_FAILED";
}

// src/members/http-store.ts
function cloudbaseRpc() {
  const env = process.env.CLOUDBASE_ENV_ID;
  if (!env || !/^[a-zA-Z0-9-]+$/.test(env))
    throw new DatabaseFailure("configuration", "CLOUDBASE_ENV_REQUIRED");
  const auth = cloudbaseAuthorization(env);
  const base = `https://${env}.api.tcloudbasegateway.com/v1/rdb/rest/rpc/`;
  return async (name, args) => {
    noteDatabaseUse(name);
    const authorization = await auth.header();
    let response;
    try {
      response = await fetch(base + name, {
        method: "POST",
        headers: {
          Authorization: authorization,
          "Content-Type": "application/json",
          "Accept-Profile": "public",
          "Content-Profile": "public"
        },
        body: JSON.stringify(args),
        signal: AbortSignal.timeout(15e3)
      });
    } catch {
      throw new DatabaseFailure("http_connect", "RDB_HTTP_UNREACHABLE");
    }
    if (!response.ok) {
      if (response.status === 401) auth.invalidate();
      const diagnostic = await rdbDiagnostic(response, name);
      const purgeError = name === "ec_commit" && purgeDatabaseError(diagnostic.upstreamCode);
      if (purgeError) throw purgeError;
      throw new DatabaseFailure(
        "http_rpc",
        rdbFailureCode(diagnostic),
        diagnostic
      );
    }
    try {
      return await response.json();
    } catch {
      throw new DatabaseFailure("http_decode", "RDB_HTTP_INVALID_RESPONSE");
    }
  };
}
var HttpStore = class {
  constructor(rpc = cloudbaseRpc()) {
    this.rpc = rpc;
  }
  async read(collection, id) {
    const snapshot = await this.rpc("ec_read", {
      p_collection: collection,
      p_id: id
    });
    return snapshot.data;
  }
  async list(collection, filter, options) {
    if (collection === "public_site_export") {
      if (Object.keys(filter).length || options.offset !== 0 || options.limit !== 1) throw Error("INVALID_PUBLIC_EXPORT_QUERY");
      return { items: [await this.rpc("ec_public_site_export", {})], total: 1 };
    }
    if (collection === "event_roster") {
      validateRosterQuery(filter, options);
      return await this.rpc("ec_event_roster", { p_filter: filter, p_offset: options.offset, p_limit: options.limit });
    }
    if (collection === "member_stats") {
      if (Object.keys(filter).length || options.offset !== 0 || options.limit !== 1) throw new Error("INVALID_STATS_QUERY");
      return { items: [await this.rpc("ec_member_stats", {})], total: 1 };
    }
    if (collection === "club_resources") {
      validateResourceQuery(filter, options);
      return await this.rpc("ec_resources_list", { p_filter: filter, p_offset: options.offset, p_limit: options.limit });
    }
    if (collection === "login_history") {
      validateLoginQuery(filter, options);
      return await this.rpc("ec_login_history", { p_filter: filter, p_offset: options.offset, p_limit: options.limit });
    }
    if (collection === "media_expired") {
      validateExpired(filter, options);
      return await this.rpc("ec_media_expired", { p_before: filter.before, p_limit: options.limit });
    }
    if (collection === "access_members") {
      validateAccessQuery(filter, options);
      return await this.rpc("ec_access_members", { p_filter: filter, p_offset: options.offset, p_limit: options.limit });
    }
    const forum = collection.startsWith("forum_") || filter._forumAudit === true;
    if (forum) validateForumQuery(collection, filter, options);
    return await this.rpc(forum ? "ec_forum_list" : "ec_list", {
      p_collection: collection,
      p_filter: filter,
      p_offset: options.offset,
      p_limit: options.limit
    });
  }
  async run(fn) {
    for (let attempt = 0; attempt < 32; attempt++) {
      const reads = /* @__PURE__ */ new Map(), writes = /* @__PURE__ */ new Map();
      const load = (collection, id) => {
        const key2 = collection + "/" + id;
        if (!reads.has(key2))
          reads.set(
            key2,
            this.rpc("ec_read", {
              p_collection: collection,
              p_id: id
            }).then((snapshot) => ({
              collection,
              id,
              ...snapshot
            }))
          );
        return reads.get(key2);
      };
      const tx = {
        get: async (collection, id) => {
          const key2 = collection + "/" + id;
          return structuredClone(
            writes.has(key2) ? writes.get(key2).data : (await load(collection, id)).data
          );
        },
        set: async (collection, id, data) => {
          await load(collection, id);
          writes.set(collection + "/" + id, {
            collection,
            id,
            data: structuredClone(data)
          });
        },
        remove: async (collection, id) => {
          await load(collection, id);
          writes.set(collection + "/" + id, { collection, id, data: null });
        }
      };
      const result = await fn(tx);
      if (!reads.size && !writes.size) return result;
      const commit = await this.rpc("ec_commit", {
        p_reads: (await Promise.all(reads.values())).map(
          ({ collection, id, etag }) => ({ collection, id, etag })
        ),
        p_writes: [...writes.values()]
      });
      if (commit.ok) return result;
      if (commit.conflict)
        await new Promise(
          (resolve) => setTimeout(resolve, 5 + Math.floor(Math.random() * 20))
        );
      if (!commit.conflict)
        throw new DatabaseFailure("http_commit", "RDB_COMMIT_REJECTED");
    }
    throw new DatabaseFailure("http_commit", "RDB_CONFLICT_RETRY_EXHAUSTED");
  }
};

// src/runtime.ts
var service;
function getService() {
  return service ??= new MemberService(
    process.env.DB_DRIVER === "postgres-tcp" ? new PgStore() : new HttpStore()
  );
}

// src/index.ts
function createHandler(resolveService) {
  return async (event) => {
    const requestId = (0, import_node_crypto13.randomUUID)();
    const headers = {
      "X-Request-ID": requestId,
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      Vary: "Origin",
      "X-Content-Type-Options": "nosniff",
      "X-EClub-Backend-Revision": BACKEND_BODY_REVISION,
      "X-EClub-Data-Revision": "public-site-budget-v1"
    };
    const requestHeaders = Object.fromEntries(
      Object.entries(event.headers ?? {}).map(([k, v]) => [k.toLowerCase(), v])
    );
    const origin = requestHeaders.origin;
    const allowed = process.env.ALLOWED_ORIGIN;
    if (allowed && origin === allowed) {
      headers["Access-Control-Allow-Origin"] = origin;
      headers["Access-Control-Allow-Credentials"] = "true";
      headers["Access-Control-Allow-Methods"] = "GET, POST, PATCH, PUT, DELETE, OPTIONS";
      headers["Access-Control-Allow-Headers"] = "Content-Type, X-Requested-With";
    }
    const respond = (statusCode, body) => ({
      statusCode,
      headers,
      body: JSON.stringify(body)
    });
    const rawPath = (event.path ?? "").split("?")[0];
    const path = rawPath.startsWith("/api/") ? rawPath : "/api" + (rawPath.startsWith("/") ? rawPath : "/" + rawPath);
    const method = event.httpMethod ?? "GET";
    if (method === "OPTIONS") return { statusCode: 204, headers, body: "" };
    if (path === "/api/health") {
      if (method !== "GET")
        return respond(405, {
          success: false,
          error: { code: "METHOD_NOT_ALLOWED", message: "\u4EC5\u652F\u6301 GET" }
        });
      return respond(200, {
        success: true,
        data: {
          status: "ok",
          service: "ElectronicClub API",
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        }
      });
    }
    if (!/^\/api\/(auth|profile|members|roles|permissions|imports|audit|public|public-site|events|articles|popups|forum|media|login-history|resources)(?:\/|$)/.test(
      path
    ))
      return respond(404, {
        success: false,
        error: { code: "NOT_FOUND", message: "\u63A5\u53E3\u4E0D\u5B58\u5728" }
      });
    try {
      if (method !== "GET") {
        if (!allowed || origin !== allowed || requestHeaders["x-requested-with"] !== "ElectronicClub")
          throw new ApiError(403, "CSRF_REJECTED", "\u8BF7\u6C42\u6765\u6E90\u6821\u9A8C\u5931\u8D25");
        if (!(requestHeaders["content-type"] ?? "").startsWith("application/json"))
          throw new ApiError(415, "CONTENT_TYPE", "\u8BF7\u4F7F\u7528application/json");
      }
      const input = parseHttpBody(
        event,
        /^\/api\/(forum|media|resources)(?:\/|$)/.test(path) ? 65536 : 31e5
      );
      const cookieName = sessionCookieConfig().name;
      const token = (requestHeaders.cookie ?? "").split(";").map((x) => x.trim()).find((x) => x.startsWith(`${cookieName}=`))?.slice(cookieName.length + 1) ?? "";
      const query = event.queryStringParameters ?? {};
      if (method === "GET" && path === "/api/public-site/config")
        return respond(200, { success: true, data: { mode: process.env.PUBLIC_SITE_MODE === "qiniu" ? "qiniu" : "database", target: 1500 } });
      if (method === "GET" && process.env.PUBLIC_SITE_MODE === "qiniu") {
        if (isPublicSitePath(path, {}) && !isPublicSitePath(path, query) && query.live !== "true" && query.admin !== "true")
          throw new ApiError(400, "INVALID_INPUT", "\u516C\u5F00\u67E5\u8BE2\u53C2\u6570\u65E0\u6548");
        if (isPublicSitePath(path, query)) {
          headers["X-EClub-Public-Delivery"] = "qiniu-v1";
          const result2 = await publicSiteResponse(new QiniuPublicSiteStorage(), path, query);
          if (result2.binary) {
            headers["Content-Type"] = result2.contentType;
            headers["Content-Disposition"] = "inline";
            return { statusCode: 200, headers, body: result2.binary.toString("base64"), isBase64Encoded: true };
          }
          return respond(200, { success: true, data: result2.data });
        }
        if (path.startsWith("/api/public/") && !isPublicSitePath(path, {})) throw new ApiError(404, "NOT_FOUND", "\u63A5\u53E3\u4E0D\u5B58\u5728");
        if (!token) throw new ApiError(401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
      }
      if (!token && !(path === "/api/auth/login" && method === "POST") && !(method === "GET" && (path.startsWith("/api/media/") || /^\/api\/resources(?:\/[a-f0-9-]{36}\/download)?$/.test(path) || path.startsWith("/api/public/") || /^\/api\/forum\/(boards|posts|images)(?:\/|$)/.test(path))))
        throw new ApiError(401, "UNAUTHENTICATED", "\u8BF7\u5148\u767B\u5F55");
      const service2 = resolveService();
      if (path === "/api/imports/template" && method === "GET") {
        await service2.authorize(token, "members.import");
        headers["Content-Type"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        headers["Content-Disposition"] = 'attachment; filename="members-template.xlsx"';
        return {
          statusCode: 200,
          headers,
          body: (await templateWorkbook()).toString("base64"),
          isBase64Encoded: true
        };
      }
      if (method === "GET" && (path === "/api/members/export.xlsx" || /^\/api\/imports\/[a-f0-9]{64}\/errors.xlsx$/.test(path))) {
        let binary;
        if (path === "/api/members/export.xlsx") {
          const result2 = await service2.execute(
            token,
            "GET",
            "/api/members/export",
            {},
            event.queryStringParameters ?? {}
          );
          const page2 = result2.data;
          binary = await exportWorkbook(
            [
              "\u5B66\u53F7",
              "\u59D3\u540D",
              "\u6635\u79F0",
              "\u6027\u522B",
              "\u5B66\u9662",
              "\u4E13\u4E1A",
              "\u73ED\u7EA7",
              "\u5E74\u7EA7",
              "\u624B\u673A\u53F7",
              "\u90AE\u7BB1",
              "\u72B6\u6001"
            ],
            page2.items.map((m) => [
              m.studentId,
              m.name,
              m.nickname,
              m.gender,
              m.college,
              m.major,
              m.className,
              m.grade,
              m.phone,
              m.email,
              m.status
            ])
          );
        } else {
          const result2 = await service2.execute(
            token,
            "GET",
            path.replace("/errors.xlsx", ""),
            {},
            {}
          );
          const job = result2.data;
          binary = await exportWorkbook(
            [
              "\u539F\u884C\u53F7",
              "\u5B66\u53F7",
              "\u59D3\u540D",
              "\u6027\u522B",
              "\u5B66\u9662",
              "\u4E13\u4E1A",
              "\u73ED\u7EA7",
              "\u5E74\u7EA7",
              "\u9519\u8BEF"
            ],
            job.rows.filter((row) => row.error).map((row) => [
              String(row.line),
              row.member?.studentId ?? "",
              row.member?.name ?? "",
              row.member?.gender ?? "",
              row.member?.college ?? "",
              row.member?.major ?? "",
              row.member?.className ?? "",
              row.member?.grade ?? "",
              row.error ?? ""
            ])
          );
        }
        headers["Content-Type"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        headers["Content-Disposition"] = 'attachment; filename="export.xlsx"';
        return {
          statusCode: 200,
          headers,
          body: binary.toString("base64"),
          isBase64Encoded: true
        };
      }
      const result = path === "/api/auth/login" && method === "POST" ? await service2.login(
        input,
        loginContext(event.requestContext, requestHeaders)
      ) : await service2.execute(
        token,
        method,
        path,
        input,
        event.queryStringParameters ?? {}
      );
      if (result.publicSync) headers["X-EClub-Public-Sync"] = result.publicSync;
      if (result.binary && result.contentType?.startsWith("image/")) {
        headers["Content-Type"] = result.contentType;
        headers["Content-Disposition"] = "inline";
        return {
          statusCode: 200,
          headers,
          body: result.binary.toString("base64"),
          isBase64Encoded: true
        };
      }
      if (result.binary) {
        headers["Content-Type"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        headers["Content-Disposition"] = `attachment; filename="registrations.xlsx"; filename*=UTF-8''${encodeURIComponent(result.filename ?? "registrations.xlsx")}`;
        return {
          statusCode: 200,
          headers,
          body: result.binary.toString("base64"),
          isBase64Encoded: true
        };
      }
      if (result.token || result.clearCookie) {
        headers["Set-Cookie"] = sessionCookie(
          result.token ?? "",
          Boolean(result.clearCookie)
        );
      }
      return result.error ? respond(result.status ?? 400, { success: false, error: result.error }) : respond(200, {
        success: true,
        data: result.data,
        ...result.publicSync && result.publicSync !== "ready" ? {
          warning: "\u5185\u5BB9\u5DF2\u4FDD\u5B58\uFF0C\u516C\u5F00\u9875\u9762\u5C1A\u672A\u540C\u6B65\u5B8C\u6210\u3002\u7BA1\u7406\u5458\u53EF\u5728\u201C\u516C\u5F00\u53D1\u5E03\u4E0E\u9884\u7B97\u201D\u68C0\u67E5\u5E76\u91CD\u65B0\u540C\u6B65\u3002"
        } : {}
      });
    } catch (error) {
      if (error instanceof HttpBodyError) {
        headers["X-EClub-Body-Error"] = error.diagnostic.stage;
        console.error(
          JSON.stringify({
            requestId,
            category: "transport",
            revision: BACKEND_BODY_REVISION,
            code: error.code,
            ...error.diagnostic
          })
        );
      }
      if (error instanceof ApiError && error.status === 401 && path === "/api/auth/logout") {
        headers["Set-Cookie"] = sessionCookie("", true);
        return respond(200, { success: true, data: { ok: true } });
      }
      if (error instanceof ApiError)
        return respond(error.status, {
          success: false,
          error: { code: error.code, message: error.message }
        });
      if (error instanceof import_zod11.ZodError)
        return respond(400, {
          success: false,
          error: {
            code: "INVALID_INPUT",
            message: error.issues.map((x) => `${x.path.join(".")}: ${x.message}`).join("\uFF1B")
          }
        });
      console.error(
        JSON.stringify({
          requestId,
          ...error instanceof DatabaseFailure ? error.diagnostic : void 0,
          category: error instanceof DatabaseFailure ? "database" : "internal",
          stage: error instanceof DatabaseFailure ? error.stage : "request",
          code: error instanceof DatabaseFailure ? error.safeCode : "INTERNAL_FAILURE"
        })
      );
      return respond(503, {
        success: false,
        error: {
          code: "SERVICE_UNAVAILABLE",
          message: "\u670D\u52A1\u6682\u4E0D\u53EF\u7528\uFF0C\u8BF7\u68C0\u67E5\u90E8\u7F72\u914D\u7F6E\u6216\u7A0D\u540E\u91CD\u8BD5"
        }
      });
    }
  };
}
var main = createHandler(getService);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createHandler,
  main
});
