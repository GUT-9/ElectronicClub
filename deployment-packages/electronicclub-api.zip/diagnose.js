"use strict";

// src/members/pg-store.ts
var import_pg = require("pg");
var DatabaseFailure = class extends Error {
  constructor(stage, safeCode2, diagnostic) {
    super("Database unavailable");
    this.stage = stage;
    this.safeCode = safeCode2;
    this.diagnostic = diagnostic;
  }
};
function createPool() {
  if (!process.env.DATABASE_URL)
    throw new DatabaseFailure("configuration", "DATABASE_NOT_CONFIGURED");
  if (process.env.PG_TLS !== "disable" && !process.env.PG_CA_CERT)
    throw new DatabaseFailure("configuration", "TLS_CA_REQUIRED");
  let endpoint;
  try {
    endpoint = new URL(process.env.DATABASE_URL);
  } catch {
    throw new DatabaseFailure("configuration", "INVALID_DATABASE_URL");
  }
  if (!["postgres:", "postgresql:"].includes(endpoint.protocol) || [...endpoint.searchParams.keys()].some(
    (key) => key.toLowerCase().startsWith("ssl")
  ))
    throw new DatabaseFailure("configuration", "UNSAFE_DATABASE_URL");
  if (process.env.PG_TLS === "disable" && !["127.0.0.1", "localhost", "[::1]"].includes(endpoint.hostname))
    throw new DatabaseFailure("configuration", "REMOTE_TLS_REQUIRED");
  return new import_pg.Pool({
    connectionString: process.env.DATABASE_URL,
    max: 4,
    connectionTimeoutMillis: 5e3,
    idleTimeoutMillis: 3e4,
    statement_timeout: 15e3,
    ssl: process.env.PG_TLS === "disable" ? false : { rejectUnauthorized: true, ca: process.env.PG_CA_CERT }
  });
}

// src/members/cloudbase-auth.ts
var import_node_crypto = require("node:crypto");
var import_signature_nodejs = require("@cloudbase/signature-nodejs");
function cloudbaseAuthorization(env) {
  let cached;
  let pending;
  const invalidate = () => {
    cached = void 0;
  };
  async function header() {
    if (process.env.CLOUDBASE_APIKEY)
      return `Bearer ${process.env.CLOUDBASE_APIKEY}`;
    const secretId = process.env.TENCENTCLOUD_SECRETID, secretKey = process.env.TENCENTCLOUD_SECRETKEY, sessionToken = process.env.TENCENTCLOUD_SESSIONTOKEN;
    if (!secretId || !secretKey)
      throw new DatabaseFailure(
        "runtime_identity",
        "CLOUDBASE_IDENTITY_UNAVAILABLE"
      );
    const fingerprint = (0, import_node_crypto.createHash)("sha256").update(JSON.stringify([secretId, secretKey, sessionToken])).digest("hex");
    if (cached?.fingerprint === fingerprint && cached.until > Date.now())
      return `Bearer ${cached.token}`;
    if (!pending || pending.fingerprint !== fingerprint) {
      const exchange = async () => {
        const url = `https://${env}.api.tcloudbasegateway.com/auth/v1/token/clientCredential`;
        const body = { grant_type: "client_credentials" };
        const headers = {
          "Content-Type": "application/json",
          Host: new URL(url).host,
          "X-TCB-Source": `${process.env.TCB_SOURCE || ""},scf`,
          "X-Client-Timestamp": String(Date.now()),
          "X-SDK-Version": "tcb-node-sdk/3.18.7"
        };
        if (process.env.TENCENTCLOUD_REGION)
          headers["X-TCB-Region"] = process.env.TENCENTCLOUD_REGION;
        const signed = (0, import_signature_nodejs.sign)({
          secretId,
          secretKey,
          method: "POST",
          url,
          params: body,
          headers,
          timestamp: Math.floor(Date.now() / 1e3) - 1,
          withSignedParams: false,
          isCloudApi: true
        });
        headers.Authorization = `${signed.authorization}, Timestamp=${signed.timestamp}${sessionToken ? `, Token=${sessionToken}` : ""}`;
        let response;
        try {
          response = await fetch(url, {
            method: "POST",
            headers,
            body: JSON.stringify(body),
            signal: AbortSignal.timeout(15e3)
          });
        } catch {
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_UNREACHABLE"
          );
        }
        if (!response.ok)
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_REJECTED"
          );
        let result;
        try {
          result = await response.json();
        } catch {
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_INVALID_RESPONSE"
          );
        }
        if (!result || typeof result.access_token !== "string" || !result.access_token)
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_INVALID_RESPONSE"
          );
        const lifetime = typeof result.expires_in === "number" && Number.isFinite(result.expires_in) ? Math.max(0, Math.min(result.expires_in, 3600) - 60) : 0;
        cached = {
          token: result.access_token,
          until: Date.now() + lifetime * 1e3,
          fingerprint
        };
        return `Bearer ${result.access_token}`;
      };
      pending = { fingerprint, promise: exchange() };
    }
    const active = pending;
    try {
      return await active.promise;
    } finally {
      if (pending === active) pending = void 0;
    }
  }
  return { header, invalidate };
}

// src/members/rdb-diagnostics.ts
var providerCodes = /* @__PURE__ */ new Set([
  "INVALID_PATH",
  "INVALID_ENV",
  "INVALID_ENV_ID",
  "ENV_NOT_FOUND",
  "RESOURCE_NOT_FOUND",
  "DATABASE_NOT_INITIALIZED",
  "DATABASE_NOT_FOUND",
  "PERMISSION_DENIED",
  "UNAUTHORIZED",
  "FORBIDDEN",
  "NOT_FOUND",
  "INTERNAL_ERROR",
  "INTERNAL_SERVER_ERROR",
  "FAILED_OPERATION",
  "ACCESS_TOKEN_INVALID",
  "TOKEN_EXPIRED",
  "FailedOperation",
  "InvalidParameter",
  "InvalidParameterValue",
  "ResourceNotFound",
  "UnauthorizedOperation",
  "AuthFailure",
  "InternalError",
  "OperationDenied",
  "ServiceUnavailable"
]);
var sqlStates = /* @__PURE__ */ new Set([
  "42501",
  "42P01",
  "42883",
  "3F000",
  "23505",
  "23503",
  "23514",
  "23502",
  "40001",
  "40P01",
  "53300",
  "53400",
  "57014",
  "55P03",
  "08000",
  "08001",
  "08003",
  "08004",
  "08006",
  "08P01",
  "XX000",
  "P0001"
]);
var record = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
function safeCode(value) {
  if (typeof value !== "string") return void 0;
  return providerCodes.has(value) || sqlStates.has(value) || /^PGRST\d{3}$/.test(value) ? value : void 0;
}
function safeId(value) {
  return typeof value === "string" && /^(?:[0-9a-f]{32}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(
    value
  ) ? value : void 0;
}
async function rdbDiagnostic(response, operation) {
  let body = {};
  try {
    body = record(await response.json());
  } catch {
  }
  const wrapper = record(body.Response);
  const nested = record(body.error);
  const error = record(wrapper.Error);
  const code = [body.code, nested.code, error.Code, body.errorCode].map(safeCode).find(Boolean);
  const requestId = [
    response.headers.get("x-request-id"),
    response.headers.get("x-tcb-request-id"),
    response.headers.get("x-cloudbase-request-id"),
    body.requestId,
    body.request_id,
    body.reqId,
    body.RequestId,
    wrapper.RequestId
  ].map(safeId).find(Boolean);
  const contentType = response.headers.get("content-type") ?? "";
  return {
    upstreamStatus: response.status,
    upstreamCode: code ?? "UNRECOGNIZED",
    upstreamRequestId: requestId,
    operation: ["ec_read", "ec_list", "ec_commit"].includes(operation) ? operation : "unknown",
    responseKind: contentType.includes("json") ? "json" : contentType.includes("html") ? "html" : "other"
  };
}
function rdbFailureCode(diagnostic) {
  const code = diagnostic.upstreamCode;
  if ([401, 403].includes(diagnostic.upstreamStatus) || [
    "42501",
    "PGRST301",
    "PERMISSION_DENIED",
    "UNAUTHORIZED",
    "FORBIDDEN",
    "AuthFailure",
    "UnauthorizedOperation",
    "ACCESS_TOKEN_INVALID",
    "TOKEN_EXPIRED"
  ].includes(code))
    return "RDB_HTTP_PERMISSION_DENIED";
  if (["PGRST202", "42883"].includes(code)) return "RDB_RPC_NOT_INSTALLED";
  if (["42P01", "3F000", "PGRST205"].includes(code))
    return "RDB_SCHEMA_NOT_INSTALLED";
  if (code === "PGRST106") return "RDB_SCHEMA_NOT_EXPOSED";
  if (code === "INVALID_PATH") return "RDB_ENDPOINT_NOT_AVAILABLE";
  if (["PGRST000", "PGRST001"].includes(code))
    return "RDB_DATABASE_UNAVAILABLE";
  return "RDB_HTTP_FAILED";
}

// src/members/http-store.ts
function cloudbaseRpc() {
  const env = process.env.CLOUDBASE_ENV_ID;
  if (!env || !/^[a-zA-Z0-9-]+$/.test(env))
    throw new DatabaseFailure("configuration", "CLOUDBASE_ENV_REQUIRED");
  const auth = cloudbaseAuthorization(env);
  const base = `https://${env}.api.tcloudbasegateway.com/v1/rdb/rest/rpc/`;
  return async (name, args) => {
    const authorization = await auth.header();
    let response;
    try {
      response = await fetch(base + name, {
        method: "POST",
        headers: {
          Authorization: authorization,
          "Content-Type": "application/json",
          "Accept-Profile": "public",
          "Content-Profile": "public"
        },
        body: JSON.stringify(args),
        signal: AbortSignal.timeout(15e3)
      });
    } catch {
      throw new DatabaseFailure("http_connect", "RDB_HTTP_UNREACHABLE");
    }
    if (!response.ok) {
      if (response.status === 401) auth.invalidate();
      const diagnostic = await rdbDiagnostic(response, name);
      throw new DatabaseFailure(
        "http_rpc",
        rdbFailureCode(diagnostic),
        diagnostic
      );
    }
    try {
      return await response.json();
    } catch {
      throw new DatabaseFailure("http_decode", "RDB_HTTP_INVALID_RESPONSE");
    }
  };
}
var HttpStore = class {
  constructor(rpc = cloudbaseRpc()) {
    this.rpc = rpc;
  }
  async read(collection, id) {
    const snapshot = await this.rpc("ec_read", {
      p_collection: collection,
      p_id: id
    });
    return snapshot.data;
  }
  async list(collection, filter, options) {
    return await this.rpc("ec_list", {
      p_collection: collection,
      p_filter: filter,
      p_offset: options.offset,
      p_limit: options.limit
    });
  }
  async run(fn) {
    for (let attempt = 0; attempt < 5; attempt++) {
      const reads = /* @__PURE__ */ new Map(), writes = /* @__PURE__ */ new Map();
      const load = (collection, id) => {
        const key = collection + "/" + id;
        if (!reads.has(key))
          reads.set(
            key,
            this.rpc("ec_read", {
              p_collection: collection,
              p_id: id
            }).then((snapshot) => ({
              collection,
              id,
              ...snapshot
            }))
          );
        return reads.get(key);
      };
      const tx = {
        get: async (collection, id) => {
          const key = collection + "/" + id;
          return structuredClone(
            writes.has(key) ? writes.get(key).data : (await load(collection, id)).data
          );
        },
        set: async (collection, id, data) => {
          await load(collection, id);
          writes.set(collection + "/" + id, {
            collection,
            id,
            data: structuredClone(data)
          });
        },
        remove: async (collection, id) => {
          await load(collection, id);
          writes.set(collection + "/" + id, { collection, id, data: null });
        }
      };
      const result = await fn(tx);
      const commit = await this.rpc("ec_commit", {
        p_reads: (await Promise.all(reads.values())).map(
          ({ collection, id, etag }) => ({ collection, id, etag })
        ),
        p_writes: [...writes.values()]
      });
      if (commit.ok) return result;
      if (!commit.conflict)
        throw new DatabaseFailure("http_commit", "RDB_COMMIT_REJECTED");
    }
    throw new DatabaseFailure("http_commit", "RDB_CONFLICT_RETRY_EXHAUSTED");
  }
};

// src/diagnose.ts
async function run() {
  if (process.env.DB_DRIVER !== "postgres-tcp") {
    const store = new HttpStore();
    await store.run(async (tx) => {
      await tx.get("system", "control");
    });
    console.log(
      JSON.stringify({
        httpsRpc: true,
        transactionRoundtrip: true,
        initialized: !!await store.read("system", "control")
      })
    );
    return;
  }
  const pool = createPool();
  try {
    const connection = await pool.connect();
    try {
      await connection.query("BEGIN");
      await connection.query("SELECT 1");
      await connection.query("ROLLBACK");
      const role = await connection.query(
        "SELECT rolsuper,rolcreatedb,rolcreaterole,rolreplication FROM pg_roles WHERE rolname=current_user"
      );
      const unsafe = Object.values(role.rows[0] ?? {}).some(Boolean);
      if (unsafe) throw new Error("PRIVILEGED_ROLE");
      console.log(
        JSON.stringify({
          database: "reachable",
          transaction: "passed",
          restrictedRole: true
        })
      );
    } finally {
      connection.release();
    }
  } finally {
    await pool.end();
  }
}
run().catch((error) => {
  console.error(
    JSON.stringify({
      ...error instanceof DatabaseFailure ? error.diagnostic : void 0,
      stage: error instanceof DatabaseFailure ? error.stage : "database_diagnostic",
      code: error instanceof DatabaseFailure ? error.safeCode : "DB_CHECK_FAILED"
    })
  );
  process.exitCode = 1;
});
