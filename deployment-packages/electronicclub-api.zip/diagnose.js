"use strict";

// src/members/pg-store.ts
var import_pg = require("pg");
var DatabaseFailure = class extends Error {
  constructor(stage, safeCode) {
    super("Database unavailable");
    this.stage = stage;
    this.safeCode = safeCode;
  }
};
function createPool() {
  if (!process.env.DATABASE_URL)
    throw new DatabaseFailure("configuration", "DATABASE_NOT_CONFIGURED");
  if (process.env.PG_TLS !== "disable" && !process.env.PG_CA_CERT)
    throw new DatabaseFailure("configuration", "TLS_CA_REQUIRED");
  let endpoint;
  try {
    endpoint = new URL(process.env.DATABASE_URL);
  } catch {
    throw new DatabaseFailure("configuration", "INVALID_DATABASE_URL");
  }
  if (!["postgres:", "postgresql:"].includes(endpoint.protocol) || [...endpoint.searchParams.keys()].some(
    (key) => key.toLowerCase().startsWith("ssl")
  ))
    throw new DatabaseFailure("configuration", "UNSAFE_DATABASE_URL");
  if (process.env.PG_TLS === "disable" && !["127.0.0.1", "localhost", "[::1]"].includes(endpoint.hostname))
    throw new DatabaseFailure("configuration", "REMOTE_TLS_REQUIRED");
  return new import_pg.Pool({
    connectionString: process.env.DATABASE_URL,
    max: 4,
    connectionTimeoutMillis: 5e3,
    idleTimeoutMillis: 3e4,
    statement_timeout: 15e3,
    ssl: process.env.PG_TLS === "disable" ? false : { rejectUnauthorized: true, ca: process.env.PG_CA_CERT }
  });
}

// src/members/http-store.ts
function cloudbaseRpc() {
  const env = process.env.CLOUDBASE_ENV_ID, key = process.env.CLOUDBASE_APIKEY;
  if (!env || !/^[a-zA-Z0-9-]+$/.test(env) || !key)
    throw new DatabaseFailure("configuration", "CLOUDBASE_HTTP_AUTH_REQUIRED");
  const base = `https://${env}.api.tcloudbasegateway.com/v1/rdb/rest/rpc/`;
  return async (name, args) => {
    let response;
    try {
      response = await fetch(base + name, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
          "Accept-Profile": "public",
          "Content-Profile": "public"
        },
        body: JSON.stringify(args),
        signal: AbortSignal.timeout(15e3)
      });
    } catch {
      throw new DatabaseFailure("http_connect", "RDB_HTTP_UNREACHABLE");
    }
    if (!response.ok) {
      let code = "";
      try {
        code = (await response.json()).code ?? "";
      } catch {
      }
      const safeCode = response.status === 401 || response.status === 403 || code === "42501" ? "RDB_HTTP_PERMISSION_DENIED" : code === "PGRST202" || code === "42883" ? "RDB_RPC_NOT_INSTALLED" : code === "42P01" ? "RDB_SCHEMA_NOT_INSTALLED" : "RDB_HTTP_FAILED";
      throw new DatabaseFailure("http_rpc", safeCode);
    }
    try {
      return await response.json();
    } catch {
      throw new DatabaseFailure("http_decode", "RDB_HTTP_INVALID_RESPONSE");
    }
  };
}
var HttpStore = class {
  constructor(rpc = cloudbaseRpc()) {
    this.rpc = rpc;
  }
  async read(collection, id) {
    const snapshot = await this.rpc("ec_read", {
      p_collection: collection,
      p_id: id
    });
    return snapshot.data;
  }
  async list(collection, filter, options) {
    return await this.rpc("ec_list", {
      p_collection: collection,
      p_filter: filter,
      p_offset: options.offset,
      p_limit: options.limit
    });
  }
  async run(fn) {
    for (let attempt = 0; attempt < 5; attempt++) {
      const reads = /* @__PURE__ */ new Map(), writes = /* @__PURE__ */ new Map();
      const load = (collection, id) => {
        const key = collection + "/" + id;
        if (!reads.has(key))
          reads.set(
            key,
            this.rpc("ec_read", {
              p_collection: collection,
              p_id: id
            }).then((snapshot) => ({
              collection,
              id,
              ...snapshot
            }))
          );
        return reads.get(key);
      };
      const tx = {
        get: async (collection, id) => {
          const key = collection + "/" + id;
          return structuredClone(
            writes.has(key) ? writes.get(key).data : (await load(collection, id)).data
          );
        },
        set: async (collection, id, data) => {
          await load(collection, id);
          writes.set(collection + "/" + id, {
            collection,
            id,
            data: structuredClone(data)
          });
        },
        remove: async (collection, id) => {
          await load(collection, id);
          writes.set(collection + "/" + id, { collection, id, data: null });
        }
      };
      const result = await fn(tx);
      const commit = await this.rpc("ec_commit", {
        p_reads: (await Promise.all(reads.values())).map(
          ({ collection, id, etag }) => ({ collection, id, etag })
        ),
        p_writes: [...writes.values()]
      });
      if (commit.ok) return result;
      if (!commit.conflict)
        throw new DatabaseFailure("http_commit", "RDB_COMMIT_REJECTED");
    }
    throw new DatabaseFailure("http_commit", "RDB_CONFLICT_RETRY_EXHAUSTED");
  }
};

// src/diagnose.ts
async function run() {
  if (process.env.DB_DRIVER !== "postgres-tcp") {
    const store = new HttpStore();
    await store.run(async (tx) => {
      await tx.get("system", "control");
    });
    console.log(
      JSON.stringify({
        httpsRpc: true,
        transactionRoundtrip: true,
        initialized: !!await store.read("system", "control")
      })
    );
    return;
  }
  const pool = createPool();
  try {
    const connection = await pool.connect();
    try {
      await connection.query("BEGIN");
      await connection.query("SELECT 1");
      await connection.query("ROLLBACK");
      const role = await connection.query(
        "SELECT rolsuper,rolcreatedb,rolcreaterole,rolreplication FROM pg_roles WHERE rolname=current_user"
      );
      const unsafe = Object.values(role.rows[0] ?? {}).some(Boolean);
      if (unsafe) throw new Error("PRIVILEGED_ROLE");
      console.log(
        JSON.stringify({
          database: "reachable",
          transaction: "passed",
          restrictedRole: true
        })
      );
    } finally {
      connection.release();
    }
  } finally {
    await pool.end();
  }
}
run().catch((error) => {
  console.error(
    JSON.stringify({
      stage: error instanceof DatabaseFailure ? error.stage : "database_diagnostic",
      code: error instanceof DatabaseFailure ? error.safeCode : "DB_CHECK_FAILED"
    })
  );
  process.exitCode = 1;
});
