"use strict";

// src/members/pg-store.ts
var import_pg = require("pg");
var DatabaseFailure = class extends Error {
  constructor(stage, safeCode) {
    super("Database unavailable");
    this.stage = stage;
    this.safeCode = safeCode;
  }
};
function createPool() {
  if (!process.env.DATABASE_URL)
    throw new DatabaseFailure("configuration", "DATABASE_NOT_CONFIGURED");
  if (process.env.PG_TLS !== "disable" && !process.env.PG_CA_CERT)
    throw new DatabaseFailure("configuration", "TLS_CA_REQUIRED");
  let endpoint;
  try {
    endpoint = new URL(process.env.DATABASE_URL);
  } catch {
    throw new DatabaseFailure("configuration", "INVALID_DATABASE_URL");
  }
  if (!["postgres:", "postgresql:"].includes(endpoint.protocol) || [...endpoint.searchParams.keys()].some(
    (key) => key.toLowerCase().startsWith("ssl")
  ))
    throw new DatabaseFailure("configuration", "UNSAFE_DATABASE_URL");
  if (process.env.PG_TLS === "disable" && !["127.0.0.1", "localhost", "[::1]"].includes(endpoint.hostname))
    throw new DatabaseFailure("configuration", "REMOTE_TLS_REQUIRED");
  return new import_pg.Pool({
    connectionString: process.env.DATABASE_URL,
    max: 4,
    connectionTimeoutMillis: 5e3,
    idleTimeoutMillis: 3e4,
    statement_timeout: 15e3,
    ssl: process.env.PG_TLS === "disable" ? false : { rejectUnauthorized: true, ca: process.env.PG_CA_CERT }
  });
}

// src/diagnose.ts
async function run() {
  const pool = createPool();
  try {
    const connection = await pool.connect();
    try {
      await connection.query("BEGIN");
      await connection.query("SELECT 1");
      await connection.query("ROLLBACK");
      const role = await connection.query(
        "SELECT rolsuper,rolcreatedb,rolcreaterole,rolreplication FROM pg_roles WHERE rolname=current_user"
      );
      const unsafe = Object.values(role.rows[0] ?? {}).some(Boolean);
      if (unsafe) throw new Error("PRIVILEGED_ROLE");
      console.log(
        JSON.stringify({
          database: "reachable",
          transaction: "passed",
          restrictedRole: true
        })
      );
    } finally {
      connection.release();
    }
  } finally {
    await pool.end();
  }
}
run().catch(() => {
  console.error(
    JSON.stringify({ stage: "database_diagnostic", code: "DB_CHECK_FAILED" })
  );
  process.exitCode = 1;
});
