"use strict";

// src/resources/query.ts
function validateResourceQuery(filter, options) {
  if (Object.keys(filter).some(
    (k) => ![
      "public",
      "status",
      "search",
      "category",
      "cleanupBefore",
      "uploadBefore"
    ].includes(k)
  ) || Object.values(filter).some(
    (v) => typeof v !== "string" && typeof v !== "boolean"
  ) || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50 || String(filter.search ?? "").length > 80 || String(filter.category ?? "").length > 40 || filter.status && ![
    "uploading",
    "draft",
    "published",
    "deleting",
    "deleted",
    "all"
  ].includes(String(filter.status)))
    throw new Error("INVALID_RESOURCE_QUERY");
}

// src/members/login-query.ts
function validateLoginQuery(filter, options) {
  if (Object.keys(filter).some(
    (k) => !["search", "outcome", "from", "to"].includes(k)
  ) || Object.values(filter).some((v) => typeof v !== "string") || String(filter.search ?? "").length > 80 || !["all", "success", "failure", "blocked"].includes(
    String(filter.outcome ?? "all")
  ) || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50)
    throw new Error("INVALID_LOGIN_QUERY");
  for (const key of ["from", "to"])
    if (filter[key] && !Number.isFinite(Date.parse(String(filter[key]))))
      throw new Error("INVALID_LOGIN_DATE");
}
var actor = `coalesce(nullif(a.data#>>'{login,memberUid}',''),CASE WHEN a.data->>'action'='auth.login' THEN a.data->>'actor' END)`;
var concealed = `(u.data->>'anonymizedAt' IS NOT NULL)`;
var LOGIN_HISTORY_SQL = `WITH records AS (SELECT a.id,a.data->>'createdAt' AS at,
 jsonb_build_object('id',a.id,'createdAt',a.data->>'createdAt','memberUid',${actor},'name',coalesce(u.data->>'name',''),'studentId',coalesce(u.data->>'studentId',''),
 'outcome',CASE a.data->>'action' WHEN 'auth.login' THEN 'success' WHEN 'auth.login_blocked' THEN 'blocked' ELSE 'failure' END,
 'reason',coalesce(a.data#>>'{login,reason}',''),'ip',CASE WHEN ${concealed} THEN NULL ELSE a.data#>>'{login,ip}' END,
 'ipSource',CASE WHEN ${concealed} THEN 'unavailable' ELSE coalesce(a.data#>>'{login,ipSource}','legacy') END,
 'device',CASE WHEN ${concealed} THEN '' ELSE coalesce(a.data#>>'{login,device}','') END,'os',CASE WHEN ${concealed} THEN '' ELSE coalesce(a.data#>>'{login,os}','') END,
 'browser',CASE WHEN ${concealed} THEN '' ELSE coalesce(a.data#>>'{login,browser}','') END,'userAgent',CASE WHEN ${concealed} THEN '' ELSE coalesce(a.data#>>'{login,userAgent}','') END,
 'legacy',NOT(a.data ? 'login'),'anonymized',coalesce(${concealed},false)) AS record
 FROM electronicclub.audit_logs a LEFT JOIN electronicclub.users u ON u.id=${actor}
 WHERE a.data->>'action' IN ('auth.login','auth.login_failed','auth.login_blocked')
 AND (NOT $1::jsonb ? 'from' OR a.data->>'createdAt'>=$1::jsonb->>'from') AND (NOT $1::jsonb ? 'to' OR a.data->>'createdAt'<$1::jsonb->>'to')),
 filtered AS (SELECT * FROM records WHERE (coalesce($1::jsonb->>'outcome','all')='all' OR record->>'outcome'=$1::jsonb->>'outcome') AND strpos(lower(coalesce(record->>'name','')||' '||coalesce(record->>'studentId','')||' '||coalesce(record->>'ip','')),lower(coalesce($1::jsonb->>'search','')))>0),
 paged AS (SELECT * FROM filtered ORDER BY at DESC,id LIMIT $2 OFFSET $3)
 SELECT jsonb_build_object('total',(SELECT count(*) FROM filtered),'items',coalesce((SELECT jsonb_agg(record ORDER BY at DESC,id) FROM paged),'[]'::jsonb)) AS result`;

// src/media/query.ts
function validateExpired(filter, options) {
  if (Object.keys(filter).length !== 1 || typeof filter.before !== "string" || !Number.isFinite(Date.parse(filter.before)) || options.offset !== 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50)
    throw new Error("INVALID_MEDIA_CLEANUP_QUERY");
}

// src/members/access-query.ts
function validateAccessQuery(filter, options) {
  const keys2 = ["roleId", "permissionId", "search", "status"];
  if (Object.keys(filter).some((k) => !keys2.includes(k)) || Object.values(filter).some((v) => typeof v !== "string") || Number(!!filter.roleId) + Number(!!filter.permissionId) !== 1 || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50 || !["active", "disabled", "deleted", "all"].includes(
    String(filter.status ?? "active")
  ) || String(filter.search ?? "").length > 80)
    throw new Error("INVALID_ACCESS_QUERY");
}
var matches = `(($1::jsonb ? 'roleId' AND r.id=$1::jsonb->>'roleId') OR ($1::jsonb ? 'permissionId' AND (r.data->>'super'='true' OR r.data->'permissionIds' @> jsonb_build_array($1::jsonb->>'permissionId'))))`;
var roleSummary = `jsonb_build_object('id',r.id,'name',r.data->>'name','super',coalesce((r.data->>'super')::boolean,false))`;
var ACCESS_SQL = `WITH filtered AS (SELECT u.id,u.data FROM electronicclub.users u WHERE u.data->>'status' IN ('active','disabled','deleted') AND (coalesce($1::jsonb->>'status','active')='all' OR u.data->>'status'=coalesce($1::jsonb->>'status','active')) AND (NOT $1::jsonb ? 'search' OR strpos(upper(coalesce(u.data->>'studentId','')||' '||coalesce(u.data->>'name','')||' '||coalesce(u.data->>'nickname','')),upper($1::jsonb->>'search'))>0) AND EXISTS(SELECT 1 FROM electronicclub.user_roles ur JOIN electronicclub.roles r ON r.id=ur.role_id WHERE ur.user_id=u.id AND ${matches})),paged AS (SELECT id,data FROM filtered ORDER BY data->>'studentId',id LIMIT $2 OFFSET $3) SELECT jsonb_build_object('total',(SELECT count(*) FROM filtered),'items',coalesce((SELECT jsonb_agg(jsonb_build_object('uid',p.id,'studentId',p.data->>'studentId','name',p.data->>'name','nickname',p.data->>'nickname','status',p.data->>'status','roleIds',p.data->'roleIds','roles',coalesce((SELECT jsonb_agg(${roleSummary} ORDER BY r.data->>'name',r.id) FROM electronicclub.user_roles ur JOIN electronicclub.roles r ON r.id=ur.role_id WHERE ur.user_id=p.id),'[]'::jsonb),'sources',coalesce((SELECT jsonb_agg(${roleSummary} ORDER BY r.data->>'name',r.id) FROM electronicclub.user_roles ur JOIN electronicclub.roles r ON r.id=ur.role_id WHERE ur.user_id=p.id AND ${matches}),'[]'::jsonb)) ORDER BY p.data->>'studentId',p.id) FROM paged p),'[]'::jsonb)) AS result`;

// src/forum/query.ts
var FORUM_TABLES = [
  "forum_boards",
  "forum_posts",
  "forum_comments",
  "forum_likes",
  "forum_favorites",
  "forum_reports",
  "forum_user_restrictions",
  "forum_notifications",
  "forum_images"
];
var queryTables = [...FORUM_TABLES, "audit_logs"];
var keys = [
  "_createdBefore",
  "_beforeFloor",
  "_forumAudit",
  "status",
  "boardId",
  "postId",
  "authorUid",
  "recipientUid",
  "reporterUid",
  "ownerUid",
  "uid",
  "read",
  "_search",
  "_sort",
  "_public",
  "_favoriteUid",
  "_featured",
  "_notDeleted"
];
function validateForumQuery(collection, filter, options) {
  if (!queryTables.includes(collection) || Object.keys(filter).some((k) => !keys.includes(k)) || Object.values(filter).some(
    (v) => !["string", "boolean"].includes(typeof v)
  ) || !Number.isInteger(options.offset) || options.offset < 0 || !Number.isInteger(options.limit) || options.limit < 1 || options.limit > 50)
    throw new Error("INVALID_FORUM_QUERY");
  if (collection === "audit_logs" && filter._forumAudit !== true)
    throw new Error("INVALID_FORUM_AUDIT");
  if (filter._beforeFloor && !/^\d{1,9}$/.test(String(filter._beforeFloor)))
    throw new Error("INVALID_FLOOR");
  if (filter._sort && !["latest", "reply", "hot", "oldest", "featured"].includes(
    String(filter._sort)
  ))
    throw new Error("INVALID_FORUM_SORT");
}

// src/members/pg-store.ts
var import_pg = require("pg");
var tables = /* @__PURE__ */ new Set([
  ...FORUM_TABLES,
  "club_resources",
  "media_images",
  "media_chunks",
  "events",
  "event_managers",
  "registrations",
  "checkins",
  "articles",
  "popup_announcements",
  "popup_state",
  "users",
  "roles",
  "permissions",
  "credentials",
  "sessions",
  "student_ids",
  "audit_logs",
  "import_jobs",
  "login_limits",
  "system",
  "privacy_jobs"
]);
var DatabaseFailure = class extends Error {
  constructor(stage, safeCode2, diagnostic) {
    super("Database unavailable");
    this.stage = stage;
    this.safeCode = safeCode2;
    this.diagnostic = diagnostic;
  }
};
function createPool() {
  if (!process.env.DATABASE_URL)
    throw new DatabaseFailure("configuration", "DATABASE_NOT_CONFIGURED");
  if (process.env.PG_TLS !== "disable" && !process.env.PG_CA_CERT)
    throw new DatabaseFailure("configuration", "TLS_CA_REQUIRED");
  let endpoint;
  try {
    endpoint = new URL(process.env.DATABASE_URL);
  } catch {
    throw new DatabaseFailure("configuration", "INVALID_DATABASE_URL");
  }
  if (!["postgres:", "postgresql:"].includes(endpoint.protocol) || [...endpoint.searchParams.keys()].some(
    (key) => key.toLowerCase().startsWith("ssl")
  ))
    throw new DatabaseFailure("configuration", "UNSAFE_DATABASE_URL");
  if (process.env.PG_TLS === "disable" && !["127.0.0.1", "localhost", "[::1]"].includes(endpoint.hostname))
    throw new DatabaseFailure("configuration", "REMOTE_TLS_REQUIRED");
  return new import_pg.Pool({
    connectionString: process.env.DATABASE_URL,
    max: 4,
    connectionTimeoutMillis: 5e3,
    idleTimeoutMillis: 3e4,
    statement_timeout: 15e3,
    ssl: process.env.PG_TLS === "disable" ? false : { rejectUnauthorized: true, ca: process.env.PG_CA_CERT }
  });
}

// src/members/cloudbase-auth.ts
var import_node_crypto = require("node:crypto");
var import_signature_nodejs = require("@cloudbase/signature-nodejs");
function cloudbaseAuthorization(env) {
  let cached;
  let pending;
  const invalidate = () => {
    cached = void 0;
  };
  async function header() {
    if (process.env.CLOUDBASE_APIKEY)
      return `Bearer ${process.env.CLOUDBASE_APIKEY}`;
    const secretId = process.env.TENCENTCLOUD_SECRETID, secretKey = process.env.TENCENTCLOUD_SECRETKEY, sessionToken = process.env.TENCENTCLOUD_SESSIONTOKEN;
    if (!secretId || !secretKey)
      throw new DatabaseFailure(
        "runtime_identity",
        "CLOUDBASE_IDENTITY_UNAVAILABLE"
      );
    const fingerprint = (0, import_node_crypto.createHash)("sha256").update(JSON.stringify([secretId, secretKey, sessionToken])).digest("hex");
    if (cached?.fingerprint === fingerprint && cached.until > Date.now())
      return `Bearer ${cached.token}`;
    if (!pending || pending.fingerprint !== fingerprint) {
      const exchange = async () => {
        const url = `https://${env}.api.tcloudbasegateway.com/auth/v1/token/clientCredential`;
        const body = { grant_type: "client_credentials" };
        const headers = {
          "Content-Type": "application/json",
          Host: new URL(url).host,
          "X-TCB-Source": `${process.env.TCB_SOURCE || ""},scf`,
          "X-Client-Timestamp": String(Date.now()),
          "X-SDK-Version": "tcb-node-sdk/3.18.7"
        };
        if (process.env.TENCENTCLOUD_REGION)
          headers["X-TCB-Region"] = process.env.TENCENTCLOUD_REGION;
        const signed = (0, import_signature_nodejs.sign)({
          secretId,
          secretKey,
          method: "POST",
          url,
          params: body,
          headers,
          timestamp: Math.floor(Date.now() / 1e3) - 1,
          withSignedParams: false,
          isCloudApi: true
        });
        headers.Authorization = `${signed.authorization}, Timestamp=${signed.timestamp}${sessionToken ? `, Token=${sessionToken}` : ""}`;
        let response;
        try {
          response = await fetch(url, {
            method: "POST",
            headers,
            body: JSON.stringify(body),
            signal: AbortSignal.timeout(15e3)
          });
        } catch {
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_UNREACHABLE"
          );
        }
        if (!response.ok)
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_REJECTED"
          );
        let result;
        try {
          result = await response.json();
        } catch {
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_INVALID_RESPONSE"
          );
        }
        if (!result || typeof result.access_token !== "string" || !result.access_token)
          throw new DatabaseFailure(
            "identity_exchange",
            "CLOUDBASE_IDENTITY_INVALID_RESPONSE"
          );
        const lifetime = typeof result.expires_in === "number" && Number.isFinite(result.expires_in) ? Math.max(0, Math.min(result.expires_in, 3600) - 60) : 0;
        cached = {
          token: result.access_token,
          until: Date.now() + lifetime * 1e3,
          fingerprint
        };
        return `Bearer ${result.access_token}`;
      };
      pending = { fingerprint, promise: exchange() };
    }
    const active = pending;
    try {
      return await active.promise;
    } finally {
      if (pending === active) pending = void 0;
    }
  }
  return { header, invalidate };
}

// src/members/rdb-diagnostics.ts
var providerCodes = /* @__PURE__ */ new Set([
  "INVALID_PATH",
  "INVALID_ENV",
  "INVALID_ENV_ID",
  "ENV_NOT_FOUND",
  "RESOURCE_NOT_FOUND",
  "DATABASE_NOT_INITIALIZED",
  "DATABASE_NOT_FOUND",
  "PERMISSION_DENIED",
  "UNAUTHORIZED",
  "FORBIDDEN",
  "NOT_FOUND",
  "INTERNAL_ERROR",
  "INTERNAL_SERVER_ERROR",
  "FAILED_OPERATION",
  "ACCESS_TOKEN_INVALID",
  "TOKEN_EXPIRED",
  "FailedOperation",
  "InvalidParameter",
  "InvalidParameterValue",
  "ResourceNotFound",
  "UnauthorizedOperation",
  "AuthFailure",
  "InternalError",
  "OperationDenied",
  "ServiceUnavailable"
]);
var sqlStates = /* @__PURE__ */ new Set([
  "42501",
  "42P01",
  "42883",
  "3F000",
  "23505",
  "23503",
  "23514",
  "23502",
  "40001",
  "40P01",
  "53300",
  "53400",
  "57014",
  "55P03",
  "08000",
  "08001",
  "08003",
  "08004",
  "08006",
  "08P01",
  "XX000",
  "P0001"
]);
var record = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
function safeCode(value) {
  if (typeof value !== "string") return void 0;
  return providerCodes.has(value) || sqlStates.has(value) || /^PGRST\d{3}$/.test(value) ? value : void 0;
}
function safeId(value) {
  return typeof value === "string" && /^(?:[0-9a-f]{32}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(
    value
  ) ? value : void 0;
}
async function rdbDiagnostic(response, operation) {
  let body = {};
  try {
    body = record(await response.json());
  } catch {
  }
  const wrapper = record(body.Response);
  const nested = record(body.error);
  const error = record(wrapper.Error);
  const code = [body.code, nested.code, error.Code, body.errorCode].map(safeCode).find(Boolean);
  const requestId = [
    response.headers.get("x-request-id"),
    response.headers.get("x-tcb-request-id"),
    response.headers.get("x-cloudbase-request-id"),
    body.requestId,
    body.request_id,
    body.reqId,
    body.RequestId,
    wrapper.RequestId
  ].map(safeId).find(Boolean);
  const contentType = response.headers.get("content-type") ?? "";
  return {
    upstreamStatus: response.status,
    upstreamCode: code ?? "UNRECOGNIZED",
    upstreamRequestId: requestId,
    operation: ["ec_read", "ec_list", "ec_commit"].includes(operation) ? operation : "unknown",
    responseKind: contentType.includes("json") ? "json" : contentType.includes("html") ? "html" : "other"
  };
}
function rdbFailureCode(diagnostic) {
  const code = diagnostic.upstreamCode;
  if ([401, 403].includes(diagnostic.upstreamStatus) || [
    "42501",
    "PGRST301",
    "PERMISSION_DENIED",
    "UNAUTHORIZED",
    "FORBIDDEN",
    "AuthFailure",
    "UnauthorizedOperation",
    "ACCESS_TOKEN_INVALID",
    "TOKEN_EXPIRED"
  ].includes(code))
    return "RDB_HTTP_PERMISSION_DENIED";
  if (["PGRST202", "42883"].includes(code)) return "RDB_RPC_NOT_INSTALLED";
  if (["42P01", "3F000", "PGRST205"].includes(code))
    return "RDB_SCHEMA_NOT_INSTALLED";
  if (code === "PGRST106") return "RDB_SCHEMA_NOT_EXPOSED";
  if (code === "INVALID_PATH") return "RDB_ENDPOINT_NOT_AVAILABLE";
  if (["PGRST000", "PGRST001"].includes(code))
    return "RDB_DATABASE_UNAVAILABLE";
  return "RDB_HTTP_FAILED";
}

// src/members/http-store.ts
function cloudbaseRpc() {
  const env = process.env.CLOUDBASE_ENV_ID;
  if (!env || !/^[a-zA-Z0-9-]+$/.test(env))
    throw new DatabaseFailure("configuration", "CLOUDBASE_ENV_REQUIRED");
  const auth = cloudbaseAuthorization(env);
  const base = `https://${env}.api.tcloudbasegateway.com/v1/rdb/rest/rpc/`;
  return async (name, args) => {
    const authorization = await auth.header();
    let response;
    try {
      response = await fetch(base + name, {
        method: "POST",
        headers: {
          Authorization: authorization,
          "Content-Type": "application/json",
          "Accept-Profile": "public",
          "Content-Profile": "public"
        },
        body: JSON.stringify(args),
        signal: AbortSignal.timeout(15e3)
      });
    } catch {
      throw new DatabaseFailure("http_connect", "RDB_HTTP_UNREACHABLE");
    }
    if (!response.ok) {
      if (response.status === 401) auth.invalidate();
      const diagnostic = await rdbDiagnostic(response, name);
      throw new DatabaseFailure(
        "http_rpc",
        rdbFailureCode(diagnostic),
        diagnostic
      );
    }
    try {
      return await response.json();
    } catch {
      throw new DatabaseFailure("http_decode", "RDB_HTTP_INVALID_RESPONSE");
    }
  };
}
var HttpStore = class {
  constructor(rpc = cloudbaseRpc()) {
    this.rpc = rpc;
  }
  async read(collection, id) {
    const snapshot = await this.rpc("ec_read", {
      p_collection: collection,
      p_id: id
    });
    return snapshot.data;
  }
  async list(collection, filter, options) {
    if (collection === "member_stats") {
      if (Object.keys(filter).length || options.offset !== 0 || options.limit !== 1) throw new Error("INVALID_STATS_QUERY");
      return { items: [await this.rpc("ec_member_stats", {})], total: 1 };
    }
    if (collection === "club_resources") {
      validateResourceQuery(filter, options);
      return await this.rpc("ec_resources_list", { p_filter: filter, p_offset: options.offset, p_limit: options.limit });
    }
    if (collection === "login_history") {
      validateLoginQuery(filter, options);
      return await this.rpc("ec_login_history", { p_filter: filter, p_offset: options.offset, p_limit: options.limit });
    }
    if (collection === "media_expired") {
      validateExpired(filter, options);
      return await this.rpc("ec_media_expired", { p_before: filter.before, p_limit: options.limit });
    }
    if (collection === "access_members") {
      validateAccessQuery(filter, options);
      return await this.rpc("ec_access_members", { p_filter: filter, p_offset: options.offset, p_limit: options.limit });
    }
    const forum = collection.startsWith("forum_") || filter._forumAudit === true;
    if (forum) validateForumQuery(collection, filter, options);
    return await this.rpc(forum ? "ec_forum_list" : "ec_list", {
      p_collection: collection,
      p_filter: filter,
      p_offset: options.offset,
      p_limit: options.limit
    });
  }
  async run(fn) {
    for (let attempt = 0; attempt < 32; attempt++) {
      const reads = /* @__PURE__ */ new Map(), writes = /* @__PURE__ */ new Map();
      const load = (collection, id) => {
        const key = collection + "/" + id;
        if (!reads.has(key))
          reads.set(
            key,
            this.rpc("ec_read", {
              p_collection: collection,
              p_id: id
            }).then((snapshot) => ({
              collection,
              id,
              ...snapshot
            }))
          );
        return reads.get(key);
      };
      const tx = {
        get: async (collection, id) => {
          const key = collection + "/" + id;
          return structuredClone(
            writes.has(key) ? writes.get(key).data : (await load(collection, id)).data
          );
        },
        set: async (collection, id, data) => {
          await load(collection, id);
          writes.set(collection + "/" + id, {
            collection,
            id,
            data: structuredClone(data)
          });
        },
        remove: async (collection, id) => {
          await load(collection, id);
          writes.set(collection + "/" + id, { collection, id, data: null });
        }
      };
      const result = await fn(tx);
      const commit = await this.rpc("ec_commit", {
        p_reads: (await Promise.all(reads.values())).map(
          ({ collection, id, etag }) => ({ collection, id, etag })
        ),
        p_writes: [...writes.values()]
      });
      if (commit.ok) return result;
      if (commit.conflict)
        await new Promise(
          (resolve) => setTimeout(resolve, 5 + Math.floor(Math.random() * 20))
        );
      if (!commit.conflict)
        throw new DatabaseFailure("http_commit", "RDB_COMMIT_REJECTED");
    }
    throw new DatabaseFailure("http_commit", "RDB_CONFLICT_RETRY_EXHAUSTED");
  }
};

// src/diagnose.ts
async function run() {
  if (process.env.DB_DRIVER !== "postgres-tcp") {
    const store = new HttpStore();
    await store.run(async (tx) => {
      await tx.get("system", "control");
    });
    console.log(
      JSON.stringify({
        httpsRpc: true,
        transactionRoundtrip: true,
        initialized: !!await store.read("system", "control")
      })
    );
    return;
  }
  const pool = createPool();
  try {
    const connection = await pool.connect();
    try {
      await connection.query("BEGIN");
      await connection.query("SELECT 1");
      await connection.query("ROLLBACK");
      const role = await connection.query(
        "SELECT rolsuper,rolcreatedb,rolcreaterole,rolreplication FROM pg_roles WHERE rolname=current_user"
      );
      const unsafe = Object.values(role.rows[0] ?? {}).some(Boolean);
      if (unsafe) throw new Error("PRIVILEGED_ROLE");
      console.log(
        JSON.stringify({
          database: "reachable",
          transaction: "passed",
          restrictedRole: true
        })
      );
    } finally {
      connection.release();
    }
  } finally {
    await pool.end();
  }
}
run().catch((error) => {
  console.error(
    JSON.stringify({
      ...error instanceof DatabaseFailure ? error.diagnostic : void 0,
      stage: error instanceof DatabaseFailure ? error.stage : "database_diagnostic",
      code: error instanceof DatabaseFailure ? error.safeCode : "DB_CHECK_FAILED"
    })
  );
  process.exitCode = 1;
});
